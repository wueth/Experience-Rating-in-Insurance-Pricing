####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Dynamic random effects null model: full exposure RNN implementation
#########  Author: Mario Wuthrich
#########  Version Jully 2024
####################################################################################

library(arrow)
library(tidyverse)
library(keras)
library(tensorflow)

pathPlot <- "../../Plots/"

####################################################################################
### load and pre-process data
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic

labelGLM <- c("ClaimNb", "True", "DrivAgeX", "GenderX", "LeasingX",
            "LowMileageX", "CatPriceX", "DeductibleX",
            "DurationX", "YearX",
            paste("VA", c(2:8), sep=""), paste("Re", c(2:15), sep=""),
            paste("Year", c(2:9), sep=""))

source("./Tools/01a static mixed effects - load data GLM.r")

tensor <- tensorGLM
dim(tensor)
tensor[1:4,,1]

### extract only policies with full exposures over the entire period
tensor[,1,1] <- rowSums(tensor[,-1,1])
YY <- tensor[which(tensor[,1,1]==9),-1,3]

###
(TT <- ncol(YY)) # number of years
(tt <- c(1:TT))  # list of all years
(muR <- mean(colMeans(YY))) # empirical frequency


## initialize tensors
Bias <- array(1, dim=nrow(YY))            # vector of ones
Null <- array(0, dim=c(nrow(YY), TT, 1))  # tensor of zeros
Time <- array(0, dim=c(nrow(YY), TT, 1))  # tensor with calendar years
for (t0 in 1:TT){Time[,t0, 1] <- t0-1}    # encode time for embeddings


####################################################################################
#########  the bounded variance case p in (0,1) and q in (0,1)
#########  (null model) to back-test the tailor-made RNN layer
####################################################################################

source("./Tools/02b networks dynamic.R")

seed <- 100
init0 <- c(log(muR), log(.5), log(3-1), log(3-1))
path1 <- paste("./Networks/NullModel",seed,".h5", sep="")
model <- network.null.model(seed, TT, init0=init0)

#
Q_loss <- function(y_true, y_pred){
    beta1    <- y_pred[,2:(TT+1),4]    # note that this is shifted by one time index
    alpha1   <- y_pred[,1:TT,5]
    mu1      <- y_pred[,2:(TT+1),1]
    q1       <- y_pred[,2:(TT+1),3]
    YY1      <- y_true
    -k_sum(+tf$math$lgamma(alpha1+YY1)-tf$math$lgamma(alpha1)+
           k_log((1-mu1*q1/beta1)^alpha1 * (mu1*q1/beta1)^YY1))
          }

model %>% compile(loss = Q_loss, optimizer = 'nadam')
### inputs: claims, bias, vt*mu0, pt, qt
### we start with the null model with vt=1, pt=p, qt=q
#{t1 <- proc.time()
#  fit <- model %>% fit(list(YY, Bias, Null, Null, Null), YY,
#                  batch_size=10000, epochs=1000, verbose=0)
#(proc.time()-t1)[3]}
#plot(fit)
#save_model_weights_hdf5(model, path1)
load_model_weights_hdf5(model, path1)

pred000 <- (model %>% predict(list(YY, Bias, Null, Null, Null), batch_size=10^6))


# mu 1, alpha/beta 4/5, p 2, q 3
round(param000 <- c(pred000[1,2,1], pred000[1,1,5], pred000[1,2,2], pred000[1,2,3]),4)

AIC0 <- 4
round(k_get_value(-Q_loss(YY, pred000)-sum(tf$math$lgamma(YY+1)))/nrow(YY),4)
round(-2*k_get_value(-Q_loss(YY, pred000)-sum(tf$math$lgamma(YY+1))) + 2* AIC0)



####################################################################################
#########  exploiting non-parametric modeling of mu_t, p_t, q_t
####################################################################################


####################################################################################
#########  (1) non-parametric p_t
####################################################################################

path1 <- paste("./Networks/PtModel",seed,".h5", sep="")
model <- network.null.model(seed, TT, init0=init0)

model %>% compile(loss = Q_loss, optimizer = 'nadam')
###
#{t1 <- proc.time()
#  fit <- model %>% fit(list(YY, Bias, Null, Time, Null), YY,
#                  batch_size=10000, epochs=1000, verbose=0)
#(proc.time()-t1)[3]}
#plot(fit)
#save_model_weights_hdf5(model, path1)
load_model_weights_hdf5(model, path1)

pred010 <- (model %>% predict(list(YY, Bias, Null, Time, Null), batch_size=10^6))

# mu 1, alpha/beta 4/5, p 2, q 3
round(param010 <- c(pred010[1,2,1], pred010[1,1,5], pred010[1,2,2], pred010[1,2,3]),4)

AIC0 <- TT+3
round(k_get_value(-Q_loss(YY, pred010)-sum(tf$math$lgamma(YY+1)))/nrow(YY),4)
round(-2*k_get_value(-Q_loss(YY, pred010)-sum(tf$math$lgamma(YY+1))) + 2* AIC0)


####################################################################################
#########  non-parametric q_t
####################################################################################

path1 <- paste("./Networks/QtModel",seed,".h5", sep="")
model <- network.null.model(seed, TT, init0=init0)

model %>% compile(loss = Q_loss, optimizer = 'nadam')
###
#{t1 <- proc.time()
#  fit <- model %>% fit(list(YY, Bias, Null, Null, Time), YY,
#                  batch_size=10000, epochs=1000, verbose=0)
#(proc.time()-t1)[3]}
#plot(fit)
#save_model_weights_hdf5(model, path1)
load_model_weights_hdf5(model, path1)

pred001 <- (model %>% predict(list(YY, Bias, Null, Null, Time), batch_size=10^6))

# mu 1, alpha/beta 4/5, p 2, q 3
round(param001 <- c(pred001[1,2,1], pred001[1,1,5], pred001[1,2,2], pred001[1,2,3]),4)

AIC0 <- TT+3
round(k_get_value(-Q_loss(YY, pred001)-sum(tf$math$lgamma(YY+1)))/nrow(YY),4)
round(-2*k_get_value(-Q_loss(YY, pred001)-sum(tf$math$lgamma(YY+1))) + 2* AIC0)


####################################################################################
#########  non-parametric v_t*mu_t (only full exposure claims v_t=1)
####################################################################################

path1 <- paste("./Networks/Mu_tModel",seed,".h5", sep="")
model <- network.null.model(seed, TT, init0=init0)

model %>% compile(loss = Q_loss, optimizer = 'nadam')
###
#{t1 <- proc.time()
#  fit <- model %>% fit(list(YY, Bias, Time, Null, Null), YY,
#                  batch_size=10000, epochs=1000, verbose=0)
#(proc.time()-t1)[3]}
#plot(fit)
#save_model_weights_hdf5(model, path1)
load_model_weights_hdf5(model, path1)

pred100 <- (model %>% predict(list(YY, Bias, Time, Null, Null), batch_size=10^6))

# mu 1, alpha/beta 4/5, p 2, q 3
round(param100 <- c(pred100[1,2,1], pred100[1,1,5], pred100[1,2,2], pred100[1,2,3]),4)

AIC0 <- TT+3
round(k_get_value(-Q_loss(YY, pred100)-sum(tf$math$lgamma(YY+1)))/nrow(YY),4)
round(-2*k_get_value(-Q_loss(YY, pred100)-sum(tf$math$lgamma(YY+1))) + 2* AIC0)


####################################################################################
#########  flexible p_t and q_t
####################################################################################

path1 <- paste("./Networks/PtQtModel",seed,".h5", sep="")
model <- network.null.model(seed, TT, init0=init0)

model %>% compile(loss = Q_loss, optimizer = 'nadam')
###
#{t1 <- proc.time()
#  fit <- model %>% fit(list(YY, Bias, Null, Time, Time), YY,
#                  batch_size=10000, epochs=1000, verbose=0)
#(proc.time()-t1)[3]}
#plot(fit)
#save_model_weights_hdf5(model, path1)
load_model_weights_hdf5(model, path1)


pred011 <- (model %>% predict(list(YY, Bias, Null, Time, Time), batch_size=10^6))

# mu 1, alpha/beta 4/5, p 2, q 3
round(param011 <- c(pred011[1,2,1], pred011[1,1,5], pred011[1,2,2], pred011[1,2,3]),4)

AIC0 <- 2*TT+2
round(k_get_value(-Q_loss(YY, pred011)-sum(tf$math$lgamma(YY+1)))/nrow(YY),4)
round(-2*k_get_value(-Q_loss(YY, pred011)-sum(tf$math$lgamma(YY+1))) + 2* AIC0)


####################################################################################
#########  fully flexible
####################################################################################

path1 <- paste("./Networks/Full_tModel",seed,".h5", sep="")
model <- network.null.model(seed, TT, init0=init0)

model %>% compile(loss = Q_loss, optimizer = 'nadam')
###
#{t1 <- proc.time()
#  fit <- model %>% fit(list(YY, Bias, Time, Time, Time), YY,
#                  batch_size=10000, epochs=1000, verbose=0)
#(proc.time()-t1)[3]}
#plot(fit)
#save_model_weights_hdf5(model, path1)
load_model_weights_hdf5(model, path1)

pred111 <- (model %>% predict(list(YY, Bias, Time, Time, Time), batch_size=10^6))

# mu 1, alpha/beta 4/5, p 2, q 3
round(param111 <- c(pred111[1,2,1], pred111[1,1,5], pred111[1,2,2], pred111[1,2,3]),4)

AIC0 <- 3*TT+1
round(k_get_value(-Q_loss(YY, pred111)-sum(tf$math$lgamma(YY+1)))/nrow(YY),4)
round(-2*k_get_value(-Q_loss(YY, pred111)-sum(tf$math$lgamma(YY+1))) + 2* AIC0)

####################################################################################


plot.yes <- TRUE
plot.yes <- FALSE
if (plot.yes){pdf(file=paste(pathPlot, "Ch4/Pt.pdf", sep=""))}
plot(x=c(1:TT), y=pred010[1,2:(TT+1),2], cex.axis=1.5, pch=20, cex=2, col="blue", ylim=range(0,1,pred010[1,2:(TT+1),2],pred111[1,2:(TT+1),2], param000[3]), main=list("non-parametric estimation of p_t", cex=2), ylab="values", xlab="time t", cex.lab=2)
abline(h=param000[3], lwd=2)
legend(x="topleft", pch=c(-1,20,20),cex=2, lwd=c(2,-1,-1), col=c("black", "blue", "red"), legend=c("null model", "p_t"))
if (plot.yes){dev.off()}

plot.yes <- TRUE
plot.yes <- FALSE
if (plot.yes){pdf(file=paste(pathPlot, "Ch4/Qt.pdf", sep=""))}
plot(x=c(1:TT), y=pred001[1,2:(TT+1),3], cex.axis=1.5, pch=20, cex=2, col="blue", ylim=range(0,1,pred001[1,2:(TT+1),3],pred111[1,2:(TT+1),3], param000[4]), main=list("non-parametric estimation of q_t", cex=2), ylab="values", xlab="time t", cex.lab=2)
abline(h=param000[4], lwd=2)
legend(x="bottomleft", pch=c(-1,20,20),cex=2, lwd=c(2,-1,-1), col=c("black", "blue", "red"), legend=c("null model", "q_t"))
if (plot.yes){dev.off()}

plot.yes <- TRUE
plot.yes <- FALSE
if (plot.yes){pdf(file=paste(pathPlot, "Ch4/lambdat.pdf", sep=""))}
plot(x=c(1:TT), y=pred100[1,2:(TT+1),1], cex.axis=1.5, pch=20, cex=2, col="blue", ylim=range(0.1, pred100[1,2:(TT+1),1], pred111[1,2:(TT+1),1], param000[1]), main=list("non-parametric estimation of mu_t", cex=2), ylab="values", xlab="time t", cex.lab=2)
abline(h=param000[1], lwd=2)
legend(x="topright", pch=c(-1,20,20),cex=2, lwd=c(2,-1,-1), col=c("black", "blue", "red"), legend=c("null model", "mu_t"))
if (plot.yes){dev.off()}

