####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Dynamic mixed effects model: only full exposure policies
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(arrow)
library(tidyverse)
library(keras)
library(tensorflow)

pathPlot <- "../../Plots/"

####################################################################################
### load and pre-process data
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic

labelNN <- c("ClaimNb", "True", "DrivAgeX", "GenderX", "LeasingX",
            "LowMileageX", "CatPriceX", "DeductibleX",
            "DurationX", "YearX",
            "VehAgeX", "RegionX", "YearCatNN")

T00 <- 2011
T1 <- 2019

source("./Tools/01b static mixed effects - load data NN.r")

####################################################################################
#########  select and preprocess data
####################################################################################

cont <- c(5:10,13)
labelNN[cont-2]
cate <- c(14)
labelNN[cate-2]

tensor <- tensorNN
### extract only policies with full exposures over the entire period
tensor[,1,1] <- rowSums(tensor[,-1,1])              # observations yes/no
tensorTT <- tensor[which(tensor[,1,1]==9),,]
(dim0 <- dim(tensorTT))
Bias <- array(1, dim=dim0[1])
Null <- array(0, dim=c(dim0[1], T1-T00+1, 1))
(muR <- sum(tensorTT[,-1,3])/sum(tensorTT[,-1,2]))
learn.NN   <- tensorTT[,-1,3]                    # observed claim counts
learn.Expo <- pmax(tensorTT[,-1,2], .0000000001) # exposure with a small positive lower bound
learn.XX   <- tensorTT[,-1,cont]                 # continuous covariates
learn.Cat  <- tensorTT[,-1,cate]                 # categorical covariates

####################################################################################
#########  dynamic mixed effects FNN model
####################################################################################

source("./Tools/02b networks dynamic.R")

seed <- 100
init0 <- c(log(muR), log(.5), log(3-1), log(3-1))
tt <- T1-T00+1
(q0 <- c(tt, length(cont), c(20,15,10)))
bb <- c(2)
cat0 <- c(length(unique(tensorTT[,2,cate])))
path1 <- paste("./Networks/DynamicFNN",seed,"_",T1,".h5", sep="")
### careful: this network needs claims with equal length claims histories
model <- network.regression.model(seed, q0, cat0, bb, init0)
#
Q_loss <- function(y_true, y_pred){
    beta1    <- y_pred[,2:(tt+1),4] # beta_t+1 = q_t*(beta_t+lambda_t)
    alpha1   <- y_pred[,1:tt,5]     # alpha_t
    mu1      <- y_pred[,2:(tt+1),1] # mu_t
    q1       <- y_pred[,2:(tt+1),3] # p_t, PS: q_t in position 2 is not needed
    NN1      <- y_true
    -k_sum(+tf$math$lgamma(alpha1+NN1)-tf$math$lgamma(alpha1)+
           k_log((1-mu1*q1/beta1)^alpha1 * (mu1*q1/beta1)^NN1))
          }
model %>% compile(loss = Q_loss, optimizer = 'nadam')
#
CBs <- callback_model_checkpoint(path1, monitor = "val_loss", verbose = 0,  save_best_only = TRUE, save_weights_only = TRUE)
### can be time-consuming
#{t1 <- proc.time()
#     fit <- model %>% fit(list(learn.NN, learn.Expo, Bias,
#                               learn.XX, learn.Cat, Null, Null), learn.NN,
#                  validation_split=0.2,
#                  batch_size=5000, epochs=1000, verbose=0, callbacks=CBs)
#(proc.time()-t1)[3]}
#
#plot.loss("topright", fit[[2]], paste("validation loss year ",T1, sep=""), ylim0=range(fit[[2]]), col0=c("blue","darkgreen", "orange"))


### model evaluation
load_model_weights_hdf5(model, path1)
pred <- (model %>% predict(list(learn.NN, learn.Expo, Bias, learn.XX, learn.Cat, Null, Null), batch_size=10^6))



# mu 1, alpha/beta 4/5, p 2, q 3
round(param <- c(pred[1,2,1], pred[1,1,5], pred[1,2,2], pred[1,2,3]),4)

AIC0 <- 735
round(k_get_value(-Q_loss(learn.NN, pred)-sum(tf$math$lgamma(learn.NN+1)))/nrow(learn.NN),4)
round(-2*k_get_value(-Q_loss(learn.NN, pred)-sum(tf$math$lgamma(learn.NN+1))) + 2* AIC0)


####################################################################################
### plot crediblity weights
####################################################################################

expo.decay <- function(s, t, p, q, AlphaMu){
      Delta <- t-s
      (1-q)*p^(Delta+1) / (AlphaMu*q^(s-1)*(1-q)+(1-q^s)+(q^(-Delta)-1))
      }

# select parameters
T0 <- c(2:10)
col0 <- rainbow(n=length(T0), start=0.25, end=.5)
p1 <- round(pred[1,2,2],2)
q1 <- round(pred[1,2,3],2)
AlphaMu1 <- pred[1,1,5]/muR


ylim0 <- range(0, expo.decay(T0[1], T0[1], p1, q1, AlphaMu1))
for (i1 in 1:length(T0)){ylim0 <- range(ylim0,  expo.decay(T0[i1], T0[i1], p1, q1, AlphaMu1))}

col0[5] <- "red"

plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(pathPlot, "/Ch4/boundedVarianceFNN.pdf", sep="")
i0 <- 1
if (plot.yes){pdf(file=filey1)}
plot(x=c(1:T0[i0]), y=expo.decay(c(1:T0[i0]), T0[i0], p1, q1, AlphaMu1), ylim=ylim0, xlim=range(1,T0), type='l', lwd=2, ylab="credibility weights", col=col0[i0], xlab="observation time s", main=list(paste("credibility weights for p=",p1," and q=", q1, sep=""), cex=1.5), cex.lab=1.5)
for (i1 in rev(1: length(T0))){lines(x=c(1:T0[i1]), y=expo.decay(c(1:T0[i1]), T0[i1], p1, q1, AlphaMu1), lwd=2, col=col0[i1])}
if (plot.yes){dev.off()}


############

prior.weight <- function(t, p, q, AlphaMu){
      tt <- c(1:t)
      1-q^(1-tt)*p*(1-(p*q)^tt)/(1-p*q)/(q^(1-tt)*(1-q^tt)/(1-q)+AlphaMu)
      }

plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(pathPlot, "/Ch4/PriorWeightFNN.pdf", sep="")
if (plot.yes){pdf(file=filey1)}
plot(x=c(0:30), y=c(1,prior.weight(30, p1, q1, AlphaMu1)), type='l', lwd=2, ylab="credibility weight", col="blue", xlab="years of observations t", main=list(paste("weight on prior for p=",p1," and q=", q1, sep=""), cex=1.5), cex.lab=1.5)
for (i1 in rev(1: length(T0))){lines(x=c(1:T0[i1]), y=expo.decay(c(1:T0[i1]), T0[i1], p1, q1, AlphaMu1), lwd=2, col=col0[i1])}
abline(h=.85, lty=2, col="darkgray")
if (plot.yes){dev.off()}
