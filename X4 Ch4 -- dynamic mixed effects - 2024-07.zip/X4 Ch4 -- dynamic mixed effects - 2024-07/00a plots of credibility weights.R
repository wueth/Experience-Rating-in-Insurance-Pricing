####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Dynamic random effects: plots credibility weights
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

pathPlot <- "../../Plots/"

####################################################################################
### functions weights
####################################################################################


expo.decay <- function(s, t, p, q, AlphaMu){
      Delta <- t-s
      (1-q)*p^(Delta+1) / (AlphaMu*q^(s-1)*(1-q) + (1-q^s) + (q^(-Delta)-1))
      }

expo.decayQ1 <- function(s, t, p, q=1, AlphaMu){
      Delta <- t-s
      p^(Delta+1) / (AlphaMu + s + Delta)
      }

####################################################################################
### plots
####################################################################################

# select parameters
T0 <- c(2:10)
col0 <- rainbow(n=length(T0), start=0.25, end=.5)
p1 <- .23
q1 <- .79
AlphaMu1 <- 0.2414/0.0823
p2 <- 1
q2 <- .80
AlphaMu2 <- 2.0199/0.0825
p3 <- .31
q3 <- 1
AlphaMu3 <- 0.1535/0.0808


ylim0 <- range(0, expo.decay(T0[1], T0[1], p1, q1, AlphaMu1), expo.decay(T0[1], T0[1], p2, q2, AlphaMu2), expo.decayQ1(T0[1], T0[1], p3, q3, AlphaMu3))
for (i1 in 1:length(T0)){ylim0 <- range(ylim0,  expo.decay(T0[i1], T0[i1], p1, q1, AlphaMu1), expo.decay(T0[i1], T0[i1], p2, q2, AlphaMu2), expo.decayQ1(T0[i1], T0[i1], p3, q3, AlphaMu3))}

col0[5] <- "red"

plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(pathPlot, "/Ch4/boundedVariance.pdf", sep="")
i0 <- 1
if (plot.yes){pdf(file=filey1)}
plot(x=c(1:T0[i0]), y=expo.decay(c(1:T0[i0]), T0[i0], p1, q1, AlphaMu1), ylim=ylim0, xlim=range(1,T0), type='l', lwd=2, ylab="credibility weights", col=col0[i0], xlab="observation time s", main=list(paste("credibility weights for p=",p1," and q=", q1, sep=""), cex=1.5), cex.lab=1.5)
for (i1 in rev(1: length(T0))){lines(x=c(1:T0[i1]), y=expo.decay(c(1:T0[i1]), T0[i1], p1, q1, AlphaMu1), lwd=2, col=col0[i1])}
if (plot.yes){dev.off()}


filey1 <- paste(pathPlot, "/Ch4/increasingVariance.pdf", sep="")
i0 <- 1
if (plot.yes){pdf(file=filey1)}
plot(x=c(1:T0[i0]), y=expo.decay(c(1:T0[i0]), T0[i0], p2,  q2, AlphaMu2), ylim=ylim0, xlim=range(1,T0), type='l', lwd=2, ylab="credibility weights", col=col0[i0], xlab="observation time s", main=list(paste("credibility weights for p=",p2," and q=", q2, sep=""), cex=1.5), cex.lab=1.5)
for (i1 in rev(1: length(T0))){lines(x=c(1:T0[i1]), y=expo.decay(c(1:T0[i1]), T0[i1], p2,  q2, AlphaMu2), lwd=2, col=col0[i1])}
if (plot.yes){dev.off()}


filey1 <- paste(pathPlot, "/Ch4/decreasingVariance.pdf", sep="")
i0 <- 1
if (plot.yes){pdf(file=filey1)}
plot(x=c(1:T0[i0]), y=expo.decayQ1(c(1:T0[i0]), T0[i0], p3 , q3, AlphaMu3), ylim=ylim0, xlim=range(1,T0), type='l', lwd=2, ylab="credibility weights", col=col0[i0], xlab="observation time s", main=list(paste("credibility weights for p=",p3," and q=", q3, sep=""), cex=1.5), cex.lab=1.5)
for (i1 in rev(1: length(T0))){lines(x=c(1:T0[i1]), y=expo.decayQ1(c(1:T0[i1]), T0[i1], p3, q3, AlphaMu3), lwd=2, col=col0[i1])}
legend(x="topright", cex=1.5, col=col0, pch=rep(-1,length(T0)), lwd=rep(2,length(T0)), legend=paste("t=",T0, sep=""))
if (plot.yes){dev.off()}


