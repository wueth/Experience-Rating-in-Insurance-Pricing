####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Dynamic mixed effects GLM
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(arrow)
library(tidyverse)
library(keras)
library(tensorflow)

pathPlot <- "../../Plots/"


####################################################################################
### load and pre-process data
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic

labelGLM <- c("ClaimNb", "True", "DrivAgeX", "GenderX", "LeasingX",
            "LowMileageX", "CatPriceX", "DeductibleX", "DurationX", "YearX",
            paste("VA", c(2:8), sep=""), paste("Re", c(2:15), sep=""),
            paste("Year", c(2:9), sep=""))

source("./Tools/01a static mixed effects - load data GLM.r")

tensor <- tensorGLM
dim(tensor)

GLM.XX <- c(5:10, 13:33) # 1=Observation YES/NO, 2=Exposure, 3=ClaimNb, 4=True, 11=Duration, 12=YearX
labelGLM[GLM.XX-2]

####################################################################################
### set parameters and define loss functions
####################################################################################

Poisson.Deviance <- function(obs, pred){200*(sum(pred)-sum(obs)+sum(log((obs/pred)^(obs))))/length(pred)}
NB.KL.divergence <- function(true, est, phi){100*mean(true*(log(true/est)-phi/(phi-1)*log(phi/((phi-1)*est/true+1))))}

phi.star <- 1.3
T0 <- 2014
T1 <- 2018

####################################################################################
### load GLM networks
####################################################################################

source("./Tools/02a network architectures.R")
source("./Tools/02b networks dynamic.R")

####################################################################################
### one year ahead MLEs for empirical Bayes  (dynamic random effects model)
####################################################################################

results_DME_GLM_1Year <- data.frame(array(NA, dim=c(T1-T0+1, 7)))
names(results_DME_GLM_1Year) <- c("SME_GLM_in_sample", "DME_GLM_in_sample_init", "DME_GLM_in_sample", "sigmoid p", "sigmoid q", "DME_GLM_out_of_sample", "alpha0")


for (tt in c(T0:T1)){
  TT <- tt-2011+1
  # preparation of data
  dat.Obs     <- tensor[,2:(TT+1),1]             # indicator for observation yes/no
  index       <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT]==1)]  # only select active policies
  dat.Obs     <- tensor[index,2:(TT+1),1]        # observation yes/no
  dat.Expo    <- tensor[index,2:(TT+1),2]        # exposure
  dat.YY      <- tensor[index,2:(TT+1),3]        # claims
  dat.YY0     <- tensor[index,1:2,3]             # prepare tensor for claims: GLM
  dat.YY0[,1] <- rowSums(tensor[index,2:(TT),3]) # sum of past claims: GLM
  dat.YY0[,2] <- tensor[index,TT+1,3]            # actual claim
  dat.True    <- tensor[index,TT+1,4]            # true frequency
  dat.XX      <- tensor[index,2:(TT+1),GLM.XX]   # selected covariates
  dat.alpha   <- array(1, dim=c(nrow(tensor[index,,1]),1)) # prepare tensor for shape parameter
  Bias <- array(1, dim=length(index))
  Null <- array(0, dim=c(length(index), TT, 1))
  (muR <- sum(tensor[index,-1,3])/sum(tensor[index,-1,2]))
  # selection of GLM network
  (q0 <- dim(dat.XX)[3])
  seed <- 100 + TT - 1
  model <- GLM(seed, lookback=TT, q0, "exponential")
  path1 <- paste("./Networks/MixedGLM",seed,"_", tt,".h5", sep="")
  load_model_weights_hdf5(model, path1)
  w0 <- get_weights(model)
  pred <- (model %>% predict(list(dat.XX, dat.Expo, dat.alpha), batch_size=10^6))
  alpha <- pred[,TT+1]
  alpha0 <- alpha[1]
  pred <- pred[,1:TT]
  post.0  <- rowSums(pred[,1:(TT-1)])
  dat.YY0[,2] <- post.0   # this corresponds to sum_t v_t mu_t
  dat.YY0[which(dat.YY0[,2]>0),1] <- dat.YY0[which(dat.YY0[,2]>0),1]/dat.YY0[which(dat.YY0[,2]>0),2]
  post <- pred[,TT]*(post.0/(post.0+alpha)*dat.YY0[,1] + alpha/(post.0+alpha))
  (results_DME_GLM_1Year[tt-T0+1,1] <- round(NB.KL.divergence(dat.True, post, phi.star),4))
  ####
  init0 <- c(log(muR), log(alpha0), 1, 1)  # mu, alpha, p=sigmoid(), q=sigmoid()
  q0 <- c(TT, dim(dat.XX)[3])
  model <- GLM.partial.exposure(seed, q0, init0, train0=TRUE, train_pq=TRUE)
  w1 <- get_weights(model)
  w1[[3]] <- w0[[1]]
  w1[[4]] <- w0[[2]]
  set_weights(model, w1)
  pred <- (model %>% predict(list(dat.YY, dat.Expo, Bias, dat.XX, Null, Null, dat.Obs), batch_size=10^6))
  ###1) mu_t: t+1 (0=init) ###2) p_t: t+1 (0=init)  ###3) 3_t: t+1 (0=init) ###4) beta_t: t ###5) alpha_t: t
  post <- (pred[,TT,5]/pred[,TT,4]*pred[,TT+1,1])
  (results_DME_GLM_1Year[tt-T0+1,2] <- round(NB.KL.divergence(dat.True, post, phi.star),4))
  # one year ahead loss
  Q_loss0 <- function(y_true, y_pred){
       beta1    <- y_pred[,TT+1,4]  # beta_t+1 = q_t*(beta_t+v_t*mu_t)
       alpha1   <- y_pred[,TT,5]    # alpha_t
       mu1      <- y_pred[,TT+1,1]  # mu_t (0=init)
       q1       <- y_pred[,TT+1,3]  # q_t  (0=init), PS: p_t in position 2 is not needed
       NN1      <- y_true[,TT]      # the true is not shifted by 1
       -k_sum(+tf$math$lgamma(alpha1+NN1)-tf$math$lgamma(alpha1)+
           k_log((1-mu1*q1/beta1)^alpha1 * (mu1*q1/beta1)^NN1))
          }
  model %>% compile(loss = Q_loss0, optimizer = 'nadam')
  ###
  #{t1 <- proc.time()
  #     fit <- model %>% fit(list(dat.YY, dat.Expo, Bias, dat.XX, Null, Null, dat.Obs), dat.YY,
  #                batch_size=5000, epochs=1000, verbose=1)
  #(proc.time()-t1)[3]}
  #
  #plot(fit)
  path1 <- paste("./Networks/DME_GLM_PartialExpo",seed,"_",TT,".h5", sep="")
  #save_model_weights_hdf5(model, path1)
  load_model_weights_hdf5(model, path1)
  #
  pred <- (model %>% predict(list(dat.YY, dat.Expo, Bias, dat.XX, Null, Null, dat.Obs), batch_size=10^6))
  ###1) mu_t: t+1 (0=init) 2) p_t: t+1 (0=init) 3) 3_t: t+1 (0=init) 4) beta_t: t 5) alpha_t: t
  post <- (pred[,TT,5]/pred[,TT,4]*pred[,TT+1,1])
  (results_DME_GLM_1Year[tt-T0+1,3] <- round(NB.KL.divergence(dat.True, post, phi.star),4))
  w2 <- get_weights(model)
  (results_DME_GLM_1Year[tt-T0+1,4] <- k_eval(k_sigmoid(w2[[1]][1,1])))
  (results_DME_GLM_1Year[tt-T0+1,5] <- k_eval(k_sigmoid(w2[[2]][1,1])))
  (results_DME_GLM_1Year[tt-T0+1,7] <- pred[1,TT,5])
  ## out-of-sample
  dat.Obs    <- tensor[,2:(TT+2),1]
  index      <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT+1]==1)]
  dat.Obs    <- tensor[index,2:(TT+2),1]
  dat.Expo   <- tensor[index,2:(TT+2),2]
  dat.True   <- tensor[index,TT+2,4]
  dat.XX     <- tensor[index,2:(TT+2),GLM.XX]
  dat.YY     <- tensor[index,2:(TT+2),3]
  Null <- array(0, dim=c(length(index), TT+1, 1))
  dat.alpha   <- array(1, dim=c(nrow(tensor[index,,1]),1)) # prepare tensor for shape parameter
  Bias <- array(1, dim=length(index))
  qA <- c(TT+1, dim(dat.XX)[3])
  model <- GLM.partial.exposure(seed, qA, init0)
  wA <- get_weights(model)
  wA[[1]][1,1] <- w2[[1]][1,1]
  wA[[2]][1,1] <- w2[[2]][1,1]
  wA[[3]] <- w2[[3]]
  wA[[4]] <- w2[[4]]
  wA[[5]] <- w2[[5]]
  set_weights(model, wA)
  pred <- (model %>% predict(list(dat.YY, dat.Expo, Bias, dat.XX, Null, Null, dat.Obs), batch_size=10^6))
  ###1) mu_t: t+1 (0=init) 2) p_t: t+1 (0=init) 3) 3_t: t+1 (0=init) 4) beta_t: t 5) alpha_t: t
  post <- (pred[,TT+1,5]/pred[,TT+1,4]*pred[,TT+2,1])
  (results_DME_GLM_1Year[tt-T0+1,6] <- round(NB.KL.divergence(dat.True, post, phi.star),4))
   }


#plot(fit)
#save(data=results_DME_GLM_1Year, file="../Results/results_DME_GLM_1Year.rda")

results_DME_GLM_1Year


######################

load(file="../Results/results_GLM.rda")
load(file="../Results/results_SME_GLM_1Year.rda")
load(file="../Results/results_DME_GLM_1Year.rda")


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch4/DME_KL_in_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
ylim0 <- range(0,0.28)
stats <- 3
plot(x=c(T0:T1), y=results_GLM[,stats], col="blue", type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                  main=list("dynamic mixed effects: KL divergence T", cex=1.5))
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,1], col="pink", lwd=2)
lines(x=c(T0:T1), y=results_DME_GLM_1Year[,stats], col="red", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,1], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_DME_GLM_1Year[,stats], col="red", pch=20, cex=3)
legend(x="bottomleft", cex=1.5, lty=c(1,1,1), lwd=2, pch=20, col=c("blue", "pink", "red"), legend=c("GLM", "SME GLM (b)", "DME GLM (b)"))
if (pdf.plot==1){dev.off()}


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch4/DME_KL_out_of_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 6
plot(x=c(T0:T1), y=results_GLM[,stats], col="blue", type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                   main=list("dynamic mixed effects: KL divergence T+1", cex=1.5))
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,3], col="pink", lwd=2)
lines(x=c(T0:T1), y=results_DME_GLM_1Year[,stats], col="red", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,3], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_DME_GLM_1Year[,stats], col="red", pch=20, cex=3)
legend(x="bottomleft", cex=1.5, lty=c(1,1,1), lwd=2, pch=-1, col=c("blue", "pink", "red"), legend=c("GLM", "SME GLM (b)", "DME GLM (b)"))
if (pdf.plot==1){dev.off()}


#########################################################################

results_DME_GLM_1Year

pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch4/DME_KL_pq.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
plot(x=c(T0:T1), y=results_DME_GLM_1Year[,4] , ylim=c(0,1), col="blue", type='l', lwd=2,
             xlab="learning sample", ylab="values", cex.lab=1.5,
                   main=list("dynamic mixed effects: p and q values", cex=1.5))
lines(x=c(T0:T1), y=results_DME_GLM_1Year[,5], col="orange", lwd=2)
lines(x=c(T0:T1), y=results_DME_GLM_1Year[,7], col="darkgray", lwd=2)
points(x=c(T0:T1), y=results_DME_GLM_1Year[,4], col="blue", pch=20, cex=3)
points(x=c(T0:T1), y=results_DME_GLM_1Year[,5], col="orange", pch=20, cex=3)
points(x=c(T0:T1), y=results_DME_GLM_1Year[,7], col="darkgray", pch=20, cex=3)
abline(h=c(mean(results_DME_GLM_1Year[,4]), mean(results_DME_GLM_1Year[,5]), mean(results_DME_GLM_1Year[,7])), lty=2, col=c("blue","orange", "darkgray"))
legend(x="left", cex=1.5, lty=c(1,1,1), lwd=2, pch=20, col=c("blue", "orange", "darkgray"), legend=c("p values", "q values", "alpha_1"))
if (pdf.plot){dev.off()}

round(colMeans(results_DME_GLM_1Year[,c(4,5,7)]),2)

(alpha1 <- round(results_DME_GLM_1Year[5,7],2))

#########################################################################

prior.weight <- function(t, p, q, AlphaMu){
      tt <- c(1:t)
      1-q^(1-tt)*p*(1-(p*q)^tt)/(1-p*q)/(q^(1-tt)*(1-q^tt)/(1-q)+AlphaMu)
      }

mu1 <- rev(c(2:15)/100)
col0 <- rev(rainbow(n=length(mu1), start=0.5, end=.75))

(p1 <- round(results_DME_GLM_1Year[5,4],2))
(q1 <- round(results_DME_GLM_1Year[5,5],2))

plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(pathPlot, "/Ch4/PriorWeightDME.pdf", sep="")
if (plot.yes){pdf(file=filey1)}
plot(x=c(0:30), y=c(1,prior.weight(30, p1, q1, alpha1/mu1[1])), type='l', lwd=2, ylab="credibility weight", col=col0[1], xlab="years of observations t", main=list(paste("weight on prior for p=",p1," and q=", q1, sep=""), cex=1.5), cex.lab=1.5)
for (j in 2:length(mu1)){lines(x=c(0:30), y=c(1,prior.weight(30, p1, q1, alpha1/mu1[j])), col=col0[j])}
legend(x="topright", cex=1.5, lty=c(1,1), lwd=2, pch=-1, col=col0[c(length(mu1), 1)], legend=c("v_t*mu_t=2%", "v_t*mu_t=15%"))
if (plot.yes){dev.off()}


(p1 <- .8)
(q1 <- round(results_DME_GLM_1Year[5,5],2))

filey1 <- paste(pathPlot, "/Ch4/PriorWeightDMEA.pdf", sep="")
if (plot.yes){pdf(file=filey1)}
plot(x=c(0:30), y=c(1,prior.weight(30, p1, q1, alpha1/mu1[1])), type='l', lwd=2, ylab="credibility weight", col=col0[1], xlab="years of observations t", main=list(paste("weight on prior for p=",p1," and q=", q1, sep=""), cex=1.5), cex.lab=1.5)
for (j in 2:length(mu1)){lines(x=c(0:30), y=c(1,prior.weight(30, p1, q1, alpha1/mu1[j])), col=col0[j])}
legend(x="topright", cex=1.5, lty=c(1,1), lwd=2, pch=-1, col=col0[c(length(mu1), 1)], legend=c("v_t*mu_t=2%", "v_t*mu_t=15%"))
if (plot.yes){dev.off()}

(p1 <- round(results_DME_GLM_1Year[5,4],2))
(q1 <- .25)

filey1 <- paste(pathPlot, "/Ch4/PriorWeightDMEB.pdf", sep="")
if (plot.yes){pdf(file=filey1)}
plot(x=c(0:30), y=c(1,prior.weight(30, p1, q1, alpha1/mu1[1])), type='l', lwd=2, ylab="credibility weight", col=col0[1], xlab="years of observations t", main=list(paste("weight on prior for p=",p1," and q=", q1, sep=""), cex=1.5), cex.lab=1.5)
for (j in 2:length(mu1)){lines(x=c(0:30), y=c(1,prior.weight(30, p1, q1, alpha1/mu1[j])), col=col0[j])}
legend(x="topright", cex=1.5, lty=c(1,1), lwd=2, pch=-1, col=col0[c(length(mu1), 1)], legend=c("v_t*mu_t=2%", "v_t*mu_t=15%"))
if (plot.yes){dev.off()}



#########################################################################
## individual policies
#########################################################################

tt <- 2019    # last year of observations (models have only fitted up to 2018)
TT <- tt-2011+1
# preparation of data
dat.Obs     <- tensor[,2:(TT+1),1]             # indicator for observation yes/no
index       <- c(1:nrow(dat.Obs))[rowSums(dat.Obs)==TT]  # only select active policies
dat.Obs     <- tensor[index,2:(TT+1),1]        # observation yes/no
dat.Expo    <- tensor[index,2:(TT+1),2]        # exposure
dat.YY      <- tensor[index,2:(TT+1),3]        # claims
dat.True    <- tensor[index,TT+1,4]            # true frequency
dat.XX      <- tensor[index,2:(TT+1),GLM.XX]   # selected covariates
dat.alpha   <- array(1, dim=c(nrow(tensor[index,,1]),1)) # prepare tensor for shape parameter
Bias <- array(1, dim=length(index))
Null <- array(0, dim=c(length(index), TT, 1))
(muR <- sum(tensor[index,-1,3])/sum(tensor[index,-1,2]))
# selection of GLM network
seed <- 100 + TT - 2
init0 <- c(log(muR), log(.25), 1, 1)  # mu, alpha, p=sigmoid(), q=sigmoid()
## select last fitted network, year 2018
(q0 <- c(TT-1, dim(dat.XX)[3]))
model <- GLM.partial.exposure(seed, q0, init0, train0=TRUE, train_pq=TRUE)
path1 <- paste("./Networks/DME_GLM_PartialExpo",seed,"_",TT-1,".h5", sep="")
load_model_weights_hdf5(model, path1)
w2 <- get_weights(model)
## select model up to 2019
qA <- c(TT, dim(dat.XX)[3])
model <- GLM.partial.exposure(seed, qA, init0)
wA <- get_weights(model)
wA[[1]][1,1] <- w2[[1]][1,1]
wA[[2]][1,1] <- w2[[2]][1,1]
wA[[3]] <- w2[[3]]
wA[[4]] <- w2[[4]]
wA[[5]] <- w2[[5]]
set_weights(model, wA)
pred <- (model %>% predict(list(dat.YY, dat.Expo, Bias, dat.XX, Null, Null, dat.Obs), batch_size=10^6))
###1) mu_t: t+1 (0=init) 2) p_t: t+1 (0=init) 3) 3_t: t+1 (0=init) 4) beta_t: t 5) alpha_t: t
mu_t <- pred[,2:TT+1,1]



col0 <- rev(rainbow(n=3, start=0.5, end=.75))

Id <- c(1, 6)
plot(x=c((T0-2):(T1+1)), y=pred[Id[1],3:(TT+1),1], type='l', lwd=2, ylim=range(pred[Id[1],2:(TT+1),1],pred[Id[2],2:(TT+1),1],0),ylab="v_t*mu_t", col=col0[1], xlab="calendar year", main=list(paste("behavior of three selected policies", sep=""), cex=1.5), cex.lab=1.5)
lines(x=c((T0-2):(T1+1)), y=pred[Id[2],3:(TT+1),1], lwd=2, col=col0[2])


post <- array(NA, dim=c(TT+1,2,TT-1))

for (jj in 0:TT){
  dat.XX0      <- dat.XX[Id,,]
  dat.Obs0     <- dat.Obs[Id,]
  dat.Expo0    <- dat.Expo[Id,]
  dat.YY0      <- array(0,dim=dim(dat.YY[Id,]))
  if (jj>0){dat.YY0[,jj] <- 1}
  dat.alpha0   <- dat.alpha[Id,]
  Bias0        <- Bias[Id]
  Null0        <- Null[Id,,]
  pred0 <- (model %>% predict(list(dat.YY0, dat.Expo0, Bias0, dat.XX0, Null0, Null0, dat.Obs0), batch_size=10^6))
  post[jj+1,,] <- (pred0[,1:TT,5]/pred0[,1:TT,4]*pred0[,2:(TT+1),1])[,-1]
                    }

col0 <- rev(rainbow(n=TT+1, start=0.25, end=.75))
pol <- 2

plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(pathPlot, "/Ch4/3Policy_",pol,".pdf", sep="")
if (plot.yes){pdf(file=filey1)}
plot(x=c((T0-2):(T1+1)), y=post[1,pol,], type='l', lwd=2, ylim=range(post[,pol,]),ylab="experience rating price", col=col0[1], xlab="calendar year", main=list(paste("experience rating of selected insurance policy", sep=""), cex=1.5), cex.lab=1.5)
for (jj in rev(1:TT)){
     lines(x=c((T0-2):(T1+1)), y=post[jj+1,pol,], lwd=1, col=col0[jj])
     points(x=c((T0-2):(T1+1)), y=post[jj+1,pol,], pch=20, cex=2, col=col0[jj])
     }
lines(x=c((T0-2):(T1+1)), y=post[1,pol,], lwd=2, col=col0[1])
if (plot.yes){dev.off()}

