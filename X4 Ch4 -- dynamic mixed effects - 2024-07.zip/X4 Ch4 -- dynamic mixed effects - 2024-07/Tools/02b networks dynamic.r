####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Neural network definitions
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(keras)
library(tensorflow)

#=====================================================
# loss functions and plots
#=====================================================

plot.loss <- function(pos0, loss, title0, ylim0, col0){
    plot(loss$val_loss, col=col0[2], ylim=ylim0, main=list(title0, cex=1.5),xlab="training epochs", ylab="(modified) deviance loss", cex=1.5, cex.lab=1.5)
    lines(loss$loss,col=col0[1])
    abline(v=which.min(fit[[2]]$val_loss), col=col0[3])
    legend(x=pos0, cex=1.5, col=col0, lty=c(1,-1,1), lwd=c(1,-1,1), pch=c(-1,1,-1), legend=c("training loss", "validation loss", "minimal validation loss"))
   }

#=====================================================
# special layer functions
#=====================================================


BetaAlphaCell(keras$layers$Layer) %py_class% {
  # This code is based on "Working with RNNs", date rendered 2022-12-16
  # Authors Scott Zhu, Francois Chollet, Tomasz Kalinowski
  # https://tensorflow.rstudio.com/guides/keras/working_with_rnns
  initialize <- function(unit_1, unit_2, ...) {
    self$unit_1      <- unit_1
    self$unit_2      <- unit_2
    self$state_size  <- list(shape(unit_1), shape(unit_2))
    self$output_size <- list(shape(unit_1), shape(unit_2))
    super$initialize(...)
  }

  call <- function(inputs, states) {
    c(input_1, input_2, input_3, input_4) %<-% tf$nest$flatten(inputs)
    c(s1, s2) %<-% states
    # beta sequence
    output_1 <- input_1 * (s1 + input_2)
    state_1  <- output_1
    # alpha sequence
    output_2 <- input_3 * input_1 * (s2 + input_4) + (1-input_3) * output_1
    state_2  <- output_2
    #
    output <- tuple(output_1, output_2)
    new_states <- tuple(state_1, state_2)
    tuple(output, new_states)
  }

  get_config <- function() {
    list("unit_1" = self$unit_1, "unit_2" = self$unit_2)
  }
}


#=====================================================
# network for dynamic random effects null model: full exposures only
#=====================================================


network.null.model <- function(seed, q0, init0){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    NN      = layer_input(shape = c(q0[1]), dtype = 'float32')
    bias1   = layer_input(shape = c(1), dtype = 'float32')
    mu0     = layer_input(shape = c(q0[1],1), dtype = 'float32')
    timep   = layer_input(shape = c(q0[1],1), dtype = 'float32')
    timeq   = layer_input(shape = c(q0[1],1), dtype = 'float32')
    # initialize alpha and set it to position N0 in the claims
    alpha1   = bias1 %>% layer_dense(units=1, use_bias=FALSE, activation="exponential",
                                    weights=list(array(init0[2], dim=c(1,1))))
    NN1     = list(alpha1, NN) %>% layer_concatenate() %>% layer_reshape(target_shape=c(q0[1]+1,1))
    # initilize pt and set 1 in position p0
    # if pt is time dependent it is modeled categorically through embeddings
    p       = timep %>% layer_embedding(input_dim = q0[1], output_dim = 1, input_length = 1,
                        weights=list(array(init0[3], dim=c(q0[1],1)))) %>% layer_flatten() %>%
                        layer_lambda(function(x) k_sigmoid(x)) %>% layer_reshape(target_shape=c(q0[1]))
    p1      = list(bias1, p) %>% layer_concatenate() %>% layer_reshape(target_shape=c(q0[1]+1,1))
    # initilize qt and set 1 in position q0
    # if qt is time dependent it is modeled categorically through embeddings
    q       = timeq %>% layer_embedding(input_dim = q0[1], output_dim = 1, input_length = 1,
                        weights=list(array(init0[4], dim=c(q0[1],1)))) %>% layer_flatten() %>%
                        layer_lambda(function(x) k_sigmoid(x)) %>% layer_reshape(target_shape=c(q0[1]))
    q1      = list(bias1, q) %>% layer_concatenate() %>% layer_reshape(target_shape=c(q0[1]+1,1))
    # initialize vt*mu0 and set alpha1=beta1 in position 0
    mu  = mu0 %>% layer_embedding(input_dim = q0[1], output_dim = 1, input_length = 1,
                        weights=list(array(init0[1], dim=c(q0[1],1)))) %>% layer_flatten() %>%
                        layer_lambda(function(x) k_exp(x)) %>% layer_reshape(target_shape=c(q0[1]))
    mu1 = list(alpha1, mu) %>% layer_concatenate() %>% layer_reshape(target_shape=c(q0[1]+1,1))
    #
    cell    = BetaAlphaCell(1, 1)
    rnn     = layer_rnn(cell = cell, return_sequence=TRUE)
    Network = rnn(tuple(q1, mu1, p1, NN1)) %>% layer_concatenate()
    outputs = list(mu1, p1, q1, Network) %>% layer_concatenate()
    #
    keras_model(inputs = c(NN, bias1, mu0, timep, timeq), outputs = list(outputs))
    }


#=====================================================
# dynamic mixed effects FNN model: full exposures only
#=====================================================


network.regression.model <- function(seed, q0, cat0, bb, init0){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    NN      = layer_input(shape = c(q0[1]), dtype = 'float32')
    Expo1   = layer_input(shape = c(q0[1]), dtype = 'float32')
    bias1   = layer_input(shape = c(1), dtype = 'float32')
    XX0     = layer_input(shape = c(q0[1],q0[2]), dtype = 'float32')
    Cat0    = layer_input(shape = c(q0[1],1), dtype = 'int32')
    timep   = layer_input(shape = c(q0[1],1), dtype = 'float32')
    timeq   = layer_input(shape = c(q0[1],1), dtype = 'float32')
    #
    alpha1  = bias1 %>% layer_dense(units=1, use_bias=FALSE, activation="exponential",
                                    weights=list(array(init0[2], dim=c(1,1))))
    NN1     = list(alpha1, NN) %>% layer_concatenate() %>% layer_reshape(target_shape=c(q0[1]+1,1))
    #
    p       = timep %>% layer_embedding(input_dim = q0[1], output_dim = 1, input_length = 1,
                        weights=list(array(init0[3], dim=c(q0[1],1)))) %>% layer_flatten() %>%
                        layer_lambda(function(x) k_sigmoid(x)) %>% layer_reshape(target_shape=c(q0[1]))
    p1      = list(bias1, p) %>% layer_concatenate() %>% layer_reshape(target_shape=c(q0[1]+1,1))
    #
    q       = timeq %>% layer_embedding(input_dim = q0[1], output_dim = 1, input_length = 1,
                        weights=list(array(init0[4], dim=c(q0[1],1)))) %>% layer_flatten() %>%
                        layer_lambda(function(x) k_sigmoid(x)) %>% layer_reshape(target_shape=c(q0[1]))
    q1      = list(bias1, q) %>% layer_concatenate() %>% layer_reshape(target_shape=c(q0[1]+1,1))
    #
    Emb0 = Cat0 %>%
      time_distributed(layer_embedding(input_dim = cat0[1], output_dim = bb[1], input_length = 1)) %>%
      layer_reshape(target_shape=c(q0[1],bb[1]))
    #
    mu      = list(XX0, Emb0) %>% layer_concatenate() %>%
                      time_distributed(layer_dense(units=q0[3], activation='tanh')) %>%
                      time_distributed(layer_dense(units=q0[4], activation='tanh')) %>%
                      time_distributed(layer_dense(units=q0[5], activation='tanh')) %>%
                      time_distributed(layer_dense(units=1, activation='exponential',
                         weights=list(array(0,dim=c(q0[5],1)), array(init0[1], dim=c(1))))) %>%
                      layer_reshape(target_shape=c(q0[1]))
    #
    mu0     = list(mu, Expo1) %>% layer_multiply()
    mu1     = list(alpha1, mu0) %>% layer_concatenate() %>% layer_reshape(target_shape=c(q0[1]+1,1))
    #
    cell    = BetaAlphaCell(1, 1)
    rnn     = layer_rnn(cell = cell, return_sequence=TRUE)
    Network = rnn(tuple(q1, mu1, p1, NN1)) %>% layer_concatenate()
    outputs = list(mu1, p1, q1, Network) %>% layer_concatenate()
    #
    keras_model(inputs = c(NN, Expo1, bias1, XX0, Cat0, timep, timeq), outputs = list(outputs))
    }


#=====================================================
# dynamic mixed effects GLM: partial exposures
#=====================================================


GLM.partial.exposure <- function(seed, q0, init0, train0=TRUE, train_pq=TRUE){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    NN      = layer_input(shape = c(q0[1]), dtype = 'float32')
    Expo1   = layer_input(shape = c(q0[1]), dtype = 'float32')
    bias1   = layer_input(shape = c(1), dtype = 'float32')
    XX0     = layer_input(shape = c(q0[1],q0[2]), dtype = 'float32')
    timep   = layer_input(shape = c(q0[1],1), dtype = 'float32')
    timeq   = layer_input(shape = c(q0[1],1), dtype = 'float32')
    Obs     = layer_input(shape = c(q0[1]), dtype = 'float32')
    #
    alpha1  = bias1 %>% layer_dense(units=1, use_bias=FALSE, activation="exponential",
                                    weights=list(array(init0[2], dim=c(1,1))))
    NN1     = list(alpha1, NN) %>% layer_concatenate() %>% layer_reshape(target_shape=c(q0[1]+1,1))
    #
    p0      = timep %>% layer_embedding(input_dim = q0[1], output_dim = 1, input_length = 1, trainable=train_pq,
                        weights=list(array(init0[3], dim=c(q0[1],1)))) %>% layer_flatten() %>%
                        layer_lambda(function(x) k_sigmoid(x)) %>% layer_reshape(target_shape=c(q0[1]))
    p       = p0 + (1-p0) * (1-Obs)  # let's p=1 for periods without observations
    p1      = list(bias1, p) %>% layer_concatenate() %>% layer_reshape(target_shape=c(q0[1]+1,1))
    #
    q00     = timeq %>% layer_embedding(input_dim = q0[1], output_dim = 1, input_length = 1, trainable=train_pq,
                        weights=list(array(init0[4], dim=c(q0[1],1)))) %>% layer_flatten() %>%
                        layer_lambda(function(x) k_sigmoid(x)) %>% layer_reshape(target_shape=c(q0[1]))
    q       = q00 + (1-q00) * (1-Obs) # let's q=1 for periods without observations
    q1      = list(bias1, q) %>% layer_concatenate() %>% layer_reshape(target_shape=c(q0[1]+1,1))
    # GLM layer -> can be extended to FNN architecture
    mu      = XX0 %>%
              time_distributed(layer_dense(units=1, activation='exponential', trainable=train0,
                  weights=list(array(0,dim=c(q0[2],1)), array(init0[1], dim=c(1))))) %>%
                  layer_reshape(target_shape=c(q0[1]))
    #
    mu0     = list(mu, Expo1) %>% layer_multiply()
    mu1     = list(alpha1, mu0) %>% layer_concatenate() %>% layer_reshape(target_shape=c(q0[1]+1,1))
    #
    cell    = BetaAlphaCell(1, 1)
    rnn     = layer_rnn(cell = cell, return_sequence=TRUE)
    Network = rnn(tuple(q1, mu1, p1, NN1)) %>% layer_concatenate()
    outputs = list(mu1, p1, q1, Network) %>% layer_concatenate()
    #
    keras_model(inputs = c(NN, Expo1, bias1, XX0, timep, timeq, Obs), outputs = list(outputs))
    }


