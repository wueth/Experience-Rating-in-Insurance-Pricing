####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Dynamic random effects: null model with unit exposures
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(arrow)
library(tidyverse)

pathPlot <- "../../Plots/"

####################################################################################
### load and pre-process data
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic

labelGLM <- c("ClaimNb", "True", "DrivAgeX", "GenderX", "LeasingX",
            "LowMileageX", "CatPriceX", "DeductibleX",
            "DurationX", "YearX",
            paste("VA", c(2:8), sep=""), paste("Re", c(2:15), sep=""),
            paste("Year", c(2:9), sep=""))

source("./Tools/01a static mixed effects - load data GLM.r")

tensor <- tensorGLM
dim(tensor)
tensor[1:4,,1]

### extract only policies with full exposures over the entire period
tensor[,1,1] <- rowSums(tensor[,-1,1])
YY <- tensor[which(tensor[,1,1]==9),-1,3]

###
(TT <- ncol(YY)) # number of years
tt <- c(1:TT)    # list of all years
(muR <- mean(colMeans(YY))) # empirical frequency


####################################################################################
### set parameters and define loss functions
####################################################################################

NB.KL.divergence <- function(true, est, phi){100*mean(true*(log(true/est)-phi/(phi-1)*log(phi/((phi-1)*est/true+1))))}

phi.star <- 1.3

####################################################################################
#########  dynamics random effects null model
####################################################################################

## encode a lower triangular matrix on the log-scale for (p*q)^t = exp(t*log(p*q))
## the upper-left triangle is set to a very large number
A <- matrix(10^10, nrow=TT, ncol=TT)
for (t0 in 1:TT){for (s0 in 1:t0){A[t0,s0] <- t0-s0+1}} # power parameter in lower triangular matrix


#==========================================================
### the bounded variance case p in (0,1) and q in (0,1)
#==========================================================


neg.LogLikeli.bounded <- function(param){
      ## set parameters to be optimized
      mu0     <- exp(param[1])    # mu0 must be positive -> model on log-scale
      alpha10 <- exp(param[2])    # alpha_{1} must be positive -> model on log-scale
      p <- 1/(1+exp(-param[3]))   # p0 = log(1/p-1) sigmoid/logit for (0,1)
      q <- 1/(1+exp(-param[4]))   # q0 = log(1/q-1) sigmoid/logit for (0,1)
      ## scale parameter
      betat <- alpha10*q^tt + mu0*q*(1-q^tt)/(1-q)
      ## observation independent part of shape parameter
      alpha1 <- alpha10*q^tt+(1-p)*mu0*q/(1-q)*((1-(p*q)^tt)/(1-p*q)-q^tt*(1-p^tt)/(1-p))
      ## observation dependent part of shape parameter
      B <- exp(log(p*q)* A)
      ## merge the two for receiving alpha_2:TT+1
      alphat <- B %*% t(YY) + alpha1
      ## shift to alpha_1:TT by applying alpha_t+1 = p*q*(alpha_t+N_t)+(1-p)*beta_t+1
      alphat <- (alphat-(1-p)*betat)/(p*q)-t(YY)
      ## negative binomial log-likelihood
      -sum(lgamma(alphat+t(YY))-lgamma(alphat)+
          log((1-mu0*q/betat)^alphat*(mu0*q/betat)^t(YY))-lgamma(t(YY)+1))
      }


#param =(mu0, alpha10, p, q) initialize
param0 <- c(log(muR), log(.5), log(3-1), log(3-1))
# convergence 0 is successful
(paramB <- optim(par=param0, fn=neg.LogLikeli.bounded))
paramB <- paramB$par
round(bounded <- c(exp(paramB[1]), exp(paramB[2]), 1/(1+exp(-paramB[3])), 1/(1+exp(-paramB[4]))),4)

round(-neg.LogLikeli.bounded(paramB)/nrow(YY),4)
2*neg.LogLikeli.bounded(paramB) + 2*length(paramB)


#==========================================================
### the increasing variance case p = 1 and q in (0,1)
#==========================================================


neg.LogLikeli.increasing <- function(param){
      ## set parameters to be optimized
      mu0  <- exp(param[1])        # mu0 must be positive -> model on log-scale
      alpha10  <- exp(param[2])    # alpha_{1} must be positive -> model on log-scale
      q <- 1/(1+exp(-param[3]))    # q0 = log(1/q-1) sigmoid/logit for (0,1)
      ## scale parameter
      betat <- alpha10*q^tt + mu0*q*(1-q^tt)/(1-q)
      ## observation independent part of shape parameter
      alpha1 <- alpha10*q^tt
      ## observation dependent part of shape parameter
      B <- exp(log(q)* A)
      ## merge the two for receiving alpha_2:TT+1
      alphat <- B %*% t(YY) + alpha1
      ## shift to alpha_1:TT
      alphat <- alphat/q-t(YY)
      ## negative binomial log-likelihood
      -sum(lgamma(alphat+t(YY))-lgamma(alphat)+
           log((1-mu0*q/betat)^alphat*(mu0*q/betat)^t(YY))-lgamma(t(YY)+1))
      }



#param =(mu0, alpha10, p, q) initialize
param0 <- c(log(muR), log(.5), log(3-1))
# convergence 0 is successful
(paramB <- optim(par=param0, fn=neg.LogLikeli.increasing))
paramB <- paramB$par
round(bounded <- c(exp(paramB[1]), exp(paramB[2]), 1, 1/(1+exp(-paramB[3]))),4)

round(-neg.LogLikeli.increasing(paramB)/nrow(YY),4)
2*neg.LogLikeli.increasing(paramB) + 2*length(paramB)


#==========================================================
### the decreasing variance case p in (0,1) and q = 1
#==========================================================


neg.LogLikeli.decreasing <- function(param){
      ## set parameters to be optimized
      mu0  <- exp(param[1])        # mu0 must be positive -> model on log-scale
      alpha10  <- exp(param[2])    # alpha_{1} must be positive -> model on log-scale
      p <- 1/(1+exp(-param[3]))    # p0 = log(1/p-1) sigmoid/logit for (0,1)
      ## scale parameter
      betat <- alpha10 + mu0*tt
      ## observation independent part of shape parameter
      alpha1 <- alpha10+mu0*tt - mu0*p*(1-p^tt)/(1-p)
      ## observation dependent part of shape parameter
      B <- exp(log(p)* A)
      ## merge the two for receiving alpha_2:TT+1
      alphat <- B %*% t(YY) + alpha1
      ## shift to alpha_1:TT
      alphat <- (alphat-(1-p)*betat)/p-t(YY)
      ## negative binomial log-likelihood
      -sum(lgamma(alphat+t(YY))-lgamma(alphat)+
          log((1-mu0/betat)^alphat*(mu0/betat)^t(YY))-lgamma(t(YY)+1))
      }



#param =(mu0, alpha10, p, q) initialize
param0 <- c(log(muR), log(.5), log(3-1))
# convergence 0 is successful
(paramB <- optim(par=param0, fn=neg.LogLikeli.decreasing))
paramB <- paramB$par
round(bounded <- c(exp(paramB[1]), exp(paramB[2]), 1/(1+exp(-paramB[3])),1),4)

round(-neg.LogLikeli.decreasing(paramB)/nrow(YY),4)
2*neg.LogLikeli.decreasing(paramB) + 2*length(paramB)


#==========================================================
### shared common effects case p = 1 and q = 1
#==========================================================


neg.LogLikeli.common <- function(param){
      ## set parameters to be optimized
      mu0      <- exp(param[1])    # mu must be positive -> model on log-scale
      alpha10  <- exp(param[2])    # alpha_{1|0} must be positive -> model on log-scale
      ## negative binomial log-likelihood with static gamma latent factor
      -(sum(lgamma(alpha10+YA)-lgamma(alpha10)+
          log((alpha10/(T0*mu0+alpha10))^alpha10 *
             (mu0/(T0*mu0+alpha10))^YA))-sum(lgamma(YY+1)))
      }

YA <- rowSums(YY)
T0 <- ncol(YY)



#param =(lambda, beta10, p, q) initialize
param0 <- c(log(muR), log(.5))
# convergence 0 is successful
(paramB <- optim(par=param0, fn=neg.LogLikeli.common))
paramB <- paramB$par
round(bounded <- c(exp(paramB[1]), exp(paramB[2]),1,1),4)

round(-neg.LogLikeli.common(paramB)/nrow(YY),4)
2*neg.LogLikeli.common(paramB) + 2*length(paramB)
