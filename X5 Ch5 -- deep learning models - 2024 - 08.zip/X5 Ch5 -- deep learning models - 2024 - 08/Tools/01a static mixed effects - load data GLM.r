####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Static mixed effects: data preprocessing GLM
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(arrow)
library(tidyverse)

####################################################################################
### functions for data pre-processing
####################################################################################

PreProcess.CatDummy <- function(var1, short, dat2){
   names(dat2)[names(dat2) == var1]  <- "V1"
   n2 <- ncol(dat2)
   dat2$X <- as.integer(dat2$V1)
   n0 <- length(unique(dat2$X))
   for (n1 in 2:n0){dat2[, paste(short, n1, sep="")] <- as.integer(dat2$X==n1)}
   names(dat2)[names(dat2) == "V1"]  <- var1
   dat2[, c(1:n2,(n2+2):ncol(dat2))]
   }

PreProcess.Continuous <- function(var1, dat2){
   names(dat2)[names(dat2) == var1]  <- "V1"
   dat2$X <- as.numeric(dat2$V1)
   dat2$X <- (dat2$X-mean(dat2$X))/sd(dat2$X)
   names(dat2)[names(dat2) == "V1"]  <- var1
   names(dat2)[names(dat2) == "X"]  <- paste(var1,"X", sep="")
   dat2
   }

Features.PreProcess.Embedding <- function(dat2){
   dat2 <- PreProcess.Continuous("DrivAge", dat2)
   dat2$GenderX <- as.integer(dat2$Gender)-1
   dat2$LeasingX <- as.integer(dat2$Leasing)
   dat2$LowMileageX <- as.integer(dat2$LowMileage)
   dat2$RegionX <- as.integer(dat2$Region)-1
   dat2 <- PreProcess.Continuous("CatPrice", dat2)
   dat2 <- PreProcess.Continuous("VehAge", dat2)
   dat2$DeductibleX <- as.integer(as.factor(dat2$Deductible))
   dat2$Duration <- dat2$Year-dat2$StartYear
   dat2 <- PreProcess.Continuous("Duration", dat2)
   dat2 <- PreProcess.Continuous("Year", dat2)
   dat2$YearCatNN <- as.integer(dat2$YearCatGLM)-1
   dat2
    }


####################################################################################
### load and pre-process the data for GLMs
####################################################################################

dat$VehAgeGLM   <- as.factor(cut(dat$VehAge, c(-1,0,1,2,3,4,9,12, 21),
                       labels = c("0","1","2","3","4", "5-9", "10-12", "13+"),
                       include.lowest = TRUE))

dat$YearCatGLM <- as.factor(dat$Year)

dat <- PreProcess.CatDummy("VehAgeGLM", "VA", dat)
dat <- PreProcess.CatDummy("Region", "Re", dat)
dat <- PreProcess.CatDummy("YearCatGLM", "Year", dat)

dat <- Features.PreProcess.Embedding(dat)


####################################################################################
### encode the covariates in tensors
####################################################################################

T0 <- 2011
T1 <- 2019

panel.data <- function(label, dat2){
    dat2$xx <- dat2[,label]
    xx <- data.frame(dat2 %>% select(PolicyID, Year, xx) %>%
        pivot_wider(names_from="Year", names_prefix="Yr", values_from="xx"))
    for (tt in T0:T1){
         col1 <- paste("Yr", tt, sep="")
         xx[is.na(xx[,col1]),col1] <- 0
         }
   xx
   }


## concatenate data to panel data by building the corresponding tensors
Exposure     <- panel.data("Exposure", dat)
ObsIndicator <- Exposure
for (tt in T0:T1){
         col1 <- paste("Yr", tt, sep="")
         ObsIndicator[,col1] <- as.integer(ObsIndicator[,col1]>0)
         }

# generate data tensor
tensorGLM <- array(NA, dim=c(dim(Exposure), 2+length(labelGLM)))
tensorGLM[,,1] <- as.matrix(ObsIndicator)
tensorGLM[,,2] <- as.matrix(Exposure)
for (jj in 1:length(labelGLM)){
      xx <- panel.data(labelGLM[jj], dat)
      tensorGLM[,,jj+2] <- as.matrix(xx)
      }

# randomize order for stochastic gradient descent
set.seed(200)
index      <- sample(c(1:nrow(tensorGLM[,,1])), size=nrow(tensorGLM[,,1]))
tensorGLM   <- tensorGLM[index,,]
