####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Neural network definition(s)
#########  Author: Mario Wuthrich
#########  Version August 2024
####################################################################################

library(keras)
library(tensorflow)

#=====================================================
# loss functions and plots
#=====================================================

plot.loss <- function(pos0, loss, title0, ylim0, col0){
    plot(loss$val_loss, col=col0[2], ylim=ylim0, main=list(title0, cex=1.5),xlab="training epochs", ylab="(modified) deviance loss", cex=1.5, cex.lab=1.5)
    lines(loss$loss,col=col0[1])
    abline(v=which.min(fit[[2]]$val_loss), col=col0[3])
    legend(x=pos0, cex=1.5, col=col0, lty=c(1,-1,1), lwd=c(1,-1,1), pch=c(-1,1,-1), legend=c("training loss", "validation loss", "minimal validation loss"))
   }

#=====================================================
# plain-vanilla neural network
#=====================================================


####
network.embedding <- function(seed, q0, lambda0, cat0, bb, output.acti){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    Design   <- layer_input(shape = c(q0[1]), dtype = 'float32')
    Cat0     <- layer_input(shape = c(1), dtype = 'int32')
    Exposure <- layer_input(shape = c(1), dtype = 'float32')
    #
    CatEmb0 = Cat0 %>%
      layer_embedding(input_dim = cat0[1], output_dim = bb[1], input_length = 1) %>%
      layer_flatten()
    #
    Network = list(Design, CatEmb0) %>% layer_concatenate() %>%
          layer_dense(units=q0[2], activation='tanh') %>%
          layer_dense(units=q0[3], activation='tanh') %>%
          layer_dense(units=q0[4], activation='tanh') %>%
          layer_dense(units=1, activation=output.acti,
                    weights=list(array(0, dim=c(q0[4],1)), array(log(lambda0), dim=c(1))))
    #
    Response = list(Network, Exposure) %>% layer_multiply()
    #
    keras_model(inputs = c(Design, Cat0, Exposure), outputs = c(Response))
    }


#=====================================================
# time-distributed neural network weighting of past observations
#=====================================================


####
network.attention.weighting <- function(seed, q0, lambda0, cat0, bb, output.acti){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    Design   <- layer_input(shape = c(q0[1], q0[2]), dtype = 'float32')
    Cat0     <- layer_input(shape = c(q0[1]), dtype = 'int32')
    Exposure <- layer_input(shape = c(q0[1]), dtype = 'float32')
    Obs      <- layer_input(shape = c(q0[1]), dtype = 'float32')
    PosT     <- layer_input(shape = c(q0[1]), dtype = 'float32')
    # this does not include the last response (to be predicted)
    YY       <- layer_input(shape = c(q0[1]-1), dtype = 'float32')
    ### credibility weights for past claims
    CatEmb0 = Cat0 %>% layer_reshape(c(q0[1],1)) %>%
        time_distributed(layer_embedding(input_dim=cat0[1], output_dim=bb[1], input_length=1)) %>%
        time_distributed(layer_flatten())
    #
    PosT0   = PosT     %>% layer_reshape(c(q0[1],1))
    Obs0   = Obs      %>% layer_reshape(c(q0[1],1))
    Obs1   = Obs      %>% k_sum(axis=2) %>% layer_reshape(c(1)) %>% layer_repeat_vector(c(q0[1]))
    #
    Network = list(Design, CatEmb0, PosT0, Obs1/q0[1]) %>%
          layer_concatenate() %>% time_distributed(layer_layer_normalization()) %>%
          time_distributed(layer_dense(units=q0[3], activation='gelu')) %>%
          time_distributed(layer_dense(units=q0[5], activation='gelu')) %>%
          time_distributed(layer_layer_normalization()) %>%
          time_distributed(layer_dense(units=1, activation='gelu'))
    Weights = Obs0 * Network - 100 * (1-Obs0)  # setting off periods without observations
    Weights = Weights %>% layer_flatten() %>% layer_activation_softmax()
    ### regression function for predicted claim
    CatEmb1 = Cat0[,q0[1]] %>%
      layer_embedding(input_dim = cat0[1], output_dim = bb[1], input_length = 1) %>%
      layer_flatten()
    #
    Mu = list(Design[,q0[1],], CatEmb1) %>% layer_concatenate() %>%
          layer_dense(units=q0[2], activation='tanh') %>%
          layer_dense(units=q0[3], activation='tanh') %>%
          layer_dense(units=q0[4], activation='tanh') %>%
          layer_dense(units=1, activation=output.acti,
                    weights=list(array(0, dim=c(q0[4],1)), array(log(lambda0), dim=c(1))))
    #
    YY <- YY/(Exposure[,1:(q0[1]-1)]+0.001) # normalize with exposure
    Vector = list(YY, Mu) %>% layer_concatenate()
    Response = list(Weights, Vector) %>% layer_multiply() %>% k_sum(axis=2) %>%
                  layer_reshape(c(1))
    Response = list(Response, Exposure[,q0[1]]) %>% layer_multiply()
    Response = list(Response, Weights) %>% layer_concatenate()
    #
    keras_model(inputs = c(Design, Cat0, Exposure, Obs, PosT, YY), outputs = c(Response))
    }


#=====================================================
# attention layer weighting of past observations
#=====================================================

####
attention.layer.weighting <- function(seed, q0, lambda0, cat0, bb, output.acti, mask){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    Design   <- layer_input(shape = c(q0[1], q0[2]), dtype = 'float32')
    Cat0     <- layer_input(shape = c(q0[1]), dtype = 'int32')
    Exposure <- layer_input(shape = c(q0[1]), dtype = 'float32')
    Obs      <- layer_input(shape = c(q0[1]), dtype = 'float32')
    PosT     <- layer_input(shape = c(q0[1]), dtype = 'float32')
    # the last response needs to identical to zero (and not carry any information)
    YY0      <- layer_input(shape = c(q0[1]), dtype = 'float32')
    ### expected frequency new response
    CatEmb1 = Cat0[,q0[1]] %>%
        layer_embedding(input_dim=cat0[1], output_dim=bb[1], input_length=1) %>%
        layer_flatten()
    #
    Mu = list(Design[,q0[1],], CatEmb1) %>% layer_concatenate() %>%
          layer_dense(units=q0[3], activation='tanh') %>%
          layer_dense(units=q0[4], activation='tanh') %>%
          layer_dense(units=q0[5], activation='tanh') %>%
          layer_dense(units=1, activation=output.acti,
                weights=list(array(0, dim=c(q0[5],1)), array(log(lambda0), dim=c(1))))
    #
    ### attention weights
    CatEmb0 = Cat0 %>% layer_reshape(c(q0[1],1)) %>%
        time_distributed(layer_embedding(input_dim=cat0[1], output_dim=bb[1], input_length=1)) %>%
        time_distributed(layer_flatten())
    #
    PosT0  = PosT %>% layer_reshape(c(q0[1],1))
    Obs0   = Obs %>% layer_reshape(c(q0[1],1))
    Obs1   = Obs %>% k_sum(axis=2) %>% layer_reshape(c(1)) %>% layer_repeat_vector(c(q0[1]))
    Input  = list(Design, CatEmb0, PosT0, Obs1/q0[1]) %>% layer_concatenate() %>%
                   time_distributed(layer_layer_normalization())
    ### query and key
    Q  =  Input %>%
            time_distributed(layer_dense(units = q0[5], activation = "gelu")) %>%
            time_distributed(layer_layer_normalization()) %>%
            time_distributed(layer_dense(units = 1, activation = "gelu"))
    Q = Obs0 * Q - mask * (1-Obs0)
    K = Input %>%
             time_distributed(layer_dense(units = q0[5], activation = "gelu")) %>%
             time_distributed(layer_layer_normalization()) %>%
             time_distributed(layer_dense(units = 1, activation = "gelu"))
    K = Obs0 * K - mask * (1-Obs0)
    V = YY0/(Exposure+0.001)
    V = V %>% layer_reshape(c(q0[1],1)) #%>%
                #time_distributed(layer_dense(units = 1, use_bias=FALSE, activation='linear'))
    Attention = layer_attention(list(Q,V,K), use_scale = FALSE, trainable = TRUE) %>%
                layer_reshape(q0[1])
    Experience =  Attention %>% k_sum(axis=2) %>% layer_reshape(c(1))
    Response   =  list(Experience/q0[1], Mu) %>% layer_add()
    Response   = list(Response, Exposure[,q0[1]]) %>% layer_multiply()
    #
    keras_model(inputs = c(Design, Cat0, Exposure, Obs, PosT, YY0), outputs = c(Response))
    }


#=====================================================
# deep attention layer experience rating
#=====================================================

####
deep.attention <- function(seed, q0, lambda0, cat0, bb, output.acti){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    Design   <- layer_input(shape = c(q0[1], q0[2]), dtype = 'float32')
    Cat0     <- layer_input(shape = c(q0[1]), dtype = 'int32')
    Exposure <- layer_input(shape = c(q0[1]), dtype = 'float32')
    Obs      <- layer_input(shape = c(q0[1]), dtype = 'float32')
    PosT     <- layer_input(shape = c(q0[1]), dtype = 'float32')
    # unobserved responses should be masked
    YY0      <- layer_input(shape = c(q0[1]), dtype = 'float32')
    ### attention weights
    CatEmb = Cat0 %>% layer_reshape(c(q0[1],1)) %>%
        time_distributed(layer_embedding(input_dim=cat0[1], output_dim=bb[1], input_length=1)) %>%
        time_distributed(layer_flatten())
    #
    Expo   = Exposure %>% layer_reshape(c(q0[1],1))
    PosT0  = PosT %>% layer_reshape(c(q0[1],1))
    Obs0   = Obs %>% layer_reshape(c(q0[1],1))
    YY00   = YY0 %>% layer_reshape(c(q0[1],1))
    #
    Input  = list(Design, CatEmb, Expo, PosT0, Obs0, YY00) %>% layer_concatenate()
    ### query and key
    Q =  Input %>%
            time_distributed(layer_dense(units = q0[5], activation = "gelu")) %>%
            time_distributed(layer_dense(units = q0[6], activation = "gelu"))
    K =  Input %>%
            time_distributed(layer_dense(units = q0[5], activation = "gelu")) %>%
            time_distributed(layer_dense(units = q0[6], activation = "gelu"))
    V =  Input %>%
            time_distributed(layer_dense(units = q0[5], activation = "gelu")) %>%
            time_distributed(layer_dense(units = q0[6], activation = "gelu"))
    Attention = layer_attention(list(Q,V,K), use_scale = FALSE, trainable = TRUE) %>%
            layer_flatten()
    ### expected frequency new response
    CatEmb1 = Cat0[,q0[1]] %>%
        layer_embedding(input_dim=cat0[1], output_dim=bb[1], input_length=1) %>%
        layer_flatten()
    ##
    Network = list(Design[,q0[1],], CatEmb1, Attention) %>% layer_concatenate() %>%
          layer_dense(units=q0[3], activation='tanh') %>%
          layer_dense(units=q0[4], activation='tanh') %>%
          layer_dense(units=q0[5], activation='tanh') %>%
          layer_dense(units=1, activation=output.acti,
                weights=list(array(0, dim=c(q0[5],1)), array(log(lambda0), dim=c(1))))

    Response = list(Network, Exposure[,q0[1]]) %>% layer_multiply()
    # %>% layer_reshape(c(1))
    #
    keras_model(inputs = c(Design, Cat0, Exposure, Obs, PosT, YY0), outputs = c(Response))
    }


