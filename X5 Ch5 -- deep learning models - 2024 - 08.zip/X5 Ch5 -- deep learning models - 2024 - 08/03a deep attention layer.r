####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Deep experience rating
#########  Author: Mario Wuthrich
#########  Version August 2024
####################################################################################

library(arrow)
library(tidyverse)
library(keras)
library(tensorflow)

pathPlot <- "../../Plots/"


####################################################################################
### load and pre-process data
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic

labelNN <- c("ClaimNb", "True", "DrivAgeX", "GenderX", "LeasingX",
            "LowMileageX", "CatPriceX", "DeductibleX",
            "DurationX", "YearX", "VehAgeX", "RegionX", "YearCatNN")

source("./Tools/01b static mixed effects - load data NN.r")

tensor <- tensorNN
dim(tensor)

# continuous covariates for neural network
NN.XX <- c(5:10, 13) # 1=Observation YES/NO, 2=Exposure, 3=ClaimNb, 4=True, 11=Duration, 12=YearX
labelNN[NN.XX-2]

# categorical covariate for embedding layer
NN.Region <- c(14)
labelNN[NN.Region-2]
no.of.regions <- 15

####################################################################################
### set parameters and define loss functions
####################################################################################

Poisson.Deviance <- function(obs, pred){200*(sum(pred)-sum(obs)+sum(log((obs/pred)^(obs))))/length(pred)}
NB.KL.divergence <- function(true, est, phi){100*mean(true*(log(true/est)-phi/(phi-1)*log(phi/((phi-1)*est/true+1))))}

phi.star <- 1.3
T0 <- 2014
T1 <- 2018

####################################################################################
### load networks
####################################################################################

source("./Tools/02a networks.R")

####################################################################################
### deep experience rating fitting
####################################################################################

results_AttentionIII <- data.frame(array(NA, dim=c(T1-T0+1, 6)))
names(results_AttentionIII) <- c("xx", "xx", "1c_KL_in_sample", "xx", "xx", "2c_KL_forecast")

J0 <- 10
for (tt in c(T0:T1)){
  TT <- tt-2011+1
  for (j0 in 1:J0){
    # preparation of data
    dat.Obs    <- tensor[,2:(TT+1),1]        # indicator for observation yes/no
    index      <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT]==1)]  # only select active policies
    tensor0    <- tensor[index,,]
    set.seed(200)  # randomize order for stochastic gradient descent
    index0      <- sample(c(1:length(index)), size=length(index))
    #
    dat.Obs     <- tensor0[index0,2:(TT+1),1]         # observation yes/no
    dat.PosT    <- t(array(rep(rev(c(0:(TT-1)))/TT, nrow(dat.Obs)), dim=dim(t(dat.Obs)))) # positional encoding
    dat.Expo    <- tensor0[index0,2:(TT+1),2]         # exposure
    dat.YY      <- tensor0[index0,2:(TT+1),3]         # claims
    dat.YY0     <- dat.YY*dat.Obs - 2 * (1-dat.Obs)   # mask unobserved responses
    dat.YY0[,TT]<- -2                                 # mask the variable to be predicted
    dat.True    <- tensor0[index0,TT+1,4]             # true frequency
    dat.XX      <- tensor0[index0,2:(TT+1),NN.XX]     # selected continuous covariates
    dat.Reg     <- tensor0[index0,2:(TT+1),NN.Region] # categorical covariate
    (q00 <- c(dim(dat.XX)[c(2,3)], c(20,15,10,3)))
    (lambda.hom <- sum(dat.YY[,TT])/sum(dat.Expo[,TT]))
    seed <- 100 + j0 - 1
    model <- deep.attention(seed, q00, lambda.hom, no.of.regions, 2, "exponential")
    path0 <- paste("./Networks/DeepAttention_",tt,"_seed_",seed, ".h5", sep="")
    CBs <- callback_model_checkpoint(path0, monitor = "val_loss", verbose = 0,  save_best_only = TRUE, save_weights_only = TRUE)
    Q_loss <- function(y_true, y_pred){
         mu <- y_pred[,1]
         yy <- y_true[,1]
         -k_sum(-mu + yy*k_log(mu+.000000001))
          }
    adam = optimizer_adam(learning_rate = 0.002, beta_2 = 0.98)
    model %>% compile(loss = Q_loss, optimizer = adam)
    ##
    #{t1 <- proc.time()
    #  fit <- model %>% fit(list(dat.XX, dat.Reg, dat.Expo, dat.Obs, dat.PosT, dat.YY0), dat.YY[,c(TT,1)],
    #                validation_split=.2,
    #                batch_size=5000, epochs=50, verbose=0, callbacks=CBs)
    #(proc.time()-t1)[3]}
    #plot.loss("topright", fit[[2]], paste("SGD: year ", tt, ", run ", j0, sep=""), ylim0=range(fit[[2]]), col0=c("blue","darkgreen", "orange"))
    # results
    load_model_weights_hdf5(model, path0)
    pred0 <- model %>% predict(list(dat.XX, dat.Reg, dat.Expo, dat.Obs, dat.PosT, dat.YY0), batch_size=10^6)
    if (j0==1){
      post1 <- pred0[,1]/J0
              }else{
      post1 <- post1 + pred0[,1]/J0
                  }
    if (j0==J0){
      results_AttentionIII[tt-T0+1,3] <- round(NB.KL.divergence(dat.True, post1, phi.star),4)
               }
    # out-of-sample
    dat.Obs    <- tensor[,3:(TT+2),1]           # indicator for observation yes/no
    index      <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT]==1)]  # only select active policies
    tensor0    <- tensor[index,,]
    #
    dat.Obs     <- tensor0[,3:(TT+2),1]         # observation yes/no
    dat.PosT    <- t(array(rep(rev(c(0:(TT-1)))/TT, nrow(dat.Obs)), dim=dim(t(dat.Obs)))) # positional encoding
    dat.Expo    <- tensor0[,3:(TT+2),2]         # exposure
    dat.YY      <- tensor0[,3:(TT+2),3]         # claims
    dat.YY0     <- dat.YY*dat.Obs - 2 * (1-dat.Obs)   # mask unobserved responses
    dat.YY0[,TT]<- -2                                 # mask the variable to be predicted
    dat.True    <- tensor0[,TT+2,4]             # true frequency
    dat.XX      <- tensor0[,3:(TT+2),NN.XX]     # selected continuous covariates
    dat.Reg     <- tensor0[,3:(TT+2),NN.Region] # categorical covariate
    pred0 <- model %>% predict(list(dat.XX, dat.Reg, dat.Expo, dat.Obs, dat.PosT, dat.YY0), batch_size=10^6)
    if (j0==1){
      post2 <- pred0[,1]/J0
              }else{
      post2 <- post2 + pred0[,1]/J0
                  }
    if (j0==J0){
      results_AttentionIII[tt-T0+1,6] <- round(NB.KL.divergence(dat.True, post2, phi.star),4)
               }
      }}

#save(data=results_AttentionIII, file="../Results/results_AttentionIII.rda")

results_AttentionIII

######################

load(file="../Results/results_GLM.rda")
load(file="../Results/results_SME_GLM_1Year.rda")
load(file="../Results/results_DME_GLM_1Year.rda")
load(file="../Results/results_DeepAttentionI.rda")
load(file="../Results/results_AttentionII.rda")
load(file="../Results/results_AttentionIII.rda")


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch5/DeepAttention_KL_in_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
ylim0 <- range(0,0.28)
stats <- 3
plot(x=c(T0:T1), y=results_GLM[,stats], col="blue", type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                  main=list("deep experience rating: KL divergence T", cex=1.5))
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,1], col="pink", lwd=2)
lines(x=c(T0:T1), y=results_DME_GLM_1Year[,stats], col="red", lwd=2)
lines(x=c(T0:T1), y=results_DeepAttentionI[,stats], col="darkgreen", lwd=2)
#lines(x=c(T0:T1), y=results_AttentionII[,stats], col="green", lwd=2)
lines(x=c(T0:T1), y=results_AttentionIII[,stats], col="cyan", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,1], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_DME_GLM_1Year[,stats], col="red", pch=20, cex=3)
points(x=c(T0:T1), y=results_DeepAttentionI[,stats], col="darkgreen", pch=20, cex=3)
#points(x=c(T0:T1), y=results_AttentionII[,stats], col="green", pch=20, cex=3)
points(x=c(T0:T1), y=results_AttentionIII[,stats], col="cyan", pch=20, cex=3)
legend(x="topleft", bg="white", cex=1.5, lty=1, lwd=2, pch=20, col=c("blue", "pink", "red", "darkgreen", "cyan"), legend=c("GLM", "SME GLM (b)", "DME GLM (b)", "attention FNN", "deep attention"))
if (pdf.plot==1){dev.off()}


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch5/DeepAttention_KL_out_of_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 6
plot(x=c(T0:T1), y=results_GLM[,stats], col="blue", type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                   main=list("deep experience rating: KL divergence T+1", cex=1.5))
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,3], col="pink", lwd=2)
lines(x=c(T0:T1), y=results_DME_GLM_1Year[,stats], col="red", lwd=2)
lines(x=c(T0:T1), y=results_DeepAttentionI[,stats], col="darkgreen", lwd=2)
#lines(x=c(T0:T1), y=results_AttentionII[,stats], col="green", lwd=2)
lines(x=c(T0:T1), y=results_AttentionIII[,stats], col="cyan", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,3], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_DME_GLM_1Year[,stats], col="red", pch=20, cex=3)
points(x=c(T0:T1), y=results_DeepAttentionI[,stats], col="darkgreen", pch=20, cex=3)
#points(x=c(T0:T1), y=results_AttentionII[,stats], col="green", pch=20, cex=3)
points(x=c(T0:T1), y=results_AttentionIII[,stats], col="cyan", pch=20, cex=3)
legend(x="bottomleft", bg="white", cex=1.5, lty=1, lwd=2, pch=20, col=c("blue", "pink", "red", "darkgreen", "cyan"), legend=c("GLM", "SME GLM (b)", "DME GLM (b)", "attention FNN", "deep attention"))
if (pdf.plot==1){dev.off()}



####################################################################################
### analysis of weights
####################################################################################


tt <- T1
TT <- tt-2011+1
# preparation of data
dat.Obs    <- tensor[,2:(TT+1),1]        # indicator for observation yes/no
index      <- c(1:nrow(dat.Obs))[which(rowSums(dat.Obs)==TT)]
tensor0    <- tensor[index,,]
index0     <- c(1:length(index))
#
dat.Obs     <- tensor0[index0,2:(TT+1),1]         # observation yes/no
dat.PosT    <- t(array(rep(rev(c(0:(TT-1)))/TT, nrow(dat.Obs)), dim=dim(t(dat.Obs)))) # positional encoding
dat.Expo    <- tensor0[index0,2:(TT+1),2]         # exposure
dat.YY      <- tensor0[index0,2:(TT+1),3]         # claims
dat.YY0     <- array(0, dim=dim(dat.YY))
dat.YY0[,TT]<- -2                                 # mask the variable to be predicted
dat.True    <- tensor0[index0,TT+1,4]             # true frequency
dat.XX      <- tensor0[index0,2:(TT+1),NN.XX]     # selected continuous covariates
dat.Reg     <- tensor0[index0,2:(TT+1),NN.Region] # categorical covariate
(q00 <- c(dim(dat.XX)[c(2,3)], c(20,15,10,3)))
(lambda.hom <- sum(dat.YY[,TT])/sum(dat.Expo[,TT]))

for (j0 in 1:J0){
    seed <- 100 + j0 - 1
    model <- deep.attention(seed, q00, lambda.hom, no.of.regions, 2, "exponential")
    path0 <- paste("./Networks/DeepAttention_",tt,"_seed_",seed, ".h5", sep="")
    load_model_weights_hdf5(model, path0)
    pred0 <- model %>% predict(list(dat.XX, dat.Reg, dat.Expo, dat.Obs, dat.PosT, dat.YY0), batch_size=10^6)
    #
    if (j0==1){
      post1 <- pred0[,1]/J0
              }else{
      post1 <- post1 + pred0[,1]/J0
                  }
         }

post2 <- post1

for (jj in (1:(TT-1))){
  dat.YY0      <- array(0, dim=dim(dat.YY))
  dat.YY0[,jj] <- dat.Expo[,jj]  # careful the first year can have a partial exposure
  dat.YY0[,TT]<- -2              # mask the variable to be predicted
  for (j0 in 1:J0){
    seed <- 100 + j0 - 1
    model <- deep.attention(seed, q00, lambda.hom, no.of.regions, 2, "exponential")
    path0 <- paste("./Networks/DeepAttention_",tt,"_seed_",seed, ".h5", sep="")
    load_model_weights_hdf5(model, path0)
    pred0 <- model %>% predict(list(dat.XX, dat.Reg, dat.Expo, dat.Obs, dat.PosT, dat.YY0), batch_size=10^6)
    #
    if (j0==1){
      post0 <- pred0[,1]/J0
              }else{
      post0 <- post0 + pred0[,1]/J0
                  }
         }
   post2 <- rbind(post2,post0)
   }


(weights.average <- rowMeans(post2))
(weights.average <- weights.average[-1]-weights.average[1])

col0 <- rev(rainbow(n=length(weights.average), start=0, end=.75))


plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(pathPlot, "/Ch5/credibilityweightsIII.pdf", sep="")
i0 <- 1
ylim0 <- c(0,0.03)
if (plot.yes){pdf(file=filey1)}
plot(x=c(2011:(tt-1)), y=weights.average, cex.axis=1.5, ylim=ylim0, type='l', lwd=2, ylab="premium malus", col="blue", xlab="calendar year s", main=list(paste("average premium malus, T+1=", tt, sep=""), cex=1.5), cex.lab=1.5)
#abline(h=0.0275, col="black", lty=1)
points(x=c(2011:(tt-1)), y=weights.average, pch=20, cex=3, col=col0[1:7])
#legend(x="bottomright", pch=-1, cex=1.5, lty=-1, lwd=-1, box.col=FALSE, legend=c(paste0("weight on prior ", round(zero,2)*100,"%")))
if (plot.yes){dev.off()}

post3 <- post2[2:8,]
for (jj in 1:7){post3[jj,] <- post3[jj,]-post2[1,]}

plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(pathPlot, "/Ch5/credibilityweights2III.pdf", sep="")
if (plot.yes){pdf(file=filey1)}
boxplot(t(post3), xaxt='n', col=col0, range=1, outline = F, ylab="premium malus", xlab="calendar year s", main=list(paste("boxplot of premium malus, T+1=", tt, sep=""), cex=1.5), cex.lab=1.5)
axis(1, at=c(1:7), labels=c(2011:2017), cex.lab=1.5)
if (plot.yes){dev.off()}


####################################################################################
### study of auto-calibration
####################################################################################

J0 <- 10
for (tt in c(T1:T1)){
  TT <- tt-2011+1
  # preparation of data
  dat.Obs    <- tensor[,2:(TT+1),1]        # indicator for observation yes/no
  index      <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT]==1)]  # only select active policies
  tensor0    <- tensor[index,,]
  set.seed(200)  # randomize order for stochastic gradient descent
  index0      <- sample(c(1:length(index)), size=length(index))
  #
  dat.Obs     <- tensor0[index0,2:(TT+1),1]         # observation yes/no
  dat.PosT    <- t(array(rep(rev(c(0:(TT-1)))/TT, nrow(dat.Obs)), dim=dim(t(dat.Obs)))) # positional encoding
  dat.Expo    <- tensor0[index0,2:(TT+1),2]         # exposure
  dat.YY      <- tensor0[index0,2:(TT+1),3]         # claims
  dat.YY0     <- dat.YY*dat.Obs - 2 * (1-dat.Obs)   # mask unobserved responses
  dat.YY0[,TT]<- -2                                 # mask the variable to be predicted
  dat.True    <- tensor0[index0,TT+1,4]             # true frequency
  dat.XX      <- tensor0[index0,2:(TT+1),NN.XX]     # selected continuous covariates
  dat.Reg     <- tensor0[index0,2:(TT+1),NN.Region] # categorical covariate
  (q00 <- c(dim(dat.XX)[c(2,3)], c(20,15,10,3)))
  (lambda.hom <- sum(dat.YY[,TT])/sum(dat.Expo[,TT]))
  for (j0 in 1:J0){
    seed <- 100 + j0 - 1
    model <- deep.attention(seed, q00, lambda.hom, no.of.regions, 2, "exponential")
    path0 <- paste("./Networks/DeepAttention_",tt,"_seed_",seed, ".h5", sep="")
    load_model_weights_hdf5(model, path0)
    pred0 <- model %>% predict(list(dat.XX, dat.Reg, dat.Expo, dat.Obs, dat.PosT, dat.YY0), batch_size=10^6)
    if (j0==1){
      post1 <- pred0[,1]/J0
              }else{
      post1 <- post1 + pred0[,1]/J0
                  }
 }}

# test
round(NB.KL.divergence(dat.True, post1, phi.star),4)
results_AttentionIII


################
learn <- data.frame(cbind(dat.True, post1, dat.Expo[,TT]))
names(learn) <- c("True", "pred", "Exposure")

library(monotone)

## compute frequencies
learn$lambda  <- learn$pred/learn$Exposure
learn$lambdaT <- learn$True/learn$Exposure

## perform isotonic regression
learn2 <- learn
learn2 <- learn2[order(learn2$lambda),]
iso1 <- monotone(x=learn2$lambdaT, w = learn2$Exposure)

## number of different values
c(length(unique(iso1)), length(unique(learn2$lambda)))

## isotonic regression forecast
learn2$iso <- iso1
fit0 <- stepfun(learn2$lambda, c(0,learn2$iso))
learn$iso1 <- fit0(learn$lambda)

####################################################################################
### T-reliability diagram
####################################################################################

set.seed(100)
ll <- sample(size=5000, x=c(1:nrow(learn)))

pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch5/isotonic_insampleII.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
(ylim0 <- range(learn$lambda, learn$iso1))
ylim0 <- c(0.022, 0.34)
plot(x=learn[ll,]$lambda, y=learn[ll,]$iso1, ylim=ylim0, xlim=ylim0,
                  ylab="isotonic regression (true frequency)", xlab="deep experience rating", cex.lab=1.5,
                  main=list("T-reliability diagram", cex=1.5))
abline(a=0, b=1, col="orange", lwd=2)
par(new=TRUE)
dd <- density(learn$lambda, from=ylim0[1], to=ylim0[2])
plot(dd, xaxt='n', yaxt='n', cex.lab=1.5, xlab="", ylab="", lwd=3, col="blue", main="")
axis(4, col="blue", col.axis="blue")
if (pdf.plot){dev.off()}



pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch5/isotonic_insample_logII.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
ylim1 <- log(ylim0)
plot(x=log(learn[ll,]$lambda), y=log(learn[ll,]$iso1), ylim=ylim1, xlim=ylim1,
                  ylab="isotonic regression (log-scale)", xlab="deep experience rating (log-scale)", cex.lab=1.5,
                  main=list("T-reliability diagram", cex=1.5))
abline(a=0, b=1, col="orange", lwd=2)
par(new=TRUE)
plot(density(log(learn$lambda), from=ylim1[1], to=ylim1[2]), xaxt='n', yaxt='n', cex.lab=1.5, xlab="", ylab="", lwd=3, col="blue", main="")
axis(4, col="blue", col.axis="blue")
if (pdf.plot){dev.off()}

