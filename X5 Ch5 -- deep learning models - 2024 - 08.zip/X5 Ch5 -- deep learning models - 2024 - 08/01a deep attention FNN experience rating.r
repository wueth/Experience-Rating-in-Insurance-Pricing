####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Deep attention FNN experience rating model
#########  Author: Mario Wuthrich
#########  Version August 2024
####################################################################################

library(arrow)
library(tidyverse)
library(keras)
library(tensorflow)

pathPlot <- "../../Plots/"

####################################################################################
### load and pre-process data
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic

labelNN <- c("ClaimNb", "True", "DrivAgeX", "GenderX", "LeasingX",
            "LowMileageX", "CatPriceX", "DeductibleX",
            "DurationX", "YearX", "VehAgeX", "RegionX", "YearCatNN")

source("./Tools/01b static mixed effects - load data NN.r")

tensor <- tensorNN
dim(tensor)

# continuous covariates for neural network
NN.XX <- c(5:10, 13) # 1=Observation YES/NO, 2=Exposure, 3=ClaimNb, 4=True, 11=Duration, 12=YearX
labelNN[NN.XX-2]

# categorical covariate for embedding layer
NN.Region <- c(14)
labelNN[NN.Region-2]
no.of.regions <- 15

####################################################################################
### set parameters and define loss functions
####################################################################################

Poisson.Deviance <- function(obs, pred){200*(sum(pred)-sum(obs)+sum(log((obs/pred)^(obs))))/length(pred)}
NB.KL.divergence <- function(true, est, phi){100*mean(true*(log(true/est)-phi/(phi-1)*log(phi/((phi-1)*est/true+1))))}

phi.star <- 1.3
T0 <- 2014
T1 <- 2018

####################################################################################
### load networks
####################################################################################

source("./Tools/02a networks.R")

####################################################################################
### deep attention FNN experience rating model fitting
####################################################################################

results_DeepAttentionI <- data.frame(array(NA, dim=c(T1-T0+1, 6)))
names(results_DeepAttentionI) <- c("xx", "xx", "1c_KL_in_sample", "xx", "xx", "2c_KL_forecast")

J0 <- 10
for (tt in c(T0:T1)){
  TT <- tt-2011+1
  for (j0 in 1:J0){
    # preparation of learning data
    dat.Obs    <- tensor[,2:(TT+1),1]        # indicator for observation yes/no
    index      <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT]==1)]  # only select active policies
    tensor0    <- tensor[index,,]
    set.seed(200)  # randomize order for stochastic gradient descent
    index0      <- sample(c(1:length(index)), size=length(index))
    #
    dat.Obs     <- tensor0[index0,2:(TT+1),1]         # observation yes/no
    dat.PosT    <- t(array(rep(rev(c(0:(TT-1)))/TT, nrow(dat.Obs)), dim=dim(t(dat.Obs)))) # positional encoding, revert time
    dat.Expo    <- tensor0[index0,2:(TT+1),2]         # exposure
    dat.YY      <- tensor0[index0,2:(TT+1),3]         # claims
    dat.True    <- tensor0[index0,TT+1,4]             # true frequency
    dat.XX      <- tensor0[index0,2:(TT+1),NN.XX]     # selected continuous covariates
    dat.Reg     <- tensor0[index0,2:(TT+1),NN.Region] # categorical covariate
    (q00 <- c(dim(dat.XX)[c(2,3)], c(20,15,10)))
    (lambda.hom <- sum(dat.YY[,TT])/sum(dat.Expo[,TT]))
    seed <- 100 + j0 - 1
    model <- network.attention.weighting(seed, q00, lambda.hom, no.of.regions, 2, "exponential")
    path0 <- paste("./Networks/DeepAttentionI",tt,"_seed_",seed, ".h5", sep="")
    CBs <- callback_model_checkpoint(path0, monitor = "val_loss", verbose = 0,  save_best_only = TRUE, save_weights_only = TRUE)
    Q_loss <- function(y_true, y_pred){     # Poisson deviance loss function
         mu <- y_pred[,1]
         yy <- y_true[,1]
         -k_sum(-mu + yy*k_log(mu+.000000001))
          }
    adam = optimizer_adam(learning_rate = 0.002, beta_2 = 0.98)
    model %>% compile(loss = Q_loss, optimizer = adam)
    ## fitting takes some time: just reload pre-fitted networks below
    #{t1 <- proc.time()
    #  fit <- model %>% fit(list(dat.XX, dat.Reg, dat.Expo, dat.Obs, dat.PosT, dat.YY[,1:(TT-1)]), dat.YY[,c(TT,1)],
    #                validation_split=.2,
    #                batch_size=5000, epochs=100, verbose=1, callbacks=CBs)
    #(proc.time()-t1)[3]}
    #plot.loss("topright", fit[[2]], paste("SGD: year ", tt, ", run ", j0, sep=""), ylim0=range(fit[[2]]), col0=c("blue","darkgreen", "orange"))
    # results in-sample
    load_model_weights_hdf5(model, path0)
    pred0 <- model %>% predict(list(dat.XX, dat.Reg, dat.Expo, dat.Obs, dat.PosT, dat.YY[,1:(TT-1)]), batch_size=10^6)
    if (j0==1){     # network ensembling
      post1 <- pred0[,1]/J0
              }else{
      post1 <- post1 + pred0[,1]/J0
                  }
    if (j0==J0){
      results_DeepAttentionI[tt-T0+1,3] <- round(NB.KL.divergence(dat.True, post1, phi.star),4)
               }
    # results out-of-sample forecast
    dat.Obs    <- tensor[,3:(TT+2),1]        # indicator for observation yes/no
    index      <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT]==1)]  # only select active policies
    tensor0    <- tensor[index,,]
    #
    dat.Obs     <- tensor0[,3:(TT+2),1]         # observation yes/no
    dat.PosT    <- t(array(rep(rev(c(0:(TT-1)))/TT, nrow(dat.Obs)), dim=dim(t(dat.Obs)))) # positional encoding
    dat.Expo    <- tensor0[,3:(TT+2),2]         # exposure
    dat.YY      <- tensor0[,3:(TT+2),3]         # claims
    dat.True    <- tensor0[,TT+2,4]             # true frequency
    dat.XX      <- tensor0[,3:(TT+2),NN.XX]     # selected continuous covariates
    dat.Reg     <- tensor0[,3:(TT+2),NN.Region] # categorical covariate
    pred0 <- model %>% predict(list(dat.XX, dat.Reg, dat.Expo, dat.Obs, dat.PosT, dat.YY[,1:(TT-1)]), batch_size=10^6)
    if (j0==1){
      post2 <- pred0[,1]/J0
              }else{
      post2 <- post2 + pred0[,1]/J0
                  }
    if (j0==J0){
      results_DeepAttentionI[tt-T0+1,6] <- round(NB.KL.divergence(dat.True, post2, phi.star),4)
               }
      }}

#save(data=results_DeepAttentionI, file="../Results/results_DeepAttentionI.rda")

results_DeepAttentionI

####################################################################################
### analysis of credibility weights
####################################################################################

# continue previous code with tt=2018 and TT=8, respectively
# select claims that have been fully exposed during the whole time (there is zero weight on NAs)
index        <- c(1:nrow(dat.Obs))[which(rowSums(dat.Obs)==ncol(dat.Obs))]
dat.Obs0     <- dat.Obs[index,]
dat.PosT0    <- t(array(rep(rev(c(0:(TT-1)))/TT, nrow(dat.Obs0)), dim=dim(t(dat.Obs0)))) # positional encoding
dat.Expo0    <- dat.Expo[index,]
dat.YY0      <- dat.YY[index,]
dat.XX0      <- dat.XX[index,,]
dat.Reg0     <- dat.Reg[index,]

for (j0 in 1:J0){
  seed <- 100 + j0 - 1
  #model <- network.attention.weighting(seed, q00, lambda.hom, no.of.regions, 2, "exponential")
  path0 <- paste("./Networks/DeepAttentionI",tt,"_seed_",seed, ".h5", sep="")
  load_model_weights_hdf5(model, path0)
  pred0 <- model %>% predict(list(dat.XX0, dat.Reg0, dat.Expo0, dat.Obs0, dat.PosT0, dat.YY0[,1:(TT-1)]), batch_size=10^6)
  if (j0==1){
      post0 <- pred0/J0
              }else{
      post0 <- post0 + pred0/J0
                  }
      }
post0[2,]

weights.average <- colMeans(post0[,-1])
zero <- weights.average[length(weights.average)]
weights.average
weights.average <- weights.average[-length(weights.average)]

col0 <- rev(rainbow(n=length(weights.average), start=0, end=.75))


plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(pathPlot, "/Ch5/credibilityweights.pdf", sep="")
i0 <- 1
if (plot.yes){pdf(file=filey1)}
plot(x=c(2011:(tt-1)), y=weights.average, cex.axis=1.5, ylim=range(weights.average,0, 0.042), type='l', lwd=2, ylab="attention weights", col="blue", xlab="calendar year s", main=list(paste("average attention weights, T+1=", tt, sep=""), cex=1.5), cex.lab=1.5)
abline(h=0.03, col="black", lty=1)
points(x=c(2011:(tt-1)), y=weights.average, pch=20, cex=3, col=col0[1:7])
legend(x="bottomright", pch=-1, cex=1.5, lty=-1, lwd=-1, box.col=FALSE, legend=c(paste0("weight on prior ", round(zero,2)*100,"%")))
if (plot.yes){dev.off()}



post2 <- post0[,2:8]

plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(pathPlot, "/Ch5/credibilityweights2.pdf", sep="")
if (plot.yes){pdf(file=filey1)}
boxplot(post2, xaxt='n', col=col0, range=1, outline = F, ylab="attention weights", xlab="calendar year s", main=list(paste("boxplot of attention weights, T+1=", tt, sep=""), cex=1.5), cex.lab=1.5)
axis(1, at=c(1:7), labels=c(2011:2017), cex.lab=1.5)
if (plot.yes){dev.off()}


plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(pathPlot, "/Ch5/credibilityweights3.pdf", sep="")
if (plot.yes){pdf(file=filey1)}
plot(density(post2[,7], na.rm=TRUE, from=0, to=.1), ylim=c(0,50), col=col0[7],lwd=2,  xlab="attention weights", ylab="density", main=list(paste("density of attention weights, T+1=", tt, sep=""), cex=1.5), cex.lab=1.5)
for (i in c(1,6)){lines(density(post2[,i], na.rm=TRUE, from=0, to=.1), col=col0[i],lwd=2)}
legend(x="topright", lwd=2, pch=-1, cex=1.5, col=rev(col0[c(1,6,7)]), legend=c(paste("time lag", (c(1,2,7)), sep="")))
if (plot.yes){dev.off()}




####################################################################################
### analysis of results
####################################################################################

load(file="../Results/results_GLM.rda")
load(file="../Results/results_SME_GLM_1Year.rda")
load(file="../Results/results_DME_GLM_1Year.rda")
load(file="../Results/results_DeepAttentionI.rda")


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch5/AttentionFNN_KL_in_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
ylim0 <- range(0,0.28)
stats <- 3
plot(x=c(T0:T1), y=results_GLM[,stats], col="blue", type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                  main=list("deep attention FNN: KL divergence T", cex=1.5))
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,1], col="pink", lwd=2)
lines(x=c(T0:T1), y=results_DME_GLM_1Year[,stats], col="red", lwd=2)
lines(x=c(T0:T1), y=results_DeepAttentionI[,stats], col="darkgreen", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,1], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_DME_GLM_1Year[,stats], col="red", pch=20, cex=3)
points(x=c(T0:T1), y=results_DeepAttentionI[,stats], col="darkgreen", pch=20, cex=3)
legend(x="bottomright", cex=1.5, lty=c(1,1,1,1), lwd=2, pch=20, col=c("blue", "pink", "red", "darkgreen"), legend=c("GLM", "SME GLM (b)", "DME GLM (b)", "attention FNN"))
if (pdf.plot==1){dev.off()}


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch5/AttentionFNN_KL_out_of_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 6
plot(x=c(T0:T1), y=results_GLM[,stats], col="blue", type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                   main=list("deep attention FNN: KL divergence T+1", cex=1.5))
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,3], col="pink", lwd=2)
lines(x=c(T0:T1), y=results_DME_GLM_1Year[,stats], col="red", lwd=2)
lines(x=c(T0:T1), y=results_DeepAttentionI[,stats], col="darkgreen", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,3], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_DME_GLM_1Year[,stats], col="red", pch=20, cex=3)
points(x=c(T0:T1), y=results_DeepAttentionI[,stats], col="darkgreen", pch=20, cex=3)
legend(x="bottomleft", cex=1.5, lty=c(1,1,1,1), lwd=2, pch=20, col=c("blue", "pink", "red", "darkgreen"), legend=c("GLM", "SME GLM (b)", "DME GLM (b)", "attention FNN"))
if (pdf.plot==1){dev.off()}

