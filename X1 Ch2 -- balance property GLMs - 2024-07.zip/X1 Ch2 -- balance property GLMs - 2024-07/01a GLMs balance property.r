##########################################
#########  Experience Rating in Insurance Pricing
#########  Balance property in GLMs
#########  Author: Mario Wuthrich
#########  Version July 2024
##########################################

path0 <- "../../Plots/Ch2/SweMC/"

library(tidyverse)
library(arrow)

load(file="./Data/mcdata.rda")
str(mcdata)

data.frame(mcdata %>% select(Zone, AgeClass, ClaimAmount) %>%
                      pivot_wider(names_from="AgeClass", names_prefix="Age", values_from="ClaimAmount"))

data.frame(mcdata %>% select(Zone, AgeClass, ClaimNb) %>%
                      pivot_wider(names_from="AgeClass", names_prefix="Age", values_from="ClaimNb"))


######################################################################
####### homogeneous estimate (no covariates)
######################################################################

mcdata0 <- mcdata
round(mu.hom <- sum(mcdata0$ClaimAmount)/sum(mcdata0$ClaimNb))

######################################################################
####### GLM Poisson
######################################################################

glm1.Poisson <- glm(ClaimAmount/ClaimNb ~ Zone + AgeClass,
                    weights=ClaimNb, family= quasipoisson, data=mcdata0)

summary(glm1.Poisson)
# Remark that the selected variables are not significant, however this
# does not impact the study of the balance property under different links.

mcdata0$Poisson <- predict(glm1.Poisson, newdata=mcdata0, type='response')*mcdata0$ClaimNb

######################################################################
####### GLM gamma
######################################################################

glm1.gamma <- glm(ClaimAmount/ClaimNb ~ Zone + AgeClass,
                    family= Gamma(link='log'), weights=ClaimNb, data=mcdata0)

summary(glm1.gamma)

mcdata0$gamma <- predict(glm1.gamma, newdata=mcdata0, type='response')*mcdata0$ClaimNb

###
start0 <- glm1.gamma$coefficients
glm1.gammaH <- glm(ClaimAmount/ClaimNb ~ Zone + AgeClass,
                    family= Gamma, weights=ClaimNb, data=mcdata0)

summary(glm1.gammaH)

mcdata0$gammaH <- predict(glm1.gammaH, newdata=mcdata0, type='response')*mcdata0$ClaimNb

######################################################################
####### GLM inverse Gaussian
######################################################################

start0 <- glm1.gamma$coefficients
glm1.IG <- glm(ClaimAmount/ClaimNb ~ Zone + AgeClass,
                    family= inverse.gaussian(link='log'), start=start0, weights=ClaimNb, data=mcdata0)

summary(glm1.IG)

mcdata0$IG <- predict(glm1.IG, newdata=mcdata0, type='response')*mcdata0$ClaimNb

###
glm1.IGH <- glm(ClaimAmount/ClaimNb ~ Zone + AgeClass,
                    family= inverse.gaussian, start=start0, weights=ClaimNb, data=mcdata0)
warnings()

start1 <- glm1.IGH$coefficients
glm1.IGH <- glm(ClaimAmount/ClaimNb ~ Zone + AgeClass,
                    family= inverse.gaussian, start=start1, weights=ClaimNb, data=mcdata0)

summary(glm1.IGH)

mcdata0$IGH <- predict(glm1.IGH, newdata=mcdata0, type='response')*mcdata0$ClaimNb

######################################################################
####### results and plots
######################################################################

round(c(mu.hom, sum(mcdata0$Poisson)/sum(mcdata0$ClaimNb), sum(mcdata0$gamma)/sum(mcdata0$ClaimNb), sum(mcdata0$gammaH)/sum(mcdata0$ClaimNb), sum(mcdata0$IG)/sum(mcdata0$ClaimNb), sum(mcdata0$IGH)/sum(mcdata0$ClaimNb)))

ylim0 <- range(c(0,50000),mcdata0$Poisson/mcdata0$ClaimNb, mcdata0$gamma/mcdata0$ClaimNb, mcdata0$IG/mcdata0$ClaimNb, mcdata0$gammaH/mcdata0$ClaimNb, mcdata0$IGH/mcdata0$ClaimNb)
mcdata1 <- mcdata0[order(mcdata0$Poisson/mcdata0$ClaimNb),]

######################################################################

plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(path0, "plot1GLM.pdf", sep="")
if (plot.yes){pdf(file=filey1)}
plot(x=c(1:nrow(mcdata1)), y=mcdata1$Poisson/mcdata1$ClaimNb, type='l', ylim=ylim0, col="black",
                ylab="GLM estimated means", xlab="ordered by Poisson GLM estimate", cex.lab=1.5,
                main=list("GLM estimates with log-link", cex=1.5), lwd=2)
lines(x=c(1:nrow(mcdata1)), y=mcdata1$gamma/mcdata1$ClaimNb,  col="blue", lwd=2)
lines(x=c(1:nrow(mcdata1)), y=mcdata1$IG/mcdata1$ClaimNb,  col="red", lwd=2)
points(x=c(1:nrow(mcdata1)), y=mcdata1$ClaimAmount/mcdata1$ClaimNb, cex=2,pch=20, col="darkgray")
legend(x="topleft", cex=1.25, col=c("black","blue","red","darkgray"), lty=c(1,1,1,-1), lwd=c(2,2,2,-1), pch=c(-1,-1,-1,20), legend=c("Poisson", "gamma","inverse Gauss","observed"))
if (plot.yes){dev.off()}

plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(path0, "plot2GLM.pdf", sep="")
if (plot.yes){pdf(file=filey1)}
plot(x=c(1:nrow(mcdata1)), y=mcdata1$Poisson/mcdata1$ClaimNb, type='l', ylim=ylim0, col="black",
                ylab="GLM estimated means", xlab="ordered by Poisson GLM estimate", cex.lab=1.5,
                main=list("GLM estimates with canonical link", cex=1.5), lwd=2)
lines(x=c(1:nrow(mcdata1)), y=mcdata1$gammaH/mcdata1$ClaimNb, col="blue", lwd=2)
lines(x=c(1:nrow(mcdata1)), y=mcdata1$IGH/mcdata1$ClaimNb, col="red", lwd=2)
points(x=c(1:nrow(mcdata1)), y=mcdata1$ClaimAmount/mcdata1$ClaimNb, cex=2, pch=20, col="darkgray")
legend(x="topleft", cex=1.25, col=c("black","blue","red","darkgray"), lty=c(1,1,1,-1), lwd=c(2,2,2,-1), pch=c(-1,-1,-1,20), legend=c("Poisson", "gamma","inverse Gauss","observed"))
if (plot.yes){dev.off()}


######################################################################

marginal <- data.frame(mcdata0 %>% group_by(Zone) %>% summarize(
                                 Poisson     = sum(Poisson),
                                 gamma     = sum(gamma),
                                 gammaH     = sum(gammaH),
                                 IG     = sum(IG),
                                 IGH     = sum(IGH),
                                 ClaimAmount = sum(ClaimAmount),
                                 ClaimNb     = sum(ClaimNb)))

marginal[,c(2:7)] <- marginal[,c(2:7)]/marginal[,8]

plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(path0, "plot1GLMB.pdf", sep="")
if (plot.yes){pdf(file=filey1)}
barplot(t(as.matrix(marginal[,c(7,2,3,5)])), ylim=c(0,35000), col=c("darkgray","black","blue","red"), beside=TRUE, names.arg=marginal[,1], legend.text=c("observed","Poisson","gamma","inverse Gauss"),
        main=list("GLM estimated means with log-link", cex=1.5))
if (plot.yes){dev.off()}

plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(path0, "plot2GLMB.pdf", sep="")
if (plot.yes){pdf(file=filey1)}
barplot(t(as.matrix(marginal[,c(7,2,4,6)])), ylim=c(0,35000),col=c("darkgray","black","blue","red"), beside=TRUE, names.arg=marginal[,1], legend.text=c("observed","Poisson","gamma","inverse Gauss"),
        main=list("GLM estimated means with canonical link", cex=1.5))
if (plot.yes){dev.off()}

######################################################################

marginal <- data.frame(mcdata0 %>% group_by(AgeClass) %>% summarize(
                                 Poisson     = sum(Poisson),
                                 gamma     = sum(gamma),
                                 gammaH     = sum(gammaH),
                                 IG     = sum(IG),
                                 IGH     = sum(IGH),
                                 ClaimAmount = sum(ClaimAmount),
                                 ClaimNb     = sum(ClaimNb)))

marginal[,c(2:7)] <- marginal[,c(2:7)]/marginal[,8]
marginal[,1] <- paste("Age ", marginal[,1], sep="")

plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(path0, "plot1GLMC.pdf", sep="")
if (plot.yes){pdf(file=filey1)}
barplot(t(as.matrix(marginal[,c(7,2,3,5)])), ylim=c(0,35000),col=c("darkgray","black","blue","red"), beside=TRUE, names.arg=marginal[,1], legend.text=c("observed","Poisson","gamma","inverse Gauss"),
        main=list("GLM estimated means with log-link", cex=1.5))
if (plot.yes){dev.off()}

plot.yes <- TRUE
plot.yes <- FALSE
filey1 <- paste(path0, "plot2GLMC.pdf", sep="")
if (plot.yes){pdf(file=filey1)}
barplot(t(as.matrix(marginal[,c(7,2,4,6)])), ylim=c(0,35000),col=c("darkgray","black","blue","red"), beside=TRUE, names.arg=marginal[,1], legend.text=c("observed","Poisson","gamma","inverse Gauss"),
        main=list("GLM estimated means with canonical link", cex=1.5))
if (plot.yes){dev.off()}
