####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Classical GLM for claim frequencies: considering all past years
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(arrow)
library(tidyverse)
pathPlot <- "../../Plots/"

####################################################################################
### define deviance loss and negative binomial KL divergence
####################################################################################

Poisson.Deviance <- function(obs, pred){200*(sum(pred)-sum(obs)+sum(log((obs/pred)^(obs))))/length(pred)}
NB.KL.divergence <- function(true, est, phi){100*mean(true*(log(true/est)-phi/(phi-1)*log(phi/((phi-1)*est/true+1))))}

####################################################################################
### load and prepocess data for GLM
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic

dat$VehAgeGLM   <- as.factor(cut(dat$VehAge, c(-1,0,1,2,3,4,9,12, 21),
                       labels = c("0","1","2","3","4", "5-9", "10-12", "13+"),
                       include.lowest = TRUE))
dat$YearGLM  <- as.factor(dat$Year)

str(dat)

####################################################################################
### fit GLMs for all available calendar years TT
####################################################################################

phi.star <- 1.3
T0 <- 2014
T1 <- 2018

results_GLM_TT <- data.frame(array(NA, dim=c(T1-T0+1, 3)))
names(results_GLM_TT) <- c("1a_in_sample", "1b_in_sample_true", "1c_KL_in_sample")


for (TT in T0:T1){
   # fit GLM over all past years and including the Year as a categorical variable
   d.glm <- glm(ClaimNb ~ DrivAge + Gender + Leasing + LowMileage +
                       Region + CatPrice + VehAgeGLM + Deductible + YearGLM,
                       data=dat[which(dat$Year<=TT),],
                       offset=log(Exposure), family=poisson())
   # estimated means of last year
   GLM.learn <- predict(d.glm, newdata=dat[which(dat$Year==TT),], type="response")
   #
   results_GLM_TT[TT-T0+1,1] <- round(Poisson.Deviance(dat[which(dat$Year==TT),"ClaimNb"], GLM.learn),4)
   results_GLM_TT[TT-T0+1,2] <- round(Poisson.Deviance(dat[which(dat$Year==TT),"ClaimNb"], dat[which(dat$Year==TT),"True"]),4)
   results_GLM_TT[TT-T0+1,3] <- round(NB.KL.divergence(dat[which(dat$Year==TT),"True"], GLM.learn, phi.star),4)
   }

#save(data=results_GLM_TT, file="../Results/results_GLM_TT.rda")


####################################################################
####################################################################
####################################################################

load(file="../Results/results_GLM_TT.rda")
load(file="../Results/results_GLM.rda")

rbind(t(round(results_GLM[,3],3)), t(round(results_GLM_TT[,3],3)))


qq <- length(d.glm$coefficients)
beta <- exp(c(0,d.glm$coefficients[(qq-6):qq]))


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/accidentBetas.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
plot(x=c(2011:2018), y=beta, pch=20, type='l', col="blue", lwd=2, ylim=range(beta, 0.90, 1.05),
                  xlab="accident years", ylab="multiplicative factors", cex.lab=1.5,
                  main=list("accident year factors exp(beta_t)", cex=1.5))
abline(h=1)
abline(h=c(1.05, .95), lty=2)
points(x=c(2011:2018), y=beta, pch=20, col="blue", cex=3)
points(x=c(2011:2018), y=beta, pch=20, col="cyan", cex=1.5)
if (pdf.plot){dev.off()}


sigma1 <- sqrt(diag(summary(d.glm)$cov.scaled))
sigma1 <- c(0,sigma1[(qq-6):qq])
beta1 <- log(beta)

pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/accidentBetas1.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
plot(x=c(2011:2018), y=beta1, pch=20, type='l', col="blue", lwd=2, ylim=range(beta1+2*sigma1, beta1-2*sigma1),
                  xlab="accident years", ylab="regression parameters", cex.lab=1.5,
                  main=list("accident year parameters beta_t", cex=1.5))
abline(h=0, lty=2)
lines(x=c(2011:2018), y=beta1+2*sigma1, col="blue", lty=2)
lines(x=c(2011:2018), y=beta1-2*sigma1, col="blue", lty=2)
polygon(x=c(c(2011:2018), rev(c(2011:2018))), y=c(beta1+2*sigma1, rev(beta1-2*sigma1)), col=adjustcolor("blue",alpha.f=0.1), border=FALSE)
points(x=c(2011:2018), y=beta1, pch=20, col="blue", cex=3)
points(x=c(2011:2018), y=beta1, pch=20, col="cyan", cex=1.5)
if (pdf.plot){dev.off()}


####################################################################
### drop1 test (is a bit time consuming)
####################################################################

drop1(d.glm, test = c("Chisq"))
