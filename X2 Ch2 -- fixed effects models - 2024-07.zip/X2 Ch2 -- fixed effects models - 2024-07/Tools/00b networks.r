####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Neural network definition
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(keras)
library(tensorflow)

#=====================================================
# loss functions and plots
#=====================================================

plot.loss <- function(pos0, loss, title0, ylim0, col0){
    plot(loss$val_loss, col=col0[2], ylim=ylim0, main=list(title0, cex=1.5),xlab="training epochs", ylab="(modified) deviance loss", cex=1.5, cex.lab=1.5)
    lines(loss$loss,col=col0[1])
    abline(v=which.min(fit[[2]]$val_loss), col=col0[3])
    legend(x=pos0, cex=1.5, col=col0, lty=c(1,-1,1), lwd=c(1,-1,1), pch=c(-1,1,-1), legend=c("training loss", "validation loss", "minimal validation loss"))
   }

#=====================================================
# plain-vanilla neural network
#=====================================================


####
network.embedding <- function(seed, q0, lambda0, cat0, bb, output.activation){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    Design   <- layer_input(shape = c(q0[1]), dtype = 'float32')
    Cat      <- layer_input(shape = c(1), dtype = 'int32')
    Exposure <- layer_input(shape = c(1), dtype = 'float32')
    #
    CatEmb = Cat %>%
      layer_embedding(input_dim = cat0[1], output_dim = bb[1], input_length = 1) %>%
      layer_flatten()
    #
    Network = list(Design, CatEmb) %>% layer_concatenate() %>%
          layer_dense(units=q0[2], activation='tanh') %>%
          layer_dense(units=q0[3], activation='tanh') %>%
          layer_dense(units=q0[4], activation='tanh') %>%
          layer_dense(units=1, activation=output.activation,
                    weights=list(array(0, dim=c(q0[4],1)), array(log(lambda0), dim=c(1))))
    #
    Response = list(Network, Exposure) %>% layer_multiply()
    #
    keras_model(inputs = c(Design, Cat, Exposure), outputs = c(Response))
    }


