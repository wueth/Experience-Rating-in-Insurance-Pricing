####################################################################################
#########  Experience Rating in Insurance Data
#########  Pre-process data feed-forward neural network
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

PreProcess.Continuous <- function(var1, dat2){
   names(dat2)[names(dat2) == var1]  <- "V1"
   dat2$X <- as.numeric(dat2$V1)
   dat2$X <- (dat2$X-mean(dat2$X))/sd(dat2$X)
   names(dat2)[names(dat2) == "V1"]  <- var1
   names(dat2)[names(dat2) == "X"]  <- paste(var1,"X", sep="")
   dat2
   }

Features.PreProcess.Embedding <- function(dat2){
   dat2 <- PreProcess.Continuous("DrivAge", dat2)
   dat2$GenderX <- as.integer(dat2$Gender)-1
   dat2$LeasingX <- as.integer(dat2$Leasing)
   dat2$LowMileageX <- as.integer(dat2$LowMileage)
   dat2$RegionX <- as.integer(dat2$Region)-1
   dat2 <- PreProcess.Continuous("CatPrice", dat2)
   dat2 <- PreProcess.Continuous("VehAge", dat2)
   dat2$DeductibleX <- as.integer(dat$Deductible)
   dat2$Duration <- dat2$Year-dat2$StartYear
   dat2 <- PreProcess.Continuous("Duration", dat2)
   dat2 <- PreProcess.Continuous("Year", dat2)
   dat2
    }

####################################################################

dat <- Features.PreProcess.Embedding(dat)


