####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Classical GLM for claim frequencies: single calendar years
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(arrow)
library(tidyverse)
pathPlot <- "../../Plots/"

####################################################################################
### define deviance loss and negative binomial KL divergence
####################################################################################

Poisson.Deviance <- function(obs, pred){200*(sum(pred)-sum(obs)+sum(log((obs/pred)^(obs))))/length(pred)}
NB.KL.divergence <- function(true, est, phi){100*mean(true*(log(true/est)-phi/(phi-1)*log(phi/((phi-1)*est/true+1))))}

####################################################################################
### load and prepocess data for GLM
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic

dat$VehAgeGLM   <- as.factor(cut(dat$VehAge, c(-1,0,1,2,3,4,9,12, 21),
                       labels = c("0","1","2","3","4", "5-9", "10-12", "13+"),
                       include.lowest = TRUE))

str(dat)

####################################################################################
### fit GLMs for all available calendar years T >= 2014
####################################################################################

phi.star <- 1.3
T0 <- 2014
T1 <- 2018

results_GLM <- data.frame(array(NA, dim=c(T1-T0+1, 6)))
names(results_GLM) <- c("1a_in_sample", "1b_in_sample_true", "1c_KL_in_sample", "2a_out_of_sample", "2b_out_of_sample_true", "2c_KL_forecast")


for (TT in T0:T1){
   # fit GLM
   d.glm <- glm(ClaimNb ~ DrivAge + Gender + Leasing + LowMileage +
                       Region + CatPrice + VehAgeGLM + Deductible,
                       data=dat[which(dat$Year==TT),],
                       offset=log(Exposure), family=poisson())
   # estimated means and forecasting
   GLM.learn <- predict(d.glm, newdata=dat[which(dat$Year==TT),], type="response")
   GLM.test  <- predict(d.glm, newdata=dat[which(dat$Year==(TT+1)),], type="response")
   #
   results_GLM[TT-T0+1,1] <- round(Poisson.Deviance(dat[which(dat$Year==TT),"ClaimNb"], GLM.learn),4)
   results_GLM[TT-T0+1,2] <- round(Poisson.Deviance(dat[which(dat$Year==TT),"ClaimNb"], dat[which(dat$Year==TT),"True"]),4)
   results_GLM[TT-T0+1,3] <- round(NB.KL.divergence(dat[which(dat$Year==TT),"True"], GLM.learn, phi.star),4)
   results_GLM[TT-T0+1,4] <- round(Poisson.Deviance(dat[which(dat$Year==(TT+1)),"ClaimNb"], GLM.test),4)
   results_GLM[TT-T0+1,5] <- round(Poisson.Deviance(dat[which(dat$Year==(TT+1)),"ClaimNb"], dat[which(dat$Year==(TT+1)),"True"]),4)
   results_GLM[TT-T0+1,6] <- round(NB.KL.divergence(dat[which(dat$Year==(TT+1)),"True"], GLM.test, phi.star),4)
   }

#save(data=results_GLM, file="../Results/results_GLM.rda")


####################################################################################
### for comparison fit the null model
####################################################################################

results_null <- data.frame(array(NA, dim=c(T1-T0+1, 6)))
names(results_null) <- c("1a_in_sample", "1b_in_sample_true", "1c_KL_in_sample", "2a_out_of_sample", "2b_out_of_sample_true", "2c_KL_forecast")


for (TT in T0:T1){
   # fit null model
   lambda <- sum(dat[which(dat$Year==TT),"ClaimNb"])/sum(dat[which(dat$Year==TT),"Exposure"])
   # estimated means and forecasting
   null.learn <- lambda * dat[which(dat$Year==TT),"Exposure"]
   null.test  <- lambda * dat[which(dat$Year==(TT+1)),"Exposure"]
   #
   results_null[TT-T0+1,1] <- round(Poisson.Deviance(dat[which(dat$Year==TT),"ClaimNb"], null.learn),4)
   results_null[TT-T0+1,2] <- round(Poisson.Deviance(dat[which(dat$Year==TT),"ClaimNb"], dat[which(dat$Year==TT),"True"]),4)
   results_null[TT-T0+1,3] <- round(NB.KL.divergence(dat[which(dat$Year==TT),"True"], null.learn, phi.star),4)
   results_null[TT-T0+1,4] <- round(Poisson.Deviance(dat[which(dat$Year==(TT+1)),"ClaimNb"], null.test),4)
   results_null[TT-T0+1,5] <- round(Poisson.Deviance(dat[which(dat$Year==(TT+1)),"ClaimNb"], dat[which(dat$Year==(TT+1)),"True"]),4)
   results_null[TT-T0+1,6] <- round(NB.KL.divergence(dat[which(dat$Year==(TT+1)),"True"], null.test, phi.star),4)
   }

#save(data=results_null, file="../Results/results_null.rda")

####################################################################
####################################################################
####################################################################

load(file="../Results/results_GLM.rda")
load(file="../Results/results_null.rda")


t(round(results_GLM,3))


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/GLM_in_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 1
ylim0 <- range(results_null[,stats], results_GLM[,stats], results_GLM[,stats+1], results_null[,4], results_GLM[,4], results_GLM[,4+1])
plot(x=c(T0:T1), y=results_null[,stats], type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="in-sample loss", cex.lab=1.5,
                  main=list("GLM: in-sample deviance losses", cex=1.5))
points(x=c(T0:T1), y=results_null[,stats], col="black", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats], col="blue", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats+1], col="cyan", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats+1], col="cyan", pch=20, cex=3)
legend(x="topright", cex=1.5, lwd=2, pch=20, col=c("black", "blue", "cyan"), legend=c("null model", "GLM", "true model"))
if (pdf.plot){dev.off()}

pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/GLM_out_of_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 4
plot(x=c(T0:T1), y=results_null[,stats], type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="out-of-sample loss", cex.lab=1.5,
                  main=list("GLM: out-of-sample deviance losses", cex=1.5))
points(x=c(T0:T1), y=results_null[,stats], col="black", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats], col="blue", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats+1], col="cyan", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats+1], col="cyan", pch=20, cex=3)
legend(x="topleft", cex=1.5, lwd=2, pch=20, col=c("black", "blue", "cyan"), legend=c("null model", "GLM", "true model"))
if (pdf.plot==1){dev.off()}


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/GLM_KL_in_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 3
plot(x=c(T0:T1), y=results_null[,stats], type='l', lwd=2, ylim=range(0, results_null[,stats], results_GLM[,stats]),
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                  main=list("GLM: year T average KL divergence", cex=1.5))
points(x=c(T0:T1), y=results_null[,stats], col="black", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats], col="blue", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
legend(x="bottomleft", cex=1.5, lwd=2, pch=20, col=c("black", "blue"), legend=c("null model", "GLM"))
abline(h=0.2, col="darkgray", lty=2)
if (pdf.plot==1){dev.off()}

pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/GLM_KL_out_of_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 6
plot(x=c(T0:T1), y=results_null[,stats], type='l', lwd=2, ylim=range(0, results_null[,stats], results_GLM[,stats]),
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                  main=list("GLM: year T+1 average KL divergence", cex=1.5))
points(x=c(T0:T1), y=results_null[,stats], col="black", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats], col="blue", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
legend(x="bottomleft", cex=1.5, lwd=2, pch=20, col=c("black", "blue"), legend=c("null model", "GLM"))
abline(h=0.2, col="darkgray", lty=2)
if (pdf.plot==1){dev.off()}
