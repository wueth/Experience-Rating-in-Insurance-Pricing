####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Plain vanilla feed-forward neural network
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(arrow)
library(tidyverse)

pathPlot <- "../../Plots/"

####################################################################################
### load and prepocess data for FNN modeling
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic
source("./Tools/00a preprocess data FNN.R")
str(dat)

####################################################################################
### define loss and scoring functions
####################################################################################

Poisson.Deviance <- function(obs, pred){200*(sum(pred)-sum(obs)+sum(log((obs/pred)^(obs))))/length(pred)}
NB.KL.divergence <- function(true, est, phi){100*mean(true*(log(true/est)-phi/(phi-1)*log(phi/((phi-1)*est/true+1))))}

####################################################################################
### fit FNNs to the available calendar years TT
####################################################################################

source("./Tools/00b networks.R")

phi.star <- 1.3
T0 <- 2014
T1 <- 2018

features <- c("DrivAgeX", "GenderX", "LeasingX", "LowMileageX", "CatPriceX", "VehAgeX", "DeductibleX")
(q0 <- length(features))
(q00 <- c(q0, c(20,15,10)))

K0 <- 10    # ensembling parameter

results_FNN <- data.frame(array(NA, dim=c(T1-T0+1, 6)))
names(results_FNN) <- c("1a_in_sample", "1b_in_sample_true", "1c_KL_in_sample", "2a_out_of_sample", "2b_out_of_sample_true", "2c_KL_forecast")


for (TT in T0:T1){
   learn <- dat[which(dat$Year==TT),]        # learning data
   test <- dat[which(dat$Year==(TT+1)),]     # out-of-sample prediction
   lambda.hom <- sum(learn$ClaimNb)/sum(learn$Exposure)
   set.seed(300+TT)
   ll <- sample(x=c(1:nrow(learn)), size=floor(0.8*nrow(learn)))
   Xlearn <- as.matrix(learn[ll, features])  # training sample U
   Relearn <- as.matrix(learn[ll,]$RegionX)
   Vlearn <- as.matrix(learn[ll,]$Exposure)
   Xvali <- as.matrix(learn[-ll, features])  # validation sample V
   Revali <- as.matrix(learn[-ll,]$RegionX)
   Vvali <- as.matrix(learn[-ll,]$Exposure)
   Xtest <- as.matrix(test[, features])      # test sample T (out-of-sample)
   Retest <- as.matrix(test$RegionX)
   Vtest <- as.matrix(test$Exposure)
   Xlearn2 <- as.matrix(learn[, features])   # learning sample L=U+V
   Relearn2 <- as.matrix(learn$RegionX)
   Vlearn2 <- as.matrix(learn$Exposure)
   Ylearn <- as.matrix(learn[ll,]$ClaimNb)
   Yvali <- as.matrix(learn[-ll,]$ClaimNb)
   N.Region <- length(unique(learn$RegionX))  # number of categorical levels
   embedding.dim <- 2
   for (k1 in 1:K0){
     seed <- 100 + k1 - 1
     model <- network.embedding(seed, q00, lambda.hom, N.Region, embedding.dim, "exponential")
     path0 <- paste("./Networks/FNN1_year",TT,"_seed_",seed, ".h5", sep="")
     CBs <- callback_model_checkpoint(path0, monitor = "val_loss", verbose = 0,  save_best_only = TRUE, save_weights_only = TRUE)
     model %>% compile(loss = 'poisson', optimizer = 'nadam')
     ##
     #{t1 <- proc.time()
     # fit <- model %>% fit(list(Xlearn, Relearn, Vlearn),  Ylearn,
     #               validation_data=list(list(Xvali, Revali,Vvali),Yvali),
     #               batch_size=2^12, epochs=200, verbose=1, callbacks=CBs)
     #(proc.time()-t1)[3]}
     #which.min(fit[[2]]$val_loss)
     #title0 <- paste("SGD: year ", TT, ", run ", k1, sep="")
     ##pdf.plot <- TRUE
     ##pdf.plot <- FALSE
     ##filey1 <- paste(pathPlot, "/Ch2/SGD1.pdf", sep="")
     ##if (pdf.plot){pdf(file=filey1)}
     #plot.loss("topright", fit[[2]], title0, ylim0=range(fit[[2]]), col0=c("blue","darkgreen", "orange"))
     ##if (pdf.plot){dev.off()}
     # results
     load_model_weights_hdf5(model, path0)
     w1 <- get_weights(model)
     if (k1==1){
       learn.NN <- model %>% predict(list(Xlearn2, Relearn2, Vlearn2), batch_size=10^6)/K0
       test.NN <- model %>% predict(list(Xtest, Retest, Vtest), batch_size=10^6)/K0
               }else{
       learn.NN <- learn.NN + model %>% predict(list(Xlearn2, Relearn2, Vlearn2), batch_size=10^6)/K0
       test.NN <- test.NN + model %>% predict(list(Xtest, Retest, Vtest), batch_size=10^6)/K0
               }}
   #
   results_FNN[TT-T0+1,1] <- round(Poisson.Deviance(dat[which(dat$Year==TT),"ClaimNb"], learn.NN),4)
   results_FNN[TT-T0+1,2] <- round(Poisson.Deviance(dat[which(dat$Year==TT),"ClaimNb"], dat[which(dat$Year==TT),"True"]),4)
   results_FNN[TT-T0+1,3] <- round(NB.KL.divergence(dat[which(dat$Year==TT),"True"], learn.NN, phi.star),4)
   results_FNN[TT-T0+1,4] <- round(Poisson.Deviance(dat[which(dat$Year==(TT+1)),"ClaimNb"], test.NN),4)
   results_FNN[TT-T0+1,5] <- round(Poisson.Deviance(dat[which(dat$Year==(TT+1)),"ClaimNb"], dat[which(dat$Year==(TT+1)),"True"]),4)
   results_FNN[TT-T0+1,6] <- round(NB.KL.divergence(dat[which(dat$Year==(TT+1)),"True"], test.NN, phi.star),4)
   }

#save(data=results_FNN, file="../Results/results_FNN.rda")

####################################################################
####################################################################
####################################################################

load(file="../Results/results_null.rda")
load(file="../Results/results_GLM.rda")
load(file="../Results/results_FNN.rda")


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/FNN_in_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 1
ylim0 <- range(results_null[,stats], results_GLM[,stats], results_GLM[,stats+1], results_null[,4], results_GLM[,4], results_GLM[,4+1])
plot(x=c(T0:T1), y=results_null[,stats], type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="in-sample loss", cex.lab=1.5,
                  main=list("FNN: in-sample deviance losses", cex=1.5))
points(x=c(T0:T1), y=results_null[,stats], col="black", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats], col="blue", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats+1], col="cyan", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats+1], col="cyan", pch=20, cex=3)
lines(x=c(T0:T1), y=results_FNN[,stats], col="green", lwd=2)
points(x=c(T0:T1), y=results_FNN[,stats], col="green", pch=20, cex=3)
legend(x="topright", cex=1.5, lwd=2, pch=20, col=c("black", "blue", "green", "cyan"), legend=c("null model", "GLM", "FNN", "true model"))
if (pdf.plot){dev.off()}

pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/FNN_out_of_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 4
plot(x=c(T0:T1), y=results_null[,stats], type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="out-of-sample loss", cex.lab=1.5,
                  main=list("FNN: out-of-sample deviance losses", cex=1.5))
points(x=c(T0:T1), y=results_null[,stats], col="black", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats], col="blue", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats+1], col="cyan", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats+1], col="cyan", pch=20, cex=3)
lines(x=c(T0:T1), y=results_FNN[,stats], col="green", lwd=2)
points(x=c(T0:T1), y=results_FNN[,stats], col="green", pch=20, cex=3)
legend(x="topright", cex=1.5, lwd=2, pch=20, col=c("black", "blue", "green", "cyan"), legend=c("null model", "GLM", "FNN", "true model"))
if (pdf.plot==1){dev.off()}



pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/FNN_KL_in_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 3
plot(x=c(T0:T1), y=results_null[,stats], type='l', lwd=2, ylim=range(0, results_null[,stats], results_GLM[,stats], results_FNN[,stats]),
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                  main=list("FNN: year T average KL divergence", cex=1.5))
points(x=c(T0:T1), y=results_null[,stats], col="black", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats], col="blue", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
lines(x=c(T0:T1), y=results_FNN[,stats], col="green", lwd=2)
points(x=c(T0:T1), y=results_FNN[,stats], col="green", pch=20, cex=3)
legend(x="bottomright", cex=1.5, lwd=2, pch=20, col=c("black", "blue", "green"), legend=c("null model", "GLM", "FNN"))
if (pdf.plot==1){dev.off()}

pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/FNN_KL_out_of_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 6
plot(x=c(T0:T1), y=results_null[,stats], type='l', lwd=2, ylim=range(0, results_null[,stats], results_GLM[,stats], results_FNN[,stats]),
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                  main=list("FNN: year T+1 average KL divergence", cex=1.5))
points(x=c(T0:T1), y=results_null[,stats], col="black", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats], col="blue", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
lines(x=c(T0:T1), y=results_FNN[,stats], col="green", lwd=2)
points(x=c(T0:T1), y=results_FNN[,stats], col="green", pch=20, cex=3)
legend(x="bottomright", cex=1.5, lwd=2, pch=20, col=c("black", "blue", "green"), legend=c("null model", "GLM", "FNN"))
if (pdf.plot==1){dev.off()}





