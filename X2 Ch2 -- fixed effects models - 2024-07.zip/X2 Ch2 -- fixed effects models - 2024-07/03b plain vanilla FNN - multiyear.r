####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Plain vanilla feed-forward neural network: multi-year
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(arrow)
library(tidyverse)
pathPlot <- "../../Plots/"

####################################################################################
### load and prepocess data for FNN modeling
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic
source("./Tools/00a preprocess data FNN.R")
str(dat)

####################################################################################
### define loss and scoring functions
####################################################################################

Poisson.Deviance <- function(obs, pred){200*(sum(pred)-sum(obs)+sum(log((obs/pred)^(obs))))/length(pred)}
NB.KL.divergence <- function(true, est, phi){100*mean(true*(log(true/est)-phi/(phi-1)*log(phi/((phi-1)*est/true+1))))}

####################################################################################
### fit FNNs all the available calendar years TT
####################################################################################

source("./Tools/00b networks.R")

phi.star <- 1.3
T0 <- 2014
T1 <- 2018

# we add the calendar year variable YearX
(features <- c("YearX", "DrivAgeX", "GenderX", "LeasingX", "LowMileageX", "CatPriceX", "VehAgeX", "DeductibleX"))
(q0 <- length(features))
(q00 <- c(q0, c(20,15,10)))

K0 <- 10    # ensembling parameter

results_FNN_multi <- data.frame(array(NA, dim=c(T1-T0+1, 6)))
names(results_FNN_multi) <- c("1a_in_sample", "1b_in_sample_true", "1c_KL_in_sample", "2a_out_of_sample", "2b_out_of_sample_true", "2c_KL_forecast")


for (TT in T0:T1){
   learn <- dat[which(dat$Year<=TT),]  # this uses all past data, but not in a time-series structure(!)
   learnT <- dat[which(dat$Year==TT),]
   test <- dat[which(dat$Year==(TT+1)),]
   lambda.hom <- sum(learn$ClaimNb)/sum(learn$Exposure)
   set.seed(300+TT)
   ll <- sample(x=c(1:nrow(learn)), size=floor(0.8*nrow(learn)))
   Xlearn <- as.matrix(learn[ll, features])
   Relearn <- as.matrix(learn[ll,]$RegionX)
   Vlearn <- as.matrix(learn[ll,]$Exposure)
   Xvali <- as.matrix(learn[-ll, features])
   Revali <- as.matrix(learn[-ll,]$RegionX)
   Vvali <- as.matrix(learn[-ll,]$Exposure)
   Xtest <- as.matrix(test[, features])
   Retest <- as.matrix(test$RegionX)
   Vtest <- as.matrix(test$Exposure)
   XlearnT <- as.matrix(learnT[, features])
   RelearnT <- as.matrix(learnT$RegionX)
   VlearnT <- as.matrix(learnT$Exposure)
   Ylearn <- as.matrix(learn[ll,]$ClaimNb)
   Yvali <- as.matrix(learn[-ll,]$ClaimNb)
   N.Region <- length(unique(learn$RegionX))
   embedding.dim <- 2
   for (k1 in 1:K0){
     seed <- 100 + k1 - 1
     model <- network.embedding(seed, q00, lambda.hom, N.Region, embedding.dim, "exponential")
     path0 <- paste("./Networks/FNN1_multiyear",TT,"_seed_",seed,".h5", sep="")
     CBs <- callback_model_checkpoint(path0, monitor = "val_loss", verbose = 0,  save_best_only = TRUE, save_weights_only = TRUE)
     model %>% compile(loss = 'poisson', optimizer = 'nadam')
     ##
     {t1 <- proc.time()
      fit <- model %>% fit(list(Xlearn, Relearn, Vlearn),  Ylearn,
                    validation_data=list(list(Xvali, Revali,Vvali),Yvali),
                    batch_size=2^12, epochs=100, verbose=1, callbacks=CBs)
     (proc.time()-t1)[3]}
     title0 <- paste("SGD: year ", TT, ", run ", k1, sep="")
     plot.loss("topright", fit[[2]], title0, ylim0=range(fit[[2]]), col0=c("blue","darkgreen", "orange"))
     # results
     load_model_weights_hdf5(model, path0)
     if (k1==1){
       learn.NN <- model %>% predict(list(XlearnT, RelearnT, VlearnT), batch_size=10^6)/K0
       test.NN <- model %>% predict(list(Xtest, Retest, Vtest), batch_size=10^6)/K0
               }else{
       learn.NN <- learn.NN + model %>% predict(list(XlearnT, RelearnT, VlearnT), batch_size=10^6)/K0
       test.NN <- test.NN + model %>% predict(list(Xtest, Retest, Vtest), batch_size=10^6)/K0
              }
       }
   results_FNN_multi[TT-T0+1,1] <- round(Poisson.Deviance(dat[which(dat$Year==TT),"ClaimNb"], learn.NN),4)
   results_FNN_multi[TT-T0+1,2] <- round(Poisson.Deviance(dat[which(dat$Year==TT),"ClaimNb"], dat[which(dat$Year==TT),"True"]),4)
   results_FNN_multi[TT-T0+1,3] <- round(NB.KL.divergence(dat[which(dat$Year==TT),"True"], learn.NN, phi.star),4)
   results_FNN_multi[TT-T0+1,4] <- round(Poisson.Deviance(dat[which(dat$Year==(TT+1)),"ClaimNb"], test.NN),4)
   results_FNN_multi[TT-T0+1,5] <- round(Poisson.Deviance(dat[which(dat$Year==(TT+1)),"ClaimNb"], dat[which(dat$Year==(TT+1)),"True"]),4)
   results_FNN_multi[TT-T0+1,6] <- round(NB.KL.divergence(dat[which(dat$Year==(TT+1)),"True"], test.NN, phi.star),4)
   }

#save(data=results_FNN_multi, file="../Results/results_FNN_multi.rda")

####################################################################
####################################################################
####################################################################

load(file="../Results/results_null.rda")
load(file="../Results/results_GLM.rda")
load(file="../Results/results_FNN.rda")
load(file="../Results/results_FNN_multi.rda")



pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/FNN2_KL_in_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 3
plot(x=c(T0:T1), y=results_null[,stats], type='l', lwd=2, ylim=range(0, results_null[,stats], results_GLM[,stats], results_FNN[,stats]),
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                  main=list("FNN: year T average KL divergence", cex=1.5))
points(x=c(T0:T1), y=results_null[,stats], col="black", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats], col="blue", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
lines(x=c(T0:T1), y=results_FNN[,stats], col="green", lwd=2)
points(x=c(T0:T1), y=results_FNN[,stats], col="green", pch=20, cex=3)
lines(x=c(T0:T1), y=results_FNN_multi[,stats], col="darkgreen", lwd=2)
points(x=c(T0:T1), y=results_FNN_multi[,stats], col="darkgreen", pch=20, cex=3)
legend(x="bottomright", cex=1.5, lwd=2, pch=20, col=c("black", "blue", "green", "darkgreen"), legend=c("null model", "GLM", "FNN", "FNN all T"))
if (pdf.plot==1){dev.off()}

pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/FNN2_KL_out_of_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 6
plot(x=c(T0:T1), y=results_null[,stats], type='l', lwd=2, ylim=range(0, results_null[,stats], results_GLM[,stats], results_FNN[,stats]),
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                  main=list("FNN: year T+1 average KL divergence", cex=1.5))
points(x=c(T0:T1), y=results_null[,stats], col="black", pch=20, cex=3)
lines(x=c(T0:T1), y=results_GLM[,stats], col="blue", lwd=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
lines(x=c(T0:T1), y=results_FNN[,stats], col="green", lwd=2)
points(x=c(T0:T1), y=results_FNN[,stats], col="green", pch=20, cex=3)
lines(x=c(T0:T1), y=results_FNN_multi[,stats], col="darkgreen", lwd=2)
points(x=c(T0:T1), y=results_FNN_multi[,stats], col="darkgreen", pch=20, cex=3)
legend(x="bottomright", cex=1.5, lwd=2, pch=20, col=c("black", "blue", "green", "darkgreen"), legend=c("null model", "GLM", "FNN", "FNN all T"))
if (pdf.plot==1){dev.off()}


####

t(round(results_FNN[,c(3,6)],3))
t(round(results_FNN_multi[,c(3,6)],3))