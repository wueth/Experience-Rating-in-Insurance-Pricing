####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Auto-calibration
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(arrow)
library(tidyverse)

pathPlot <- "../../Plots/"

####################################################################################
### load and prepocess data for FNN modeling
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic
source("./Tools/00a preprocess data FNN.R")
str(dat)

####################################################################################
### define loss and scoring functions
####################################################################################

Poisson.Deviance <- function(obs, pred){200*(sum(pred)-sum(obs)+sum(log((obs/pred)^(obs))))/length(pred)}
NB.KL.divergence <- function(true, est, phi){100*mean(true*(log(true/est)-phi/(phi-1)*log(phi/((phi-1)*est/true+1))))}

####################################################################################
### load FNNs for a fixed calendar year
####################################################################################

source("./Tools/00b networks.R")

phi.star <- 1.3
TT <- 2018

features <- c("DrivAgeX", "GenderX", "LeasingX", "LowMileageX", "CatPriceX", "VehAgeX", "DeductibleX")
(q0 <- length(features))
(q00 <- c(q0, c(20,15,10)))

K0 <- 10    # ensembling parameter

learn <- dat[which(dat$Year==TT),]        # learning data
test <- dat[which(dat$Year==(TT+1)),]     # out-of-sample prediction
lambda.hom <- sum(learn$ClaimNb)/sum(learn$Exposure)
Xtest <- as.matrix(test[, features])
Retest <- as.matrix(test$RegionX)
Vtest <- as.matrix(test$Exposure)
Xlearn2 <- as.matrix(learn[, features])
Relearn2 <- as.matrix(learn$RegionX)
Vlearn2 <- as.matrix(learn$Exposure)
N.Region <- length(unique(learn$RegionX))
embedding.dim <- 2
# load fitted networks and make forecasts
for (k1 in 1:K0){
     seed <- 100 + k1 - 1
     model <- network.embedding(seed=100, q00, lambda.hom, N.Region, embedding.dim, "exponential")
     path0 <- paste("./Networks/FNN1_year",TT,"_seed_",seed, ".h5", sep="")
     load_model_weights_hdf5(model, path0)
     if (k1==1){
       learn.NN <- model %>% predict(list(Xlearn2, Relearn2, Vlearn2), batch_size=10^6)/K0
       test.NN <- model %>% predict(list(Xtest, Retest, Vtest), batch_size=10^6)/K0
               }else{
       learn.NN <- learn.NN + model %>% predict(list(Xlearn2, Relearn2, Vlearn2), batch_size=10^6)/K0
       test.NN <- test.NN + model %>% predict(list(Xtest, Retest, Vtest), batch_size=10^6)/K0
            }}


learn$pred <- as.vector(learn.NN)
test$pred  <- as.vector(test.NN)

####################################################################################
### isotonic recalibration: test against the observations
####################################################################################

library(monotone)

## compute frequencies
learn$lambda <- learn$pred/learn$Exposure

## perform isotonic regression
learn2 <- learn
learn2 <- learn2[order(learn2$lambda),]
learn2$Y <- learn2$ClaimNb/learn2$Exposure
iso1 <- monotone(x=learn2$Y, w = learn2$Exposure)

## number of different values
c(length(unique(iso1)), length(unique(learn2$lambda)))

## isotonic regression forecast
learn2$iso <- iso1
fit0 <- stepfun(learn2$lambda, c(0,learn2$iso))
learn$iso1 <- fit0(learn$lambda)

## global balance property
c(lambda.hom, sum(learn$iso1*learn$Exposure)/sum(learn$Exposure))

## outlier check at the boundary
plot(x=learn$lambda, y=learn$iso1, ylab="isotonic regression", xlab="neural network forecast", main=list("T-reliability diagram", cex=1.5))

# there seem to be two outliers at both boundaries -> merge classes
(mm <- sort(unique(learn$iso1))[1:5])
k1 <- 3
(vv <- sum(learn[which(learn$iso1 <= mm[k1]),]$ClaimNb)/sum(learn[which(learn$iso1 <= mm[k1]),]$Exposure))
learn[which(learn$iso1 <= mm[k1]),]$iso1 <- vv

(mm <- rev(sort(unique(learn$iso1)))[1:5])
k1 <- 3
(vv <- sum(learn[which(learn$iso1 >= mm[k1]),]$ClaimNb)/sum(learn[which(learn$iso1 >= mm[k1]),]$Exposure))
learn[which(learn$iso1 >= mm[k1]),]$iso1 <- vv

## global balance property
c(lambda.hom, sum(learn$iso1*learn$Exposure)/sum(learn$Exposure))
length(unique(learn$iso1))

####################################################################################
### T-reliability diagram
####################################################################################

set.seed(100)
ll <- sample(size=5000, x=c(1:nrow(learn)))

pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/isotonic_insample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
ylim0 <- range(learn$lambda, learn$iso1, 0.02)
plot(x=learn[ll,]$lambda, y=learn[ll,]$iso1, ylim=ylim0, xlim=ylim0,
                  ylab="isotonic regression", xlab="FNN estimated frequency", cex.lab=1.5,
                  main=list("T-reliability diagram", cex=1.5))
abline(a=0, b=1, col="orange", lwd=2)
par(new=TRUE)
plot(density(learn$lambda, from=ylim0[1], to=ylim0[2]), xaxt='n', yaxt='n', cex.lab=1.5, xlab="", ylab="", lwd=3, col="blue", main="")
axis(4, col="blue", col.axis="blue")
if (pdf.plot){dev.off()}


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch2/isotonic_insample_log.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
ylim0 <- log(range(learn$lambda, learn$iso1))
plot(x=log(learn[ll,]$lambda), y=log(learn[ll,]$iso1), ylim=ylim0, xlim=ylim0,
                  ylab="isotonic regression (log-scale)", xlab="FNN estimated frequency (log-scale)", cex.lab=1.5,
                  main=list("T-reliability diagram", cex=1.5))
abline(a=0, b=1, col="orange", lwd=2)
if (pdf.plot){dev.off()}

