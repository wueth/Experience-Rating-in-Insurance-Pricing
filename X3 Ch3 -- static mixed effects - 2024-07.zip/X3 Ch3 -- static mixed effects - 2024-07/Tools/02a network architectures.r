####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Network architectures
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(keras)
library(tensorflow)

#=====================================================
# loss functions and plots
#=====================================================

plot.loss <- function(pos0, loss, title0, ylim0, col0){
    plot(loss$val_loss, col=col0[2], ylim=ylim0, main=list(title0, cex=1.5),xlab="training epochs", ylab="(modified) deviance loss", cex=1.5, cex.lab=1.5)
    lines(loss$loss,col=col0[1])
    abline(v=which.min(fit[[2]]$val_loss), col=col0[3])
    legend(x=pos0, cex=1.5, col=col0, lty=c(1,-1,1), lwd=c(1,-1,1), pch=c(-1,1,-1), legend=c("training loss", "validation loss", "minimal validation loss"))
   }

#=====================================================
# GLM for static mixed effects
#=====================================================

GLM <- function(seed, lookback, q0, output.acti){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    Design   <- layer_input(shape = c(lookback, q0[1]), dtype = 'float32')
    Exposure <- layer_input(shape = c(lookback), dtype = 'float32')
    Bias     <- layer_input(shape = c(1), dtype = 'float32')
    #
    Network = Design %>%
          time_distributed(layer_dense(units=1, activation=output.acti)) %>%
          layer_flatten()
    # estimates the shape parameter
    Alpha = Bias %>% layer_dense(units=1, activation="exponential",
                                 use_bias=FALSE, weights=list(array(0, dim=c(1,1))))
    # estimates the mean
    GLM = list(Network, Exposure) %>% layer_multiply()
    #
    Response = list(GLM, Alpha) %>% layer_concatenate()
    #
    keras_model(inputs = c(Design, Exposure, Bias), outputs = c(Response))
    }

#=====================================================
# FNN for static mixed effects
#=====================================================

NN.SME <- function(seed, lookback, q0, cat0, bb, output.acti){
    k_clear_session()
    set.seed(seed)
    set_random_seed(seed)
    Design   <- layer_input(shape = c(lookback, q0[1]), dtype = 'float32')
    Exposure <- layer_input(shape = c(lookback), dtype = 'float32')
    Bias     <- layer_input(shape = c(1), dtype = 'float32')
    Cat0     <- layer_input(shape = c(lookback, 1), dtype = 'int32')
    #
    CatEmb0 = Cat0 %>%
      time_distributed(layer_embedding(input_dim = cat0[1], output_dim = bb[1], input_length = 1)) %>%
      time_distributed(layer_flatten())
    #
    Network = list(Design, CatEmb0) %>% layer_concatenate() %>%
          time_distributed(layer_dense(units=q0[2], activation='tanh')) %>%
          time_distributed(layer_dense(units=q0[3], activation='tanh')) %>%
          time_distributed(layer_dense(units=q0[4], activation='tanh')) %>%
          time_distributed(layer_dense(units=1, activation=output.acti)) %>%
          layer_flatten()
    # estimation of shape parameter
    Alpha = Bias %>% layer_dense(units=1, activation="exponential",
                                 use_bias=FALSE, weights=list(array(0, dim=c(1,1))))
    # estimation of mean parameter
    Output = list(Network, Exposure) %>% layer_multiply()
    #
    Response = list(Output, Alpha) %>% layer_concatenate()
    #
    keras_model(inputs = c(Design, Exposure, Cat0, Bias), outputs = c(Response))
    }

