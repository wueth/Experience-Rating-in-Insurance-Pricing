####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Static mixed effects neural network
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(arrow)
library(tidyverse)
library(keras)
library(tensorflow)

pathPlot <- "../../Plots/"


####################################################################################
### load and pre-process data
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic
str(dat)

labelNN <- c("ClaimNb", "True", "DrivAgeX", "GenderX", "LeasingX",
            "LowMileageX", "CatPriceX", "DeductibleX",
            "DurationX", "YearX",
            "VehAgeX", "RegionX", "YearCatNN")

source("./Tools/01b static mixed effects - load data NN.r")

tensor <- tensorNN
dim(tensor)

# continuous covariates for neural network
NN.XX <- c(5:10, 13) # 1=Observation YES/NO, 2=Exposure, 3=ClaimNb, 4=True, 11=Duration, 12=YearX
labelNN[NN.XX-2]

# categorical covariate for embedding layer
NN.Region <- c(14)
labelNN[NN.Region-2]
no.of.regions <- 15

####################################################################################
### set parameters and define loss functions
####################################################################################

Poisson.Deviance <- function(obs, pred){200*(sum(pred)-sum(obs)+sum(log((obs/pred)^(obs))))/length(pred)}
NB.KL.divergence <- function(true, est, phi){100*mean(true*(log(true/est)-phi/(phi-1)*log(phi/((phi-1)*est/true+1))))}

phi.star <- 1.3
T0 <- 2014
T1 <- 2018

####################################################################################
### NN network
####################################################################################

source("./Tools/02a network architectures.R")

####################################################################################
### one year ahead empirical Bayes
####################################################################################

results_SME_FNN0 <- data.frame(array(NA, dim=c(T1-T0+1, 4)))
names(results_SME_FNN0) <- c("a_KL_in_sample", "a0_KL_in_sample_hom", "a_KL_out_of_sample", "a0_KL_out_of_sample_hom")

J0 <- 10  # ensembling parameter

for (tt in c(T0:T1)){
  TT <- tt-2011+1
  # preparation of data
  for (j0 in 1:J0){
    dat.Obs    <- tensor[,2:(TT+1),1]        # indicator for observation yes/no
    index      <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT]==1)]  # only select active policies
    tensor0    <- tensor[index,,]
    set.seed(200+j0)  # randomize order for stochastic gradient descent
    index0     <- sample(c(1:length(index)), size=length(index))
    dat.Expo   <- tensor0[index0,2:(TT+1),2]         # exposure
    dat.YY     <- tensor0[index0,1:2,3]              # prepare tensor for claims
    dat.YY[,1] <- rowSums(tensor0[index0,2:TT,3])    # sum of past claims
    dat.YY[,2] <- tensor0[index0,TT+1,3]             # actual claims
    dat.True   <- tensor0[index0,TT+1,4]             # true frequency
    dat.XX     <- tensor0[index0,2:(TT+1),NN.XX]     # selected continuous covariates
    dat.Reg    <- tensor0[index0,2:(TT+1),NN.Region] # categorical covariate
    dat.alpha  <- array(1, dim=c(nrow(tensor0[index0,,1]),1)) # shape parameter
    ### selection of feed-forward neural network
    (q0 <- c(dim(dat.XX)[3], 20, 15, 10))
    seed <- 100 + j0 - 1
    model <- NN.SME(seed, lookback=TT, q0, cat0=c(no.of.regions), bb=c(2), "exponential")
    w0 <- get_weights(model)
    w0[[8]] <- array(0, dim=dim(w0[[8]]))
    w0[[9]] <- array(log(0.1), dim=dim(w0[[9]]))
    set_weights(model, w0)
    ## definition of loss function
    Q_loss <- function(y_true, y_pred){
      mu       <- y_pred[,1:TT]
      alpha    <- y_pred[,TT+1]
      YY.0     <- y_true[,1]
      YY.1     <- y_true[,2]
      mu.0     <- k_sum(mu[,1:(TT-1)],, axis=2)
      mu.1     <- mu[,TT]
      -k_sum(+tf$math$lgamma(alpha+YY.0+YY.1)-tf$math$lgamma(alpha+YY.0) +
             (alpha+YY.0)*k_log((alpha+mu.0)/(alpha+mu.0+mu.1)) +
              YY.1*k_log(mu.1/(alpha+mu.0+mu.1)))
          }
    ## FNN fitting
    path1 <- paste("./Networks/MixedNN",seed,"_", tt,"_", j0,".h5", sep="")
    model %>% compile(loss = Q_loss, optimizer = 'nadam')
    CBs <- callback_model_checkpoint(path1, monitor = "val_loss", verbose = 0,  save_best_only = TRUE, save_weights_only = TRUE)
    #{t1 <- proc.time()
    #   fit <- model %>% fit(list(dat.XX, dat.Expo, dat.Reg, dat.alpha), dat.YY,
    #                validation_split=0.2,
    #                batch_size=5000, epochs=200, verbose=0, callbacks=CBs)
    #(proc.time()-t1)[3]}
    #plot.loss("topright", fit[[2]], paste("validation loss T=",tt,", j=", j0,sep=""), ylim0=range(fit[[2]]), col0=c("blue","darkgreen", "orange"))
    load_model_weights_hdf5(model, path1)
    w0 <- get_weights(model)
    dat.Obs    <- tensor[,2:(TT+1),1]
    index      <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT]==1)]
    dat.Expo   <- tensor[index,2:(TT+1),2]
    dat.YY     <- tensor[index,1:2,3]
    dat.YY[,1] <- rowSums(tensor[index,2:(TT),3])
    dat.True   <- tensor[index,TT+1,4]
    dat.XX     <- tensor[index,2:(TT+1),NN.XX]
    dat.Reg    <- tensor[index,2:(TT+1),NN.Region]
    pred <- (model %>% predict(list(dat.XX, dat.Expo, dat.Reg, dat.alpha), batch_size=10^6))
    alpha <- pred[,TT+1]
    pred <- pred[,1:(TT)]
    post.0  <- rowSums(pred[,1:(TT-1)])
    dat.YY[,2] <- post.0
    dat.YY[which(dat.YY[,2]>0),1] <- dat.YY[which(dat.YY[,2]>0),1]/dat.YY[which(dat.YY[,2]>0),2]
    # homogeneous Buhlmann-Straub collective mean
    mu.hom <- sum(post.0/(post.0+alpha)*dat.YY[,1])/sum(post.0/(post.0+alpha))
    if (j0==1){
      post1 <- pred[,TT]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha))/J0
      post1.hom <- pred[,TT]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha)*mu.hom)/J0
              }else{
      post1 <- post1 + pred[,TT]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha))/J0
      post1.hom <- post1.hom + pred[,TT]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha)*mu.hom)/J0
                  }
    if (j0==J0){
      results_SME_FNN0[tt-T0+1,2] <- round(NB.KL.divergence(dat.True, post1.hom, phi.star),4)
      results_SME_FNN0[tt-T0+1,1] <- round(NB.KL.divergence(dat.True, post1, phi.star),4)
               }
    ## out-of-sample
    dat.Obs    <- tensor[,2:(TT+2),1]
    index      <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT+1]==1)]
    dat.Expo   <- tensor[index,2:(TT+2),2]
    dat.YY     <- tensor[index,1:2,3]
    dat.YY[,1] <- rowSums(tensor[index,2:(TT+1),3])
    dat.True   <- tensor[index,TT+2,4]
    dat.XX     <- tensor[index,2:(TT+2),NN.XX]
    dat.Reg     <- tensor[index,2:(TT+2),NN.Region]
    dat.alpha  <- array(1, dim=c(nrow(tensor[index,,1]),1)) # shape parameter
    model <- NN.SME(seed, lookback=TT+1, q0, cat0=c(no.of.regions), bb=c(2), "exponential")
    set_weights(model, w0)
    pred <- (model %>% predict(list(dat.XX, dat.Expo, dat.Reg, dat.alpha), batch_size=10^6))
    alpha <- pred[,TT+2]
    pred <- pred[,1:(TT+1)]
    post.0  <- rowSums(pred[,1:TT])
    dat.YY[,2] <- post.0
    dat.YY[which(dat.YY[,2]>0),1] <- dat.YY[which(dat.YY[,2]>0),1]/dat.YY[which(dat.YY[,2]>0),2]
    if (j0==1){
      post2 <- pred[,TT+1]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha))/J0
      post2.hom <- pred[,TT+1]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha)*mu.hom)/J0
              }else{
      post2 <- post2 + pred[,TT+1]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha))/J0
      post2.hom <- post2.hom + pred[,TT+1]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha)*mu.hom)/J0
                  }
    if (j0==J0){
      results_SME_FNN0[tt-T0+1,4] <- round(NB.KL.divergence(dat.True, post2.hom, phi.star),4)
      results_SME_FNN0[tt-T0+1,3] <- round(NB.KL.divergence(dat.True, post2, phi.star),4)
               }
        }
   }

#save(data=results_SME_FNN0, file="../Results/results_SME_FNN0.rda")

results_SME_FNN0


######################

load(file="../Results/results_GLM.rda")
load(file="../Results/results_FNN.rda")
load(file="../Results/results_SME_GLM_1Year.rda")
load(file="../Results/results_SME_FNN0.rda")


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch3/SME_FNN_KL_in_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
ylim0 <- range(0,0.28)
stats <- 3
plot(x=c(T0:T1), y=results_GLM[,stats], col="blue", type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                  main=list("static mixed effects: KL divergence T", cex=1.5))
lines(x=c(T0:T1), y=results_FNN[,stats], col="green", lwd=2)
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,1], col="pink", lwd=2)
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,2], col="pink", lwd=2, lty=2)
lines(x=c(T0:T1), y=results_SME_FNN0[,1], col="orange", lwd=2)
lines(x=c(T0:T1), y=results_SME_FNN0[,2], col="orange", lwd=2, lty=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
points(x=c(T0:T1), y=results_FNN[,stats], col="green", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,1], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,2], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_FNN0[,1], col="orange", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_FNN0[,2], col="orange", pch=20, cex=3)
legend(x="bottomleft", cex=1.5, lty=c(1,1,1,2,1,2), lwd=2, pch=20, col=c("blue", "green", "pink", "pink", "orange", "orange"), legend=c("GLM", "FNN", "SME GLM (b)", "SME GLM (b0)", "SME FNN (b)", "SME FNN (b0)"))
if (pdf.plot==1){dev.off()}


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch3/SME_FNN_KL_out_of_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 6
plot(x=c(T0:T1), y=results_GLM[,stats], col="blue", type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                   main=list("static mixed effects: KL divergence T+1", cex=1.5))
lines(x=c(T0:T1), y=results_FNN[,stats], col="green", lwd=2)
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,3], col="pink", lwd=2)
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,4], col="pink", lwd=2, lty=2)
lines(x=c(T0:T1), y=results_SME_FNN0[,3], col="orange", lwd=2)
lines(x=c(T0:T1), y=results_SME_FNN0[,4], col="orange", lwd=2, lty=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
points(x=c(T0:T1), y=results_FNN[,stats], col="green", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,3], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,4], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_FNN0[,3], col="orange", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_FNN0[,4], col="orange", pch=20, cex=3)
legend(x="bottomleft", cex=1.5, lty=c(1,1,1,2,1,2), lwd=2, pch=20, col=c("blue", "green", "pink", "pink", "orange", "orange"), legend=c("GLM", "FNN", "SME GLM (b)", "SME GLM (b0)", "SME FNN (b)", "SME FNN (b0)"))
if (pdf.plot==1){dev.off()}


