####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Static mixed effects GLM
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(arrow)
library(tidyverse)
library(keras)
library(tensorflow)

pathPlot <- "../../Plots/"


####################################################################################
### load and pre-process data
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic

labelGLM <- c("ClaimNb", "True", "DrivAgeX", "GenderX", "LeasingX",
            "LowMileageX", "CatPriceX", "DeductibleX",
            "DurationX", "YearX",
            paste("VA", c(2:8), sep=""), paste("Re", c(2:15), sep=""),
            paste("Year", c(2:9), sep=""))

# building the data tensors
source("./Tools/01a static mixed effects - load data GLM.r")

tensor <- tensorGLM
dim(tensor)

GLM.XX <- c(5:10, 13:33) # 1=Observation YES/NO, 2=Exposure, 3=ClaimNb, 4=True, 11=Duration, 12=YearX
labelGLM[GLM.XX-2]

####################################################################################
### set parameters and define loss functions
####################################################################################

Poisson.Deviance <- function(obs, pred){200*(sum(pred)-sum(obs)+sum(log((obs/pred)^(obs))))/length(pred)}
NB.KL.divergence <- function(true, est, phi){100*mean(true*(log(true/est)-phi/(phi-1)*log(phi/((phi-1)*est/true+1))))}

phi.star <- 1.3
T0 <- 2014
T1 <- 2018

####################################################################################
### load GLM network
####################################################################################

source("./Tools/02a network architectures.R")

####################################################################################
### one year ahead MLEs for empirical Bayes
####################################################################################

results_SME_GLM_1Year <- data.frame(array(NA, dim=c(T1-T0+1, 4)))
names(results_SME_GLM_1Year) <- c("a_KL_in_sample", "a0_KL_in_sample_hom", "a_KL_out_of_sample", "a0_KL_out_of_sample_hom")

for (tt in c(T0:T1)){
  TT <- tt-2011+1
  # preparation of data, the first column of the tensor is the PolicyID
  dat.Obs    <- tensor[,2:(TT+1),1]        # indicator for observation yes/no
  index      <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT]==1)]  # only select active policies
  dat.Expo   <- tensor[index,2:(TT+1),2]   # exposure
  dat.YY     <- tensor[index,1:2,3]        # prepare tensor for claims
  dat.YY[,1] <- rowSums(tensor[index,2:(TT),3]) # sum of past claims
  dat.YY[,2] <- tensor[index,TT+1,3]       # actual claim
  dat.True   <- tensor[index,TT+1,4]       # true frequency
  dat.XX     <- tensor[index,2:(TT+1),GLM.XX]  # selected covariates
  dat.alpha  <- array(1, dim=c(nrow(tensor[index,,1]),1)) # prepare tensor for shape parameter
  # selection of GLM network
  (q0 <- dim(dat.XX)[3])
  seed <- 100 + TT - 1
  model <- GLM(seed, lookback=TT, q0, "exponential")
  w0 <- get_weights(model)
  w0[[1]] <- array(0, dim=dim(w0[[1]]))
  w0[[2]] <- array(log(0.1), dim=dim(w0[[2]]))
  w0[[3]] <- array(log(sum(dat.YY[,2])/sum(dat.Expo[,TT])), dim=dim(w0[[3]]))
  set_weights(model, w0)
  ## definition of loss function
  Q_loss <- function(y_true, y_pred){
      mu       <- y_pred[,1:TT]  # the first TT components of the output are the mean estimates
      alpha    <- y_pred[,TT+1]  # the TT+1-st component of the output is alpha
      YY.0     <- y_true[,1]
      YY.1     <- y_true[,2]
      mu.0     <- k_sum(mu[,1:(TT-1)],, axis=2)
      mu.1     <- mu[,TT]
      -k_sum(+tf$math$lgamma(alpha+YY.0+YY.1)-tf$math$lgamma(alpha+YY.0) +
             (alpha+YY.0)*k_log((alpha+mu.0)/(alpha+mu.0+mu.1)) +
              YY.1*k_log(mu.1/(alpha+mu.0+mu.1)))
          }
  ## GLM fitting
  path1 <- paste("./Networks/MixedGLM",seed,"_", tt,".h5", sep="")
  model %>% compile(loss = Q_loss, optimizer = 'nadam')
  #{t1 <- proc.time()
  #   fit <- model %>% fit(list(dat.XX, dat.Expo, dat.alpha), dat.YY,
  #                batch_size=5000, epochs=1000, verbose=1)
  #(proc.time()-t1)[3]}
  #plot(fit)
  #save_model_weights_hdf5(model, path1)
  load_model_weights_hdf5(model, path1)
  w0 <- get_weights(model)
  pred <- (model %>% predict(list(dat.XX, dat.Expo, dat.alpha), batch_size=10^6))
  alpha <- pred[,TT+1]
  pred <- pred[,1:TT]
  post.0  <- rowSums(pred[,1:(TT-1)])
  dat.YY[,2] <- post.0   # this corresponds to sum_t v_t mu_t
  # we build \bar{Y}^1_T = \sum_t N_t / sum_t v_t mu_t for those policies with a claims history
  dat.YY[which(dat.YY[,2]>0),1] <- dat.YY[which(dat.YY[,2]>0),1]/dat.YY[which(dat.YY[,2]>0),2]
  # inhomogeneous credibility prediction using v_{T+1} \mu_{T+1} * (.....)
  post <- pred[,TT]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha))
  # homogeneous Buhlmann-Straub collective mean
  mu.hom <- sum(post.0/(post.0+alpha)*dat.YY[,1])/sum(post.0/(post.0+alpha))
  # homogeneous credibility prediction
  post.hom <- pred[,TT]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha)*mu.hom)
  results_SME_GLM_1Year[tt-T0+1,2] <- round(NB.KL.divergence(dat.True, post.hom, phi.star),4)
  results_SME_GLM_1Year[tt-T0+1,1] <- round(NB.KL.divergence(dat.True, post, phi.star),4)
  ## out-of-sample
  dat.Obs    <- tensor[,2:(TT+2),1]
  index      <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT+1]==1)]
  dat.Expo   <- tensor[index,2:(TT+2),2]
  dat.True   <- tensor[index,TT+2,4]
  dat.XX     <- tensor[index,2:(TT+2),GLM.XX]
  dat.YY     <- tensor[index,1:2,3]
  dat.alpha  <- array(1, dim=c(nrow(tensor[index,,1]),1)) # prepare tensor for shape parameter
  ## we need to define a new model for increased time series
  model <- GLM(seed, lookback=TT+1, q0, "exponential")
  set_weights(model, w0)
  pred <- (model %>% predict(list(dat.XX, dat.Expo, dat.alpha), batch_size=10^6))
  alpha <- pred[,TT+2]
  pred <- pred[,1:(TT+1)]
  post.0  <- rowSums(pred[,1:TT])
  dat.YY[,1] <- rowSums(tensor[index,2:(TT+1),3])
  dat.YY[,2] <- post.0
  dat.YY[which(dat.YY[,2]>0),1] <- dat.YY[which(dat.YY[,2]>0),1]/dat.YY[which(dat.YY[,2]>0),2]
  post <- pred[,TT+1]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha))
  post.hom <- pred[,TT+1]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha)*mu.hom)
  results_SME_GLM_1Year[tt-T0+1,4] <- round(NB.KL.divergence(dat.True, post.hom, phi.star),4)
  results_SME_GLM_1Year[tt-T0+1,3] <- round(NB.KL.divergence(dat.True, post, phi.star),4)
   }

#plot(fit)
#save(data=results_SME_GLM_1Year, file="../Results/results_SME_GLM_1Year.rda")

results_SME_GLM_1Year


####################################################################################
### full MLE on all years for empirical Bayes
####################################################################################


results_SME_GLM <- data.frame(array(NA, dim=c(T1-T0+1, 4)))
names(results_SME_GLM) <- c("b_KL_in_sample", "b0_KL_in_sample_hom", "b_KL_out_of_sample", "b0_KL_out_of_sample_hom")


for (tt in c(T0:T1)){
  TT <- tt-2011+1
  # preparation of data
  dat.Obs    <- tensor[,2:(TT+1),1]
  index      <- c(1:nrow(dat.Obs))[which(rowSums(dat.Obs)>0)]
  dat.Expo   <- tensor[index,2:(TT+1),2]
  dat.YY     <- tensor[index,2:(TT+1),3]
  dat.XX     <- tensor[index,2:(TT+1),GLM.XX]
  dat.alpha  <- array(1, dim=c(nrow(tensor[index,,1]),1))
  # selection of GLM network
  (q0 <- dim(dat.XX)[3])
  seed <- 100 + TT - 1
  model <- GLM(seed, lookback=TT, q0, "exponential")
  w0 <- get_weights(model)
  w0[[1]] <- array(0, dim=dim(w0[[1]]))
  w0[[2]] <- array(log(0.1), dim=dim(w0[[2]]))
  w0[[3]] <- array(log(sum(dat.YY[,2])/sum(dat.Expo[,TT])), dim=dim(w0[[3]]))
  set_weights(model, w0)
  ## definition of loss function
  Q_loss <- function(y_true, y_pred){
      mu       <- y_pred[,1:TT]
      alpha    <- y_pred[,TT+1]
      YY       <- y_true
      YY.0     <- k_sum(YY[,1:TT],axis=2)
      mu.0     <- k_sum(mu[,1:TT],axis=2)
      xx       <- k_sum(YY*k_log(mu+.00000001), axis=2)
      -k_sum(+tf$math$lgamma(alpha+YY.0)-tf$math$lgamma(alpha) +
             alpha*k_log(alpha)-(alpha+YY.0)*log(alpha+mu.0) + xx)
          }
  ## GLM fitting
  path1 <- paste("./Networks/MixedGLMFull",seed,"_", tt,".h5", sep="")
  model %>% compile(loss = Q_loss, optimizer = 'nadam')
  #{t1 <- proc.time()
  #   fit <- model %>% fit(list(dat.XX, dat.Expo, dat.alpha), dat.YY,
  #                batch_size=5000, epochs=500, verbose=0)
  #(proc.time()-t1)[3]}
  #plot(fit)
  #save_model_weights_hdf5(model, path1)
  load_model_weights_hdf5(model, path1)
  w0 <- get_weights(model)
  dat.Obs    <- tensor[,2:(TT+1),1]
  index      <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT]==1)]
  dat.Expo   <- tensor[index,2:(TT+1),2]
  dat.True   <- tensor[index,TT+1,4]
  dat.XX     <- tensor[index,2:(TT+1),GLM.XX]
  dat.alpha  <- array(1, dim=c(nrow(tensor[index,,1]),1))
  pred <- (model %>% predict(list(dat.XX, dat.Expo, dat.alpha), batch_size=10^6))
  alpha <- pred[,TT+1]
  pred <- pred[,1:TT]
  post.0  <- rowSums(pred[,1:(TT-1)])
  dat.YY     <- tensor[index,1:2,3]
  dat.YY[,1] <- rowSums(tensor[index,2:(TT),3])
  dat.YY[,2] <- post.0
  dat.YY[which(dat.YY[,2]>0),1] <- dat.YY[which(dat.YY[,2]>0),1]/dat.YY[which(dat.YY[,2]>0),2]
  post <- pred[,TT]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha))
  mu.hom <- sum(post.0/(post.0+alpha)*dat.YY[,1])/sum(post.0/(post.0+alpha))
  post.hom <- pred[,TT]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha)*mu.hom)
  results_SME_GLM[tt-T0+1,2] <- round(NB.KL.divergence(dat.True, post.hom, phi.star),4)
  results_SME_GLM[tt-T0+1,1] <- round(NB.KL.divergence(dat.True, post, phi.star),4)
  ## out-of-sample
  dat.Obs    <- tensor[,2:(TT+2),1]
  index      <- c(1:nrow(dat.Obs))[which(dat.Obs[,TT+1]==1)]
  dat.Expo   <- tensor[index,2:(TT+2),2]
  dat.True   <- tensor[index,TT+2,4]
  dat.XX     <- tensor[index,2:(TT+2),GLM.XX]
  dat.YY     <- tensor[index,1:2,3]
  dat.alpha  <- array(1, dim=c(nrow(tensor[index,,1]),1))
  # increase model by one time period
  model <- GLM(seed, lookback=TT+1, q0, "exponential")
  set_weights(model, w0)
  pred <- (model %>% predict(list(dat.XX, dat.Expo, dat.alpha), batch_size=10^6))
  alpha <- pred[,TT+2]
  pred <- pred[,1:(TT+1)]
  post.0  <- rowSums(pred[,1:TT])
  dat.YY[,1] <- rowSums(tensor[index,2:(TT+1),3])
  dat.YY[,2] <- post.0
  dat.YY[which(dat.YY[,2]>0),1] <- dat.YY[which(dat.YY[,2]>0),1]/dat.YY[which(dat.YY[,2]>0),2]
  post <- pred[,TT+1]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha))
  post.hom <- pred[,TT+1]*(post.0/(post.0+alpha)*dat.YY[,1] + alpha/(post.0+alpha)*mu.hom)
  results_SME_GLM[tt-T0+1,4] <- round(NB.KL.divergence(dat.True, post.hom, phi.star),4)
  results_SME_GLM[tt-T0+1,3] <- round(NB.KL.divergence(dat.True, post, phi.star),4)
   }

#plot(fit)
#save(data=results_SME_GLM, file="../Results/results_SME_GLM.rda")

results_SME_GLM





######################

load(file="../Results/results_GLM.rda")
load(file="../Results/results_SME_GLM.rda")
load(file="../Results/results_SME_GLM_1Year.rda")

pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch3/SME_KL_in_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 3
ylim0 <- range(0,0.35)
plot(x=c(T0:T1), y=results_GLM[,stats], col="blue", type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                  main=list("static mixed effects: KL divergence T", cex=1.5))
lines(x=c(T0:T1), y=results_SME_GLM[,1], col="brown", lwd=2)
lines(x=c(T0:T1), y=results_SME_GLM[,2], col="brown", lwd=2, lty=2)
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,1], col="pink", lwd=2)
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,2], col="pink", lwd=2, lty=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM[,1], col="brown", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM[,2], col="brown", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,1], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,2], col="pink", pch=20, cex=3)
legend(x="bottomleft", cex=1.5, lty=c(1,1,2,1,2), lwd=2, pch=20, col=c("blue", "brown", "brown", "pink", "pink"), legend=c("GLM", "SME GLM (a)", "SME GLM (a0)", "SME GLM (b)", "SME GLM (b0)"))
if (pdf.plot==1){dev.off()}


pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch3/SME_KL_out_of_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 6
plot(x=c(T0:T1), y=results_GLM[,stats], col="blue", type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                   main=list("static mixed effects: KL divergence T+1", cex=1.5))
lines(x=c(T0:T1), y=results_SME_GLM[,3], col="brown", lwd=2)
lines(x=c(T0:T1), y=results_SME_GLM[,4], col="brown", lwd=2, lty=2)
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,3], col="pink", lwd=2)
lines(x=c(T0:T1), y=results_SME_GLM_1Year[,4], col="pink", lwd=2, lty=2)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM[,3], col="brown", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM[,4], col="brown", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,3], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_SME_GLM_1Year[,4], col="pink", pch=20, cex=3)
legend(x="bottomleft", cex=1.5, lty=c(1,1,2,1,2), lwd=2, pch=20, col=c("blue", "brown", "brown", "pink", "pink"), legend=c("GLM", "SME GLM (a)", "SME GLM (a0)", "SME GLM (b)", "SME GLM (b0)"))
if (pdf.plot==1){dev.off()}
