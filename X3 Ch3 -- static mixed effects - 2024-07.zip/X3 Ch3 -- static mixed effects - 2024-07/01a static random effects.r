####################################################################################
#########  Experience Rating in Insurance Pricing
#########  Static random effects: Buhlmann-Straub models
#########  Author: Mario Wuthrich
#########  Version July 2024
####################################################################################

library(arrow)
library(tidyverse)
pathPlot <- "../../Plots/"

####################################################################################
### define deviance loss and negative binomial KL divergence
####################################################################################

Poisson.Deviance <- function(obs, pred){200*(sum(pred)-sum(obs)+sum(log((obs/pred)^(obs))))/length(pred)}
NB.KL.divergence <- function(true, est, phi){100*mean(true*(log(true/est)-phi/(phi-1)*log(phi/((phi-1)*est/true+1))))}

####################################################################################
### load
####################################################################################

load(file=paste("../Data/DataSynthetic.rda", sep=""))
dat <- DataSynthetic

str(dat)

####################################################################################
### set parameters
####################################################################################

phi.star <- 1.3
T0 <- 2014
T1 <- 2018

####################################################################################
### fit static random effects models SRE: version (a) considering all past data
####################################################################################

results_SRE <- data.frame(array(NA, dim=c(T1-T0+1, 4)))
names(results_SRE) <- c("a_KL_in_sample", "a0_KL_in_sample_hom", "a_KL_out_of_sample", "a0_KL_out_of_sample_hom")

results_param <- data.frame(array(NA, dim=c(T1-T0+1, 3)))
names(results_param) <- c("MLE mean", "MLE_alpha", "hom_mean")

# define negative binomial log-likelihood
neg.SRE.LL <- function(param){
       mu0   <- exp(param[1])
       alpha <- exp(param[2])
       -sum(lgamma(alpha+datT$nn)-lgamma(alpha)-alpha*log(1+mu0*datT$vv/alpha)-datT$nn *log(1+alpha/(mu0*datT$vv)))
           }

for (TT in T0:T1){
   # select data
   datT <- dat[which(dat$Year<=TT),]
   # we only select the insurance policies that have some exposure after T0
   ID   <- datT[which(datT$Year>=T0), c("PolicyID", "ClaimNb", "Exposure", "True")]
   datT <- datT[which(datT$PolicyID %in% ID$PolicyID),]
   # initialization of the root search algorithm
   if(TT==T0){param0 <- c(log(mean(datT$ClaimNb)), log(1))}
   # we aggregate exposures and claims per considered insurance policy
   datT <- data.frame(datT %>%  group_by(PolicyID) %>%
                                         summarize(nn = sum(ClaimNb),
                                                   vv = sum(Exposure)))
   # MLE (convergence 0 is successful)
   (paramB <- optim(par=param0, fn=neg.SRE.LL))
   param0 <- paramB$par
   param1 <- exp(param0)
   results_param[TT-T0+1,1:2] <- param1
   ### in-sample (only last year to be comparable to the other methods)
   datT <- dat[which(dat$Year<=TT),]
   ID   <- datT[which(datT$Year==TT), c("PolicyID", "ClaimNb", "Exposure", "True")]
   datT <- datT[which(datT$PolicyID %in% ID$PolicyID),]
   datT <- data.frame(datT %>%  group_by(PolicyID) %>%
                                         summarize(nn = sum(ClaimNb),
                                                   vv = sum(Exposure)))
   datT <- ID %>% left_join(datT, by = "PolicyID")
   datT$nn <- datT$nn - datT$ClaimNb     # for in-sample we only need to aggregate to T-1
   datT$vv <- datT$vv - datT$Exposure    # for in-sample we only need to aggregate to T-1
   datT$pred <- datT$Exposure * (1/(datT$vv+param1[2]/param1[1])*datT$nn + (1-datT$vv/(datT$vv+param1[2]/param1[1]))*param1[1])
   mu.hom <- sum(1/(datT$vv+param1[2]/param1[1])*datT$nn)/sum(datT$vv/(datT$vv+param1[2]/param1[1]))
   results_param[TT-T0+1,3] <- mu.hom
   datT$pred.hom <- datT$Exposure * (1/(datT$vv+param1[2]/param1[1])*datT$nn + (1-datT$vv/(datT$vv+param1[2]/param1[1]))*mu.hom)
   #
   results_SRE[TT-T0+1,2] <- round(NB.KL.divergence(datT$True, datT$pred.hom, phi.star),4)
   results_SRE[TT-T0+1,1] <- round(NB.KL.divergence(datT$True, datT$pred, phi.star),4)
   ### out-of-sample
   datT <- dat[which(dat$Year<=(TT+1)),]
   ID   <- datT[which(datT$Year==(TT+1)), c("PolicyID", "ClaimNb", "Exposure", "True")]
   datT <- datT[which(datT$PolicyID %in% ID$PolicyID),]
   datT <- data.frame(datT %>%  group_by(PolicyID) %>%
                                         summarize(nn = sum(ClaimNb),
                                                   vv = sum(Exposure)))
   datT <- ID %>% left_join(datT, by = "PolicyID")
   datT$nn <- datT$nn - datT$ClaimNb
   datT$vv <- datT$vv - datT$Exposure
   datT$pred <- datT$Exposure * (1/(datT$vv+param1[2]/param1[1])*datT$nn + (1-datT$vv/(datT$vv+param1[2]/param1[1]))*param1[1])
   datT$pred.hom <- datT$Exposure * (1/(datT$vv+param1[2]/param1[1])*datT$nn + (1-datT$vv/(datT$vv+param1[2]/param1[1]))*mu.hom)
   #
   results_SRE[TT-T0+1,4] <- round(NB.KL.divergence(datT$True, datT$pred.hom, phi.star),4)
   results_SRE[TT-T0+1,3] <- round(NB.KL.divergence(datT$True, datT$pred, phi.star),4)
   }

#save(data=results_SRE, file="../Results/results_SRE.rda")

results_param
results_SRE

####################################################################################
### fit static random effects models SRE: version (b) considering only last year
####################################################################################

results_SRE0 <- data.frame(array(NA, dim=c(T1-T0+1, 4)))
names(results_SRE0) <- c("b_KL_in_sample", "b0_KL_in_sample_hom", "b_KL_out_of_sample", "b0_KL_out_of_sample_hom")

results_param0 <- data.frame(array(NA, dim=c(T1-T0+1, 3)))
names(results_param0) <- c("MLE mean", "MLE_alpha", "hom_mean")


# define negative binomial log-likelihood
neg.SRE.LL0 <- function(param){
       mu0   <- exp(param[1])
       alpha <- exp(param[2])
       -sum(lgamma(alpha+datT$nn)-lgamma(alpha+datT$nn0)+(alpha+datT$nn0)*log((alpha+mu0*datT$vv0)/(alpha+mu0*datT$vv))+(datT$nn-datT$nn0) *log(1-(alpha+mu0*datT$vv0)/(alpha+mu0*datT$vv)))
           }

for (TT in T0:T1){
   # select data
   datT <- dat[which(dat$Year<=TT),]
   ID  <- datT[which(datT$Year==TT), c("PolicyID", "ClaimNb", "Exposure", "True")]
   datT <- datT[which(datT$PolicyID %in% ID$PolicyID),]
   datT <- data.frame(datT %>%  group_by(PolicyID) %>%
                                         summarize(nn = sum(ClaimNb),
                                                   vv = sum(Exposure)))
   datT <- ID %>% left_join(datT, by = "PolicyID")
   datT$nn0 <- datT$nn - datT$ClaimNb
   datT$vv0 <- datT$vv - datT$Exposure
   if(TT==T0){param0   <- c(log(mean(datT$ClaimNb)), log(1))}
   ### MLE (convergence 0 is successful)
   paramB <- optim(par=param0, fn=neg.SRE.LL0)
   param0 <- paramB$par
   param1 <- exp(param0)
   results_param0[TT-T0+1,1:2] <- param1
   ### in-sample
   datT <- dat[which(dat$Year<=TT),]
   ID  <- datT[which(datT$Year==TT), c("PolicyID", "ClaimNb", "Exposure", "True")]
   datT <- datT[which(datT$PolicyID %in% ID$PolicyID),]
   datT <- data.frame(datT %>%  group_by(PolicyID) %>%
                                         summarize(nn = sum(ClaimNb),
                                                   vv = sum(Exposure)))
   datT <- ID %>% left_join(datT, by = "PolicyID")
   datT$nn <- datT$nn - datT$ClaimNb
   datT$vv <- datT$vv - datT$Exposure
   datT$pred <- datT$Exposure * (1/(datT$vv+param1[2]/param1[1])*datT$nn + (1-datT$vv/(datT$vv+param1[2]/param1[1]))*param1[1])
   mu.hom <- sum(1/(datT$vv+param1[2]/param1[1])*datT$nn)/sum(datT$vv/(datT$vv+param1[2]/param1[1]))
   results_param0[TT-T0+1,3] <- mu.hom
   datT$pred.hom <- datT$Exposure * (1/(datT$vv+param1[2]/param1[1])*datT$nn + (1-datT$vv/(datT$vv+param1[2]/param1[1]))*mu.hom)
   #
   results_SRE0[TT-T0+1,2] <- round(NB.KL.divergence(datT$True, datT$pred.hom, phi.star),4)
   results_SRE0[TT-T0+1,1] <- round(NB.KL.divergence(datT$True, datT$pred, phi.star),4)
   ### out-of-sample
   datT <- dat[which(dat$Year<=(TT+1)),]
   ID  <- datT[which(datT$Year==(TT+1)), c("PolicyID", "ClaimNb", "Exposure", "True")]
   datT <- datT[which(datT$PolicyID %in% ID$PolicyID),]
   datT <- data.frame(datT %>%  group_by(PolicyID) %>%
                                         summarize(nn = sum(ClaimNb),
                                                   vv = sum(Exposure)))
   datT <- ID %>% left_join(datT, by = "PolicyID")
   datT$nn <- datT$nn - datT$ClaimNb
   datT$vv <- datT$vv - datT$Exposure
   datT$pred <- datT$Exposure * (1/(datT$vv+param1[2]/param1[1])*datT$nn + (1-datT$vv/(datT$vv+param1[2]/param1[1]))*param1[1])
   datT$pred.hom <- datT$Exposure * (1/(datT$vv+param1[2]/param1[1])*datT$nn + (1-datT$vv/(datT$vv+param1[2]/param1[1]))*mu.hom)
   #
   results_SRE0[TT-T0+1,4] <- round(NB.KL.divergence(datT$True, datT$pred.hom, phi.star),4)
   results_SRE0[TT-T0+1,3] <- round(NB.KL.divergence(datT$True, datT$pred, phi.star),4)
   }

#save(data=results_SRE0, file="../Results/results_SRE0.rda")

results_param
results_param0
results_SRE0

####################################################################
####################################################################
####################################################################

load(file="../Results/results_GLM.rda")
load(file="../Results/results_null.rda")
load(file="../Results/results_SRE.rda")
load(file="../Results/results_SRE0.rda")



pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch3/SRE_KL_in_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 3
ylim0 <- range(0,0.7)
plot(x=c(T0:T1), y=results_null[,stats], type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                  main=list("static random effects: KL divergence T", cex=1.5))
lines(x=c(T0:T1), y=results_SRE[,1], col="brown", lwd=2)
lines(x=c(T0:T1), y=results_SRE[,2], col="brown", lwd=2, lty=2)
lines(x=c(T0:T1), y=results_SRE0[,1], col="pink", lwd=2)
lines(x=c(T0:T1), y=results_SRE0[,2], col="pink", lwd=2, lty=2)
lines(x=c(T0:T1), y=results_GLM[,stats], col="blue", lwd=2)
points(x=c(T0:T1), y=results_null[,stats], col="black", pch=20, cex=3)
points(x=c(T0:T1), y=results_SRE[,1], col="brown", pch=20, cex=3)
points(x=c(T0:T1), y=results_SRE[,2], col="brown", pch=20, cex=3)
points(x=c(T0:T1), y=results_SRE0[,1], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_SRE0[,2], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
legend(x="bottomleft", cex=1.5, lty=c(1,1,1,2,1,2), lwd=2, pch=20, col=c("black", "blue", "brown", "brown", "pink", "pink"), legend=c("null model", "GLM", "SRE (a)", "SRE (a0)", "SRE (b)", "SRE (b0)"))
if (pdf.plot==1){dev.off()}

pdf.plot <- TRUE
pdf.plot <- FALSE
filey1 <- paste(pathPlot, "/Ch3/SRE_KL_out_of_sample.pdf", sep="")
if (pdf.plot){pdf(file=filey1)}
stats <- 6
plot(x=c(T0:T1), y=results_null[,stats], type='l', lwd=2, ylim=ylim0,
                  xlab="learning sample", ylab="KL divergence to true model", cex.lab=1.5,
                  main=list("static random effects: KL divergence T+1", cex=1.5))
lines(x=c(T0:T1), y=results_SRE[,3], col="brown", lwd=2)
lines(x=c(T0:T1), y=results_SRE[,4], col="brown", lwd=2, lty=2)
lines(x=c(T0:T1), y=results_SRE0[,3], col="pink", lwd=2)
lines(x=c(T0:T1), y=results_SRE0[,4], col="pink", lwd=2, lty=2)
lines(x=c(T0:T1), y=results_GLM[,stats], col="blue", lwd=2)
points(x=c(T0:T1), y=results_null[,stats], col="black", pch=20, cex=3)
points(x=c(T0:T1), y=results_SRE[,3], col="brown", pch=20, cex=3)
points(x=c(T0:T1), y=results_SRE[,4], col="brown", pch=20, cex=3)
points(x=c(T0:T1), y=results_SRE0[,3], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_SRE0[,4], col="pink", pch=20, cex=3)
points(x=c(T0:T1), y=results_GLM[,stats], col="blue", pch=20, cex=3)
legend(x="bottomleft", cex=1.5, lty=c(1,1,1,2,1,2), lwd=2, pch=20, col=c("black", "blue", "brown", "brown", "pink", "pink"), legend=c("null model", "GLM", "SRE (a)", "SRE (a0)", "SRE (b)", "SRE (b0)"))
if (pdf.plot==1){dev.off()}
