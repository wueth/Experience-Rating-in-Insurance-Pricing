##########################################
#########  Experience Rating in Insurance Pricing
#########  Empirical Bayes and Robbins' formula
#########  Author: Mario Wuthrich
#########  Version July, 2024
##########################################

library(tidyverse)
library(arrow)

### data

dat <- data.frame(cbind(c(0:7),c(7840, 1317, 239, 42, 14, 4, 4, 1)))
names(dat) <- c("k", "n_k")
dat$nb_claims <- dat$k * dat$n_k

colSums(dat[,2:3])

### Robbins' formula

dat$p_k <- dat$n_k / sum(dat$n_k)
round(dat$p_k,4)

dat$Robbins <- NA
dat[1:7,]$Robbins <- (dat[1:7,]$k+1)*dat[2:8,]$p_k/dat[1:7,]$p_k

round(dat$Robbins,4)

### empirical Bayesian estimation of the Poisson gamma model

(mu0_MLE <- sum(dat$nb_claims)/sum(dat$n_k))

# log-likelihood for shape parameter
LL <- function(log_alpha){
          alpha <- exp(log_alpha)
          sum(dat$n_k*(lgamma(alpha+dat$k)-lgamma(alpha)-lgamma(dat$k+1)-dat$k*log(alpha/mu0_MLE+1)-alpha*log(mu0_MLE/alpha+1)))
                        }
# negative log-likelihood for shape parameter
LL.minus <- function(aa){-LL(aa)}

# convergence 0 is successful
a0 <- log(1)
(a1 <- optim(par=c(a0), fn=LL.minus,  method = "L-BFGS-B"))
(alpha_MLE <- exp(a1$par))

# credibility weights
(omega <- 1/(1+alpha_MLE/mu0_MLE))

dat$empBayes <- omega * dat$k + (1-omega)*mu0_MLE

round(dat$empBayes,4)
